import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { page } from "../../hooks/hooks"
import { LoginPage } from '../../pageRepository/search';
import { BasePage } from '../../utility/basepage';
const login = new LoginPage();
const basePage = new BasePage();

Given('I navigated to {string}', async (url: string) => { 
  let baseUrl:any = process.env.apiurl;
    const response:any = await page.goto(baseUrl);
    page.waitForLoadState("domcontentloaded");
    page.waitForTimeout(3000);
    const data = await response.json();
    console.log(data);
    const gbpDescription = data.bpi.GBP.description;
    expect(gbpDescription).toBe("British Pound Sterling");
});

Given('I navigate to {string}', async (url: string) => { 
  let baseUrl:any = process.env.url;
    await page.goto(baseUrl);
    page.waitForLoadState("domcontentloaded");
    page.waitForTimeout(3000);
  await login.search("book");
 
});


Then('verify cart updated or not {string}', async (text: string) => {
  login.isCartUpdated();
});