const report = require('multiple-cucumber-html-reporter');

report.generate({
  jsonDir: 'testResults',
  reportPath: 'testResults',
  reportName: 'playwrightReport',
  metadata: {
    browser: {
      name: 'chrome',
      version: 'latest'
    },
    device: 'Local test machine',
    platform: {
      name: 'ubuntu',
      version: '20.04'
    }
  },
  customData: {
    title: 'Run info',
    data: [
      { label: 'Project', value: 'Playwright Cucumber Project' },
      { label: 'Release', value: '1.0.0' },
      { label: 'Cycle', value: 'B11221.34321' },
      { label: 'Execution Start Time', value: new Date().toISOString() },
      { label: 'Execution End Time', value: new Date().toISOString() }
    ]
  }
});