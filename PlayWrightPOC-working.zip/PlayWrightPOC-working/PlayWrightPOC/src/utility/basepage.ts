// import { Page } from 'playwright';
import { Frame, Locator } from "playwright";
import { page } from "../hooks/hooks";
export class BasePage {

  async click(selector: string) {
    await page.click(selector);
    console.log(`user click on element ${selector}`);
  }

  async type(selector: string, text: string) {
    await page.fill(selector, text);
    console.log(`user enters data ${text} on element ${selector}`);
  }

  async getText(selector: string) {
    console.log(`user gets element text ${selector}`);
    return page.textContent(selector);   
  }

  async isVisible(selector: string): Promise<boolean> {
    return page.isVisible(selector);
  }

  async waitForSelector(selector: string) {
    await page.waitForSelector(selector);
  }

  async selectByValue(dropdownSelector: string, value: string) {
    await page.selectOption(dropdownSelector, value);
    console.log(`user selected dropdown value ${value} on element ${dropdownSelector}`);
  }

  async selectByLabel(dropdownSelector: string,label: string) {
    await page.selectOption(dropdownSelector, { label });
    console.log(`user selected dropdown value ${label} on element ${dropdownSelector}`);
  }

  async selectByIndex(dropdownSelector: string,index: number) {
    await page.selectOption(dropdownSelector, { index });
    console.log(`user selected dropdown value ${index} on element ${dropdownSelector}`);
  }

  async selectMultiple(dropdownSelector: string,values: string[]) {
    await page.selectOption(dropdownSelector, values);
  }

  async getFrame(selector: string): Promise<Frame> {
    const elementHandle:any = await page.$(selector);
    return elementHandle.contentFrame();
  }
  
  async selectByValueInFrame(iframeSelector : string, dropdownSelector: string,value: string) {
    const frame = await this.getFrame(iframeSelector);
    await frame.selectOption(dropdownSelector, value);
  }

  async selectByLabelInFrame(iframeSelector : string,dropdownSelector: string,label: string) {
    const frame = await this.getFrame(iframeSelector);
    await frame.selectOption(dropdownSelector, { label });
  }

  async selectByIndexInFrame(iframeSelector : string,dropdownSelector: string,index: number) {
    const frame = await this.getFrame(iframeSelector);
    await frame.selectOption(dropdownSelector, { index });
  }
}