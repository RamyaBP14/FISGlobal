import { expect } from "allure-playwright";
import { BasePage } from "../utility/basepage"
import { page } from "../hooks/hooks";
import { context } from "@cucumber/cucumber";

export class LoginPage extends BasePage {
  private searchInput = "//input[@name='_nkw']";
  private searchButton = "input[type=submit]";
  private addToCart = "#atcBtn_btn_1";
  private firstSearchResult = "//ul[contains(@class,'srp-results')]/li[1]";
  private updatedCart ='#gh-cart-n';

  async search(inputValue: string) {    
    await this.type(this.searchInput, inputValue);
    page.waitForTimeout(4000);  
    await this.click(this.searchButton);
    page.waitForTimeout(30000);     
  }

  async addAnItemToCart() {
    // const pages = await context.pages();
    // await pages[1].bringToFront();
    
  }

  async isCartUpdated() {
    await page.waitForSelector('.srp-results');   
    await this.click(this.firstSearchResult);   
    page.waitForTimeout(30000);
    await this.click(this.addToCart);
    let msg = await this.getText(this.updatedCart); 
    expect(msg).toBe("1");
  }  
  
}