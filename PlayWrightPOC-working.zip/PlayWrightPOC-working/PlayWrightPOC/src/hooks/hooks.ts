import { After, AfterAll, Before, BeforeAll, Status } from "@cucumber/cucumber";
import { Browser,BrowserContext,Page,chromium,firefox ,webkit} from "playwright"; 
import dotenv from "dotenv"

let browser : Browser;
let browserContext : BrowserContext;
let page: Page;
dotenv.config();

BeforeAll(async function() {      
    let browserType = process.env.browser;
    switch(browserType) {
        case "chrome" :
            browser = await chromium.launch({ headless: false, channel: "chrome", slowMo: 100 });
            break;

        case "edge" :
            browser = await chromium.launch({ headless: false, channel: "edge", slowMo: 100, args:['--start-maximized'] });
            break;

        case "firefox" :
            browser = await firefox.launch({ headless: false, slowMo: 100 });
            break;
            
        case "safari" :
            browser = await webkit.launch({ headless: false, slowMo: 100 });
            break;
    }
})

Before(async function(scenario) {     
    browserContext = await browser.newContext();
    page = await browserContext.newPage(); 
    let baseUrl:any = process.env.url;
    console.log(`************${scenario.pickle.name} is started*************`);
    // await page.goto(baseUrl);
    // page.waitForLoadState("domcontentloaded");
    // page.waitForTimeout(3000);
});

After(async function(scenario) {    
    if(scenario.result?.status==Status.FAILED)
    {
        const screenshot = await page.screenshot({ path:`testResults/screenshot/${scenario.pickle.name}.png`});
        this.attach(screenshot, 'image/png');
    }
     page.close();
     browserContext.close();
    console.log(`************${scenario.pickle.name} is ended*************`);
})

AfterAll(async function() {
    browser.close();
})

export { page };