import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [
    ['line'],
    ['json', { outputFile: 'cucumber-report.json' }]
  ],
});