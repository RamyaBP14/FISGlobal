const common = [
    'src/features/**/*.feature', // Specify feature files
    '--require-module ts-node/register', // Load TypeScript module
    '--require src/stepDefiniations/**/*.ts', // Load step definitions
    '--require src/ hooks/**/*.ts', // Load hooks
    '--format progress-bar', // Load custom formatter
    //'--format node_modules/@cucumber/pretty-formatter' // Load pretty formatter
    '--format json:testResults/cucumber-report.json',
    // format: ['json:reports/cucumber-report.json'],
    '--parallel 2'
  ].join(' ');
  
  module.exports = {
    default: common
  };