import { FhBankAccount } from '../../objects/fh_hub/fhBankAccount';  
import createBankAccountJson from '../../../resources/data/API/POST/fh_hub/AddBankAccount.json';
import { APIUtil } from '../../../utility/apiUtil';
import { fhHubUrls } from '../../../resources/data/API/urls/fh_hub';
import { PageBase } from '../../../utility/PageBase';

const pageBase = new PageBase();
const apiUtil = new APIUtil();

export class AddBankAccounts {

  async createBankAccount(bankName: string): Promise<FhBankAccount> {
    let responseData;
    const bankNumber = await pageBase.getRandomInt(2);
    let amendedBankAccountJson = createBankAccountJson
      amendedBankAccountJson = {
        ...amendedBankAccountJson,
        'bankNumber': bankNumber,
        'bankName': bankName + bankNumber,
      }
    console.log(amendedBankAccountJson); 
    const bankAccountBody:string = JSON.stringify(amendedBankAccountJson)      
    const response: Response = await apiUtil.POST(fhHubUrls.POST_AddBankAccount, bankAccountBody);
    if (!response.ok) {
      responseData = null;
    } else if(responseData == null){
      for (let i=0; i<10; i++) {
        if( response.status == 200) {
          break;
        }
        await this.createBankAccount(bankName);
      }
    }
    console.log(response);
    if (response.body !== null) {
      const responseJson = await response.json();
      const addBankAccountData: FhBankAccount = {
        'bankName': responseJson.data.bankName,
        'bankNumber': responseJson.data.bankNumber,
        'fhBankAccountSetupDataKey': responseJson.data.fhBankAccountSetupDataKey 
      }; 
      return addBankAccountData;
    } else {
      throw new Error('Failed to add the bank account via API');
    }
  } 

}