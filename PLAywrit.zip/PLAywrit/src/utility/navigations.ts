import { PageBase } from "./PageBase";

export class Navigations extends PageBase {
  
  async navigateToUrl(url: string) {
    const parsedUrl = new URL(url);
    const baseUrl = parsedUrl.origin;
    await this.navigate(baseUrl + url);
  }

  async navigateToFDPublicUsers() { 
    await this.navigateToUrl('/s/fd/crm/list.html')
  }

  async navigateToServiceLocations() { 
    await this.navigateToUrl('/o/ops/assets/service-location-list')
  }

}