/* eslint-disable no-undef */
/* eslint-disable @typescript-eslint/no-var-requires */
const AWS = require('aws-sdk'); 
AWS.config.update({    
  accessKeyId: 'AKIAWBRU5O3SF46WWVPN',
  region: 'us-east-1',
  secretAccessKey: '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'
});

const secretManager = new AWS.SecretsManager();

export async function getSecret(secretName: string,secretKey:string): Promise<string> {
 try {
    
    const data = await secretManager.getSecretValue({ SecretId: secretName }).promise();         
         const SecretString = data["SecretString"];
         const secret= JSON.parse(SecretString)
         const Base_URL=secret[secretKey]
      return Base_URL 
    
  } catch (err) {
    throw new Error(`Error retrieving secret: ${err}`);
  }
}