import { expect } from '@playwright/test'
import { LoggerUtil } from './logger'
import { PageBase } from './PageBase'
import axios from 'axios';
import { request } from "playwright";
import mime from "mime-lib";
import { WebClient } from '@slack/web-api';
import * as fs from 'fs';
import path from 'path';
import { errorMessage } from 'aws-sdk/clients/datapipeline';
import { JsonOperations } from './jsonOperations';
import Chance from 'chance';
import { DataTable } from '@cucumber/cucumber';
import { getSecret } from './secureCredentials';
// import {citycode, executionOptions} from '../../cucumber.js'


let log = new LoggerUtil();
let jsonUtil = new JsonOperations();
let newUrl: String;
let chance = new Chance();

export class CommonUtils extends PageBase {
    private gWorksLoader = '//div[@class="loader"]'
    private toasterMessage = '//div[@role="alertdialog"]'
    private toasterMessage1 = '(//div[@role="alertdialog"])[1]'
    private toasterMessage2 = '(//div[@role="alertdialog"])[2]'
    private toasterClose = "//button[contains(@class,'toast-close-button')]/span"
    public window

    private utilityBillingTab = "//p[text()='Utility Billing']"
    private UBSettings = "(//p[text()='Settings'])[1]"
    
    private invoicesMenu = "//span[text()='Invoices']"
    private pageHeader = "//h4[@class='gw-page-header']"
    //Side Menu Navigations
    private sideMenu = "//p[text()='HR']"
    // private sideSubMenu = "//span[text()='Accounts']"
    private sideSubMenu = "(//span[text()='Accounts'])[1]"
    private HRSettingsOptions = "//button[text()='Deductions/Benefits']"

    private listOptions = '//div[@role="option"]'
    //Master list Records
    private selectRecord = "//tr[@id='gw-row-data']/td[1]/a"
    private financeTab = "//button[@class='gw-side-nav-menu accordion-button active show']";


    //front desk web elements:

    private emailField = "//input[@id='emailAddress']"
    private passwordField = "//input[@id='loginPassword']"
    private loginBtn = "//button[text()='Login']"
    private dashboardPage = "//a[text()=' Dashboard']"
    private searchInput = "//input[@type='search']"
    private recordFound = "(//td)[1]"
    private payrollTab = "//a[text()='Payroll']"
    private pricingTab = "//a[text()='Pricing']"
    private agencyUsersTab = "//a[text()='Agency Users']"
    private channelTemplatesTab = "//a[text()='Channel Templates']"
    private emailDeliveribilityTab = "//a[text()='Email Deliverability']"
    private globalAPITab = "//a[text()='Global API Logs']"
    private addnewClientTab = "//span[text()='Add New Client']"
    private downloadTab = "//span[text()='Download']"
    private cityProfilePage = "//a[text()='Client']"
    private settingTab = "//span[text()='Settings']"
    private logsTab = "//span[text()='Logs']"
    private displayNameField = "//input[@id='cname'][@name='city.name']"
    private legelNameField = "//input[@id='cname'][@name='city.legal_name']"
    private logintoPortal = "//a[text()='Log into Portal']"
    private frontdeskPage = "//h3[text()='FrontDesk']"
    private userProfileIcon = "//a[@title='User Profile']"
    private logOut = "//a[text()='Log Out ']"
    private hubUserProfile = '//li//*[@data-icon="user"]//ancestor::a'
    private hubLogout = "//div[text()=' Logout ']"
    private sidenavMenuList = "//nav[@id='side-menu']//div[@class='nav-link first-level-menu']"
    private inQAToggle = "(//i[@aria-hidden='true'])[7]"
    private updateBtn = "(//button[text()='Update'])[1]"
    private globalSearchTextBox = "//input[@placeholder='Search']"
    private masterListRecord = "(//tr[@id='gw-row-data'])[1]"
    private labelLocator = "//label[normalize-space()='Initial Deposit Amount']"
    private labelValueLocator = "//label[normalize-space()='Initial Deposit Amount']/../following-sibling::div/span"
    private MasterPagrFilters = "//div[@class='ng-value-container']//div[text()='All Services']/parent::div//input"
    private ubHubTogglebutton = "//input[@id='ub']"
    private opsHubToggleButton = "//input[@id='ops']"
    private opsHubRadioButton = "//input[@id='ops_full']"
    private UITableColumns = "//table//th"
    private inQAtoggleButton = "//input[@id='inQA']"
    private tablesFirstRowData = "//table//tr[1]/td"
    private accountSpecificData = "(//table//tr[1]/td/span[text()='10086503']/../../following-sibling::tr)[1]/td"
    private selectCalender = "//input[@id='gw-select-data-range']"
    private calenderPreviousButton = "//button[@class='previous' and @style='visibility: visible;']"
    private calenderStartMonthVisibility = "//bs-days-calendar-view[1]//button[@type='button']//span[text()='July']"
    private calenderEndMonthVisibility = "//bs-days-calendar-view[2]//button[@type='button']//span[text()='August']"
    private calenderNextButton = "//button[@class='next' and @style='visibility: visible;']" 
    private selectStartMonthDate = "(//table[@role='grid'])[1]//span[text()='5' and @class='ng-star-inserted']"
    private selectEndMothDate = "(//table[@role='grid'])[2]//span[text()='7' and @class='ng-star-inserted']"
    private executionCityName = "//div[@id='navbarSupportedContent']//a[@class='nav-link gw-cursor-default']"
    private cityCodes = ""
    private frontDeskToggleButton = "//input[@id='frontdesk']/following-sibling::i[1]"
    private updateBtn2 = "(//button[text()='Update'])[2]"
    private timetrackerCheckbox = "//input[@id='plugin_timetracker']"
    private timetrackerCheckboxButton = "//input[@id='plugin_timetracker']/following-sibling::i"
    private approveTStoaster = "//div[@id='toast-container']"
    private agencySelect = '//select[@name="citycode"]'
    private agencySelectDropdownOptions = '//select[@name="citycode"]//option'
    private closeLoginPopUp = '//button[contains(@id, "pendo-close-guide")]'

    //UB
    private billingTab="//span[text()='Billing']"
    private utilitySettingsTab = "//p[text()='Utility Billing']//following::p[5]"
    private utilitySettingsBillingTab = "//span[normalize-space()='Billing']"
    private UBSettingsBilling = "//button[@id='flyout-menu342']"
    private updateButtonEditService = "//button[@id='gw-ub-service-request-create-request-btn' and contains(@class, 'gw-btn-primary') and text()='Update']"

    async loginPage(urlBase, codevalue, scenariotags=["test"]) {
        const username = await getSecret('Login.Credentials','Login.Username')
        const password = await getSecret('Login.Credentials','Login.Password')
        await global.page.goto(urlBase, { timeout: 50000 })
        await log.info("Launched url :"+ urlBase)
        await this.enter(this.emailField, username)
        await this.enter(this.passwordField, password)
        await this.wait(2000)
        await this.click(this.loginBtn)
        await this.waitForPageLoad()
        await this.wait(8000)
        await this.verifyVisibility(this.dashboardPage, "Visible")

        let cityCode;
        for (let i = 0; i < scenariotags.length; i++) {
          if (scenariotags.includes("@city2")) {
            cityCode = process.env.cityCode2;
            codevalue  = cityCode;
          } else if (scenariotags.includes("@city3")) {
            cityCode = process.env.cityCode3;
            codevalue  = cityCode;
          } else if (scenariotags.includes("@city4")) {
            cityCode = process.env.cityCode4;
            codevalue  = cityCode;
          } else if (scenariotags.includes("@city5")) {
            cityCode = process.env.cityCode5;
            codevalue  = cityCode;
          } else if (scenariotags.includes("@city6")) {
            cityCode = process.env.cityCode6;
            codevalue  = cityCode;
          } else if (scenariotags.includes("@city7")) {
            cityCode = process.env.cityCode7;
            codevalue  = cityCode;
          } else if (scenariotags.includes("@city8")) {
            cityCode = process.env.cityCode8;
            codevalue  = cityCode;
          } else if (scenariotags.includes("@city9")) {
            cityCode = process.env.cityCode9;
            codevalue  = cityCode;
          } else if (scenariotags.includes("@city10")) {
            cityCode = process.env.cityCode10;
            codevalue  = cityCode;
          } else if (scenariotags.includes("@city11")) {
            cityCode = process.env.cityCode11;
            codevalue  = cityCode;
          } else if (scenariotags.includes("@city12")) {
            cityCode = process.env.cityCode12;
            codevalue  = cityCode;
          } else if (scenariotags.includes("@city13")) {
            cityCode = process.env.cityCode13;
            codevalue  = cityCode
          } else if (scenariotags.includes("@city14")) {
            cityCode = process.env.cityCode14;
            codevalue  = cityCode;
          } else if (scenariotags.includes("@city15")) {
            cityCode = process.env.cityCode15;
            codevalue  = cityCode
          } else if (scenariotags.includes("@ubDefaultCode")){
            cityCode = process.env.ubDefaultCode;    
            codevalue  = cityCode;
          } else if (scenariotags.includes("@financeDefaultCode")){
            cityCode = process.env.financeDefaultCode;    
            codevalue  = cityCode;
          } else if (scenariotags.includes("@opsDefaultCode")){
            cityCode = process.env.opsDefaultCode;    
            codevalue  = cityCode;
          } else if (scenariotags.includes("@hrDefaultCode")){
            cityCode = process.env.hrDefaultCode;    
            codevalue  = cityCode;
          } else if (scenariotags.includes("@payrollDefaultCode")){
            cityCode = process.env.payrollDefaultCode;    
            codevalue  = cityCode;
          } else if (scenariotags.includes("@city16")){
            cityCode = process.env.cityCode16;    
            codevalue  = cityCode;
          } else {
            cityCode = process.env.cityCode;
            codevalue  = cityCode;
          }
        }
        //select 
        await this.wait(4000);
        await this.enter(this.searchInput, codevalue);
        await this.pressEnter();
        await this.click('//tr[@city-code="%%%"]'.replace("%%%", codevalue));
        await this.wait(4000);
        await this.handleLoadingSpinner();
        await this.verifyVisibility(this.cityProfilePage, "Visible");
       
        //Select Env for STG  
        if (await this.isChecked(this.inQAtoggleButton)) {
            await this.click(this.inQAToggle);
            await this.wait(2000);
            await this.click(this.updateBtn);
        } else {
            await log.info("Already in STG environment");
        }
         //Select FrontDesk Toggle
        if (await this.isChecked(this.frontDeskToggleButton)) {
            await log.info("FrontDesk toggle is already enabled");
        } else {
            await this.wait(2000);
            await this.click(this.frontDeskToggleButton);
            await this.wait(2000);
            await this.click(this.updateBtn2);
            await log.info("FrontDesk toggle is enabled now");
        }
        
        //Select UB Hub
        if (await this.isChecked(this.ubHubTogglebutton)) {
            await log.info("UB hub toggle is already enabled")
        } else {
            await this.wait(2000)
            await this.click(this.ubHubTogglebutton)
            await this.wait(2000)
            await this.click(this.updateBtn)
            await log.info("UB hub toggle is enabled now")
        }
        
        
        //Select OPS Hub
        if (await this.isChecked(this.opsHubToggleButton)) {
            await log.info("OPS hub toggle is already enabled")
        } else {
            await this.click(this.opsHubToggleButton)
            await log.info("OPS hub toggle is enabled now")
            await this.click(this.opsHubRadioButton)
            await this.click(this.updateBtn)
            await log.info("OPS hub Full radio button is selected now")
        }
        
        //TimeTracker for Timesheet
        for (let i = 0; i < scenariotags.length; i++) {
            if (scenariotags.includes("@timesheet")) {
                if (!(await this.isChecked(this.timetrackerCheckbox))) {
                    await this.click(this.timetrackerCheckboxButton)
                    await log.info("Checked TimeTracker")
                    await this.click(this.updateBtn2)
                    await this.wait(2000)
                    await this.waitForPageLoad()
                } else {
                    log.info("Time Tracker already enabled")
                }
            } else {
                log.info("Time Tracker Not required")
                if (await this.isChecked(this.timetrackerCheckbox)) {
                    await this.click(this.timetrackerCheckboxButton)
                    await log.info("UnChecked TimeTracker")
                    await this.click(this.updateBtn2)
                    await this.wait(2000)
                    await this.waitForPageLoad()
                } else {
                    log.info("Time Tracker already disabled")
                }
            }
        }
        global.cityCode = codevalue;
        await this.windowHandling(this.logintoPortal);
        await this.wait(10000);
    }

    /*  async logout() {
         await this.wait(4000)
         const frontDesk="//p[text()='FrontDesk']"
         const userProfileIcon = "//a[@title='User Profile']"
         const logOut = "//a[text()='Log Out ']"
         const loginPage="//h3[text()='Log In: Agency Portal']"
         await this.window.click(frontDesk)
         await this.window.click(userProfileIcon)
        // await this.window.waitForTimeout(4000)
         await this.window.click(logOut)
         await this.wait(4000)
         let headerText = await this.window.innerText(loginPage)
         await log.info(headerText)
         await expect("FrontDesk").toBe(headerText)*/
    private FinanceTab = "//h2[@id='gw-side-nav-heading0']"
    private financeHubSettings = "(//div[@class='gw-nav-submenu-bg-color gw-submenu-dropdown']//p[contains(text(),'Settings')])[1]"
    private financeAccounting = "(//span[text()='Accounting'])[1]"

    async waitForLoadingSpinnerVisibility() {
        await log.info("Waiting for loading spinner ");
        await global.page.waitForSelector(this.gWorksLoader, { state: "visible", timeout: 4000 })
        await log.info("Loading spinner is visible ");
    }

    async handleLoadingSpinner() {
        if (await this.isVisible(this.gWorksLoader)) {
            await this.waitForSelectorHidden(this.gWorksLoader, 150000)
        }
        else /*if (page.isHidden(this.loadSpinner)) */ {
            /*await this.waitForLoadingSpinnerVisibility()*/
            //await this.isHidden(this.loadSpinner)
        }
    }
    async handleLoadingSpinnerPayrollCalculation() {
        if (await this.isVisible(this.gWorksLoader)) {
            await this.waitForSelectorHidden(this.gWorksLoader, 300000);
        }
        else /*if (page.isHidden(this.loadSpinner)) */ {
            /*await this.waitForLoadingSpinnerVisibility()*/
            //await this.isHidden(this.loadSpinner)
        }
    }

    async gettoasterMessage() {
        await this.waitForSelector(this.toasterMessage, 30000)
        const msg = await (await this.getInnerText(this.toasterMessage)).trim();
        await log.info(`Toaster Message displayed as : ${msg}`)
        await this.waitForSelectorHidden(this.toasterMessage, 30000)
        return msg
    }

    async toasterValidation(expectedValue) {
        await this.waitForSelector(this.toasterMessage, 150000)
        const msg = await (await this.getInnerText(this.toasterMessage)).trim();
        expect(msg).toBe(expectedValue)
        await log.info(`Toaster Message displayed as : ${msg}`)
        await this.waitForSelectorHidden(this.toasterMessage, 150000)
    }

    async toasterValidationfor2Messages(msg1,msg2) {
        await this.waitForSelector(this.toasterMessage1, 150000)
        const msgUi1 = await (await this.getInnerText(this.toasterMessage1)).trim();
        await expect(msgUi1).toBe(msg1)
        await log.info(`Toaster Message displayed as : ${msgUi1}`)
        await this.waitForSelector(this.toasterMessage, 150000)
        const msgUi2 = await (await this.getInnerText(this.toasterMessage2)).trim();
        await expect(msgUi2).toBe(msg2)
        await log.info(`Toaster Message displayed as : ${msgUi2}`)
        await this.waitForSelectorHidden(this.toasterMessage, 150000)
    }

    async toasterValidationfor2MessagesContain(msg1,msg2) {
        await this.waitForSelector(this.toasterMessage1, 150000)
        const msgUi1 = await (await this.getInnerText(this.toasterMessage1)).trim();
        await expect(msgUi1).toContain(msg1)
        await log.info(`Toaster Message displayed as : ${msgUi1}`)
        await this.waitForSelector(this.toasterMessage, 150000)
        const msgUi2 = await (await this.getInnerText(this.toasterMessage2)).trim();
        await expect(msgUi2).toContain(msg2)
        await log.info(`Toaster Message displayed as : ${msgUi2}`)
        await this.waitForSelectorHidden(this.toasterMessage, 150000)
    }
    async toasterValidationfor2MessagesContainAnyOfThem(msg1,msg2) {
        if(await this.isVisible(this.toasterMessage1)){
            const msgUi1 = await (await this.getInnerText(this.toasterMessage1)).trim();
            await expect(msgUi1).toContain(msg1)
            await log.info(`Toaster Message displayed as : ${msgUi1}`)
        } else if(await this.isVisible(this.toasterMessage2)) {
            await this.waitForSelector(this.toasterMessage2, 5000)
            const msgUi2 = await (await this.getInnerText(this.toasterMessage2)).trim();
            await expect(msgUi2).toContain(msg2)
            await log.info(`Toaster Message displayed as : ${msgUi2}`)
        } else {
            throw new Error('Neither message is displayed.');
        }
    }
    async toasterValidationfor2MessagesContainAny(msg1, msg2) {
        await this.waitForSelector(this.toasterMessage1, 150000);
        const msgUi1 = (await this.getInnerText(this.toasterMessage1)).trim();
        
        await this.waitForSelector(this.toasterMessage2, 150000);
        const msgUi2 = (await this.getInnerText(this.toasterMessage2)).trim();
    
        const msg1Found = msgUi1.includes(msg1);
        const msg2Found = msgUi2.includes(msg2);
    
        // Checking if either message 1 or message 2 is displayed
        if (msg1Found || msg2Found) {
            await log.info(`Toaster Message displayed as : ${msg1Found ? msgUi1 : msgUi2}`);
            await this.waitForSelectorHidden(this.toasterMessage, 150000);
        } else {
            throw new Error('Neither message is displayed.');
        }
    
        // Assertion - Only one of the messages should match
        expect(msg1Found + msg2Found).toBe(1);
    }

    async toasterMessageContainsValidation(expectedValue) {
        await this.waitForSelector(this.toasterMessage, 30000)
        const msg = await (await this.getInnerText(this.toasterMessage)).trim();
        await expect(msg).toContain(expectedValue)
        await log.info(`Toaster Message displayed as : ${msg}`)
        await this.waitForSelectorHidden(this.toasterMessage, 30000)
    }

    async validateDatesWRTMonthSelection(monthLocator, dateLocator, month, dateValue) {
        await this.selectDropdownwithStrictMatch(monthLocator, this.listOptions, month)
        await this.click(dateLocator)
        switch (month) {
            case "January":
            case "March":
            case "May":
            case "July":
            case "August":
            case "October":
            case "December":
                await this.datesValidation('31', dateValue, month)
                break
            case "April":
            case "June":
            case "September":
            case "November":
                await this.datesValidation('30', dateValue, month)
                break
            case "February":
                let date = await this.getElements(this.listOptions)
                if (await date.length == '28') {
                    await log.info("No of dates displayed for the " + month + ": " + date.length)
                    await this.selectValueEquals(this.listOptions, dateValue)
                } else if (await date.length == '29') {
                    await log.info("Leap year")
                    await log.info("No of dates displayed for the " + month + ": " + date.length)
                    await this.selectValueEquals(this.listOptions, dateValue)
                } else {
                    await log.error("Dates length is not as expected: " + date.length)
                }
                break
            default:
                await log.error("Invalid month")
        }
    }
    async datesValidation(dateLen, dateValue, month) {
        let date = await this.getElements(this.listOptions)
        if (await date.length == dateLen) {
            await log.info("No of dates displayed for the " + month + ": " + date.length)
            await this.selectValueEquals(this.listOptions, dateValue)
        } else {
            await log.error("Dates length is not as expected: " + date.length)
        }
    }

    async navigateToUBSettings() {
        await this.wait(2000)
        if (await this.isVisible(this.UBSettings)) {
            await this.click(this.UBSettings)
        } else {
            await this.click(this.utilityBillingTab)
            await this.wait(2000)
            await this.click(this.UBSettings)
        }
    }
    async navigateToBillingGeneralPage() {
        await this.navigateToUBSettings()
        await this.wait(2000)
        await this.click(this.utilitySettingsBillingTab)  //utilitySettingsBillingTab  UBSettingsBilling
        await this.wait(2000)
        await this.handleLoadingSpinner()
    }
    async navigateToInvoicesMasterPage() {
        await this.navigateToUBSettings()
        await this.wait(2000)
        await this.click(this.invoicesMenu)
        await this.wait(2000)
        await this.handleLoadingSpinner()
    }

    //PageHeader
    async verifyPageHeader(headerText) {
        await this.verifyElementTrimmedText(this.pageHeader, headerText)
    }

    // Master list Records
    async clickOnRecordsOfMasterlist(recordNumber) {
        await this.click(`(${this.selectRecord})[${recordNumber}]`)
        await this.wait(3000)
    }


    //Side Manu Navigations
    //HR Hub
    async clickOnSideMenuOption(menuOption) {
        const sideMenuOption = this.sideMenu.replace(`HR`, menuOption)
        await this.click(sideMenuOption)
        await this.sleep(2000);
    }

    async clickOnSideSubMenuOption(menuOption) {
        const sideMenuOption = this.sideSubMenu.replace(`Accounts`, menuOption)
        await this.click(sideMenuOption)
    }

    async navigateToHROptions(HRmenu) {
        await this.clickOnSideMenuOption("HR")
        await this.clickOnSideMenuOption(HRmenu)
        await this.handleLoadingSpinner()
    }


    async navigateToHRPayrollOption(payrollOption) {
        await this.clickOnSideMenuOption("HR")
        await this.clickOnSideMenuOption("Payroll")
        await this.clickOnSideMenuOption(payrollOption)
        await this.handleLoadingSpinner()
    }

    async navigateToHRSettings() {
        await this.clickOnSideMenuOption("HR")
        await this.clickOnSideMenuOption("Settings")
        await this.handleLoadingSpinner()
    }

    async navigateToHRSettingsOption(settingOption) {
        await this.clickOnSideMenuOption("HR")
        await this.clickOnSideMenuOption("Settings")
        await this.handleLoadingSpinner()
        const settingsOption = this.sideMenu.replace(`Deductions/Benefits`, settingOption)
        await this.click(settingOption)
    }

    //UB Hub
    async navigateToUBAccountOption(accountsMenu) {
        await this.clickOnSideMenuOption("Utility Billing")
        await this.clickOnSideMenuOption("UB Accounts")
        await this.clickOnSideMenuOption(accountsMenu)
        await this.handleLoadingSpinner()
    }

    async navigateToBillingOption(billingMenu) {
        await this.clickOnSideMenuOption("Utility Billing")
        await this.clickOnSideMenuOption("Billing")
        await this.clickOnSideMenuOption(billingMenu)
        await this.handleLoadingSpinner()
    }

    async navigateToUBMenu(option) {
        await this.clickOnSideMenuOption("Utility Billing")
        await this.clickOnSideMenuOption(option)
        await this.handleLoadingSpinner()
    }

    async navigateToUBSettingsMenu(option) {
        await this.clickOnSideMenuOption("Utility Billing")
        await this.clickOnSideMenuOption("Settings")
        await this.clickOnSideMenuOption(option)
        await this.handleLoadingSpinner()
    }



    //Operations Hub
    async navigateToOPSMenu(option) {
        await this.clickOnSideMenuOption("Operations")
        await this.clickOnSideMenuOption(option)
        await this.handleLoadingSpinner()
    }

    async navigateToOPSSettingsMenu(option) {
        await this.clickOnSideMenuOption("Operations")
        await this.clickOnSideMenuOption("Settings")
        await this.clickOnSideMenuOption(option)
        await this.handleLoadingSpinner()
    }
    //All

    async getMenuIsVisible(menuOption) {
        let menuvisible = false
        const sideMenuOption = this.sideMenu.replace(`HR`, menuOption)
        menuvisible = await this.isVisible(sideMenuOption)
        return menuvisible
    }

    async getSubMenuIsVisible(menuOption) {
        let menuvisible = false
        const sideMenuOption = this.sideSubMenu.replace(`Accounts`, menuOption)
        menuvisible = await this.isVisible(sideMenuOption)
        return menuvisible
    }

    // async navigate3sideMenus(menu1,menu2,menu3){
    //     if((!(await this.getMenuIsVisible(menu2)))){
    //         await this.clickOnSideMenuOption(menu1)
    //         await this.wait(2000)
    //     }
    //     if((!(await this.getSubMenuIsVisible(menu3)))){
    //         if(await menu2=="Utility Billings" && await menu3=="Settings"){
    //             await this.click("(//span[text()='Settings'])[2]")
    //         }
    //         else if(await menu2=="Operations" && await menu3=="Settings"){
    //             await this.click("(//span[text()='Settings'])[2]")
    //         }
    //         else {
    //             await this.clickOnSideMenuOption(menu2)
    //         }

    //     }
    //     await this.clickOnSideSubMenuOption(menu3)
    //     await this.handleLoadingSpinner()
    // }
    async navigate3sideMenus(menu1, menu2, menu3) {
        const menu2Visible = await this.getMenuIsVisible(menu2);
        const menu3Visible = await this.getSubMenuIsVisible(menu3);

        if (!menu2Visible) {
            await this.clickOnSideMenuOption(menu1);
            await this.wait(2000);
        }

        if (!menu3Visible) {
            if (menu1 === "Utility Billing" && menu2 === "Settings") {
                await this.click("(//p[text()='Settings'])[3]");
            } else if (menu1 === "Operations" && menu2 === "Settings") {
                await this.click("(//p[text()='Settings'])[1]");
            } else {
                await this.clickOnSideMenuOption(menu2);
            }
        }

        await this.clickOnSideSubMenuOption(menu3);
        await this.handleLoadingSpinner();
    }


    // async navigate2sideMenus(menu1,menu2){
    //     if((!(await this.getSubMenuIsVisible(menu2)))){
    //         await this.clickOnSideMenuOption(menu1)
    //         await this.wait(2000)
    //     }
    //     await this.clickOnSideSubMenuOption(menu2)
    //     await this.handleLoadingSpinner()
    // }
    async navigate2sideMenus(menu1, menu2) {
        const isSubMenuVisible = await this.getSubMenuIsVisible(menu2);

        if (!isSubMenuVisible) {
            await this.clickOnSideMenuOption(menu1);
            await this.wait(2000);
        }

        await this.clickOnSideSubMenuOption(menu2);
        await this.handleLoadingSpinner();
    }

    //To attach file in cucumber file
    async getContentTypeToAttachFile(fileType) {
        let contentType;
        switch (fileType) {
            case "csv":
                contentType = 'text/csv'
                return contentType
            case "xlsx":
                contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                return contentType
            case "dat":
                contentType = 'application/octet-stream.dat'
                return contentType
            case "rte":
                contentType = 'application/x-winrte.rte'
                return contentType
            case "imp":
                contentType = 'application/vnd.accpac.simply.imp'
                return contentType
            default:
                throw new Error(`Unsupported file Type: ${fileType}`);
        }
    }

    async getTestingCityName() {
        const cityCode = process.env.cityCode
        let cityName;
        
        switch (cityCode) {
            case "mnd_auto_mig_stg":
              cityName = 'Moundridge_Auto_Migration_Stg'  
              return cityName
            case 'mnd001':
              cityName = 'Moundridge'
              return cityName
            case 'fd_mnd_stg_test_01':
            case 'ben_abra_9822':
            case "len_stg9":
            case "mnd_sep_22_qa":
              cityName = 'Moundridge'
              return cityName
            case "eff_july_21":
              cityName = 'Effingham'
              return cityName
            case "wil001":
              cityName = 'Williamson'
              return cityName
            case "for_july_02":
              cityName = 'Fort Pierre'
              return cityName
            case "key001":
                cityName = 'Keystone'
                return cityName
            case "mil001":
                cityName = 'Miller'
                return cityName
            case "bat_july_17_qa":
                cityName = 'Bates'
                return cityName
            case "gre_jun_28":
                cityName = 'Greenup'
                return cityName
            case "mil_july_05":
                cityName = 'Miller'
                return cityName
            case "len_july_12":
                cityName = 'Lennox'
                return cityName
            case "frank_lennox_001":
                cityName = 'Lennox'
                return cityName
            case "lak_july_08":
                cityName = 'Lakeview'
                return cityName
            case "hia_002":
                cityName = 'Hiawatha'
                return cityName
            case "lak_stg17":
                cityName = 'Lakeview'
                return cityName
            case "fon001":
                cityName = 'Fonda'
                return cityName
            case "goo_july_10":
                cityName = 'Goodman'
                return cityName
            case "mil_july_05":
                cityName = 'Miller'
                return cityName
            case "len_july_12":
                cityName = 'Lennox'
                return cityName
            case "lak_july_08":
                cityName = 'Lakeview'
                return cityName
            default:
                throw new Error(`Incorrect city name for upload functionality, create folder with the city name and upload the respected files: ${cityName}`);
        }
    }
    // below code to get the city code value from command line

    // async getCityCodeValueFromCommandLine() {
    //     // Get the arguments after "--" in the npm run cucumber command.
    //     const args = process.argv.slice(process.argv.indexOf('--') + 1);

    //     if (args.length > 0) {
    //         let opsValue = '';
    //         let abcValue = '';

    //         // Loop through the arguments to find -p flag and its value.
    //         for (let i = 2; i < args.length; i++) {
    //             if (args[i] === '-p' && i + 1 < args.length) {
    //                 opsValue = args[i + 1];
    //                 // Increment i again to skip the next iteration since it corresponds to the value of -p.
    //                 i++;
    //             } else {
    //                 // Check if the current argument is not a flag (doesn't start with "-").
    //                 if (!args[i].startsWith('-')) {
    //                     abcValue = args[i];
    //                 }
    //             }
    //         }
    //         console.log(`test tag value: ${opsValue}`);
    //         console.log(`city code value: ${abcValue}`);
    //         return abcValue

        
    //     } else {
    //         console.log('Please provide city code arguments after "--".');
    //     }
    // }

    // below code to get the city code value from command line with Retry

    async getCityCodeValueFromCommandLine() {
        // Get the arguments after "--" in the npm run cucumber command.
        const args = process.argv.slice(process.argv.indexOf('--') + 1);
    
        if (args.length > 0) {
            let testTag = ''; // Formerly opsValue
            let cityCode = ''; // Formerly abcValue
            let retryValue = '';
    
            // Loop through the arguments to find -p flag and its value.
            for (let i = 2; i < args.length; i++) {
                if (args[i] === '-p' && i + 1 < args.length) {
                    testTag = args[i + 1]; 
                    // Increment i again to skip the next iteration since it corresponds to the value of -p.
                    i++;
                } else if (args[i] === '--retry' && i + 1 < args.length) {
                    retryValue = args[i + 1];
                    // Increment i again to skip the next iteration since it corresponds to the value of --retry.
                    i++;
                } else {
                    // Check if the current argument is not a flag (doesn't start with "-").
                    if (!args[i].startsWith('-')) {
                        cityCode = args[i]; 
                    }
                }
            }
    
            console.log(`test tag value: ${testTag}`); // Formerly opsValue
            console.log(`city code value: ${cityCode}`); // Formerly abcValue
            console.log(`retry value: ${retryValue}`);
            return cityCode; // Formerly abcValue
        } else {
            console.log('Please provide city code arguments after "--".');
        }
    }

    // below code to get the city code value from command line when city code is passed with named variable

    // async getCityCodeValueFromCommandLine() {
    //     // Get the arguments after "--" in the npm run cucumber command.
    //     console.log("argv:",process.argv)
    //     const args = process.argv.slice(process.argv.indexOf('--') + 1);
    
    //     if (args.length > 0) {
    //         let cityCode = ''; 

    //         for (let i = 2; i < args.length; i++) {
    //             if(args[i].startsWith('citycode')){
    //                 const cityCodeString = args[i].split("=",2);
    //                 cityCode = cityCodeString[1]
    //                 break
    //             }
    //         }
    //         console.log(`city code value: ${cityCode}`); 
    //         return cityCode;
    //     } else {
    //         console.log('Please provide city code arguments after "--".');
    //     }
    // }

    // below code to get the arg values from commander lib program object. This works with parallel execution as well.
    // async getCityCodeValueFromProgramCommander() {
    //     // Get the arguments after "--" in the npm run cucumber program commander command.
    //     const executionOption = await executionOptions
    //     const executionCityCode = await global.city
    //     const a = citycode
    //     console.log("Starting execution with options :", executionOption)
    //     console.log("Starting execution for city :",executionCityCode)
    //     return executionCityCode
    // }
    

    async getCityCodeValueforExecution(){
        let cityCodeValue = await this.getCityCodeValueFromCommandLine()
        //let cityCodeValue = await this.getCityCodeValueFromProgramCommander()
        if(cityCodeValue == "" || cityCodeValue == "@rerun.txt"){
        cityCodeValue = await process.env.cityCode 
        await log.info(`As no specific city selected, starting execution in STG environment:${cityCodeValue}`)
        return cityCodeValue
        }
        else{
            await log.info(`Specific city selected for execution: ${cityCodeValue}`)
            return cityCodeValue
        }
    }

    async globalSearch(val) {
        await this.click(this.globalSearchTextBox)
        await this.enter(this.globalSearchTextBox, val)
        await this.pressEnter()
        await this.handleLoadingSpinner()
    }

    async selectRowFromMasterList(rowNumber) {
        const selectRow = (await this.masterListRecord).replace("[1]", `[${await rowNumber}]`)
        await this.click(selectRow)
    }

    async clickOnColumnSort(column: string) {
        this.clickPosition(`//span[text()='${column}']`, 1, 1)
        await this.handleLoadingSpinner()
    }
    async newUpdateButton(){
        await this.clickPosition(this.updateButtonEditService, 1, 1) 
    }

    async verifyLabelDisplayed(labelName,state){
        const labelLoc = (this.labelLocator).replace("Initial Deposit Amount",labelName)
        await this.verifyVisibility(labelLoc,state)
    }
    
    async navigateToFinancePage(){
        await this.wait(2000)
        await this.waitForLoad()
        // await this.click(this.FinanceTab)  
        // await this.wait(2000)
        await this.click(this.financeHubSettings)
        await this.wait(2000)
        await this.click(this.financeAccounting)
        await this.wait(2000) 
    }

    async SelectMasterPageFilter(filterType,valueToSelect){
            const filterLocator = this.MasterPagrFilters.replace("All Services",filterType)
            await this.selectDropdownwithStrictMatch(filterLocator, this.listOptions, valueToSelect)
            await this.handleLoadingSpinner()
            await this.wait(1000)
        }
    
    async verifyLabelValues(labelName,value){
        const labelValueLoc = (this.labelValueLocator).replace("Initial Deposit Amount",labelName)
        await this.verifyElementTrimmedText(labelValueLoc,value)
    }

    async verifyLabelValuesIgnoringCommas(labelName,value){
        const labelValueLoc = (this.labelValueLocator).replace("Initial Deposit Amount",labelName)
        await this.verifyElementValueIgnoreCommas(labelValueLoc,value)
    }

      async getTestEnvironmentURL(){
        const url = await this.getUrl()
        const testEnvironment = url.split("/u/utility-billing",2)
        console.log('Test Environment:', testEnvironment[0]);
        await jsonUtil.appendConfigJsonData(`configData.json`,{testEnvironment: testEnvironment[0]})
        return testEnvironment[0]  
    }
  
    async getUITableColumns(loc=this.UITableColumns){
        return await this.getTextsInList(loc)
    }

    async getTablesFirstRowData(loc=this.tablesFirstRowData,row="1"){
        const desiredRowloc = loc.replace("1",row)
        return await this.getTextsInList(desiredRowloc)
    } 

    async getTablesFirstRowDataforSpecificAccount(accountNumber, loc=this.accountSpecificData,row="1"){
        const desiredAccountLoc = loc.replace("10086503",accountNumber)
        const desiredRowloc = desiredAccountLoc.replace(")[1]",`)[${row}]`)
        return await this.getTextsInList(desiredRowloc)
    } 

    async getTablesFirstRowDataStringForPDFValidation(loc=this.tablesFirstRowData,row="1"){
        const desiredRowloc = loc.replace("1",row)
        return await this.getTextsInListForPDFValidation(desiredRowloc)
    } 

    async selectDateRangeFromCalender(startMonth,startDate,endMonth, endDate,calenderLoc=this.selectCalender){
        await this.click(calenderLoc)
        const startMonthVisibilityLoc = (this.calenderStartMonthVisibility).replace("July",startMonth)
        const startDateLoc = (this.selectStartMonthDate).replace("5",startDate)
        const endMonthVisibilityLoc = (this.calenderEndMonthVisibility).replace("August",endMonth)
        const endDateLoc = (this.selectEndMothDate).replace("7",endDate)
        for(let i=0; i<12; i++){
            if(!await this.isVisible(startMonthVisibilityLoc)){
                await this.click(this.calenderPreviousButton)
            }
            else{
                await log.info(`Desired start Month has been selected: ${startMonth}`)
                break
            }
        }
        await this.forceclick(startDateLoc)
        await log.info(`Desired start date has been selected: ${startDate}`)
        
        for(let i=0; i<12; i++){
            if(!await this.isVisible(endMonthVisibilityLoc)){
                await this.click(this.calenderNextButton)
            }
            else{
                await log.info(`Desired end Month has been selected: ${endMonth}`)
                break
            }
        }
        await this.forceclick(endDateLoc)
        await log.info(`Desired end date has been selected: ${endDate}`)
    }
    async response(res) {
        let resbody = await res.body();
        global.slackresponse = JSON.parse(await mime.decodeBase64(resbody));
        await log.info(await global.slackresponse);
        return global.slackresponse
      }

    // To send a message to Slack using playwright request
//     async sendSlackMessage(message: string) {
//         const webhookUrl = 'https://hooks.slack.com/services/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';
//         const req = await request.newContext({baseURL:webhookUrl})
//         const msg = {
//             text: message, // Use the provided message parameter here
//           };
//         const channelId = 'ui-automation-results';
//     try {
//       const response = await req.post(webhookUrl, {
//         data: msg,
//       });
//       await log.info('Message sent to Slack');
//     //   console.log('Message sent to Slack:', response.status);
//     } catch (error:any) {
//       console.error('Error sending message to Slack:', error.message);
//     }
// }

async makePostRequestWithAttachment(fileType: string, filePath: string): Promise<void> {
    const webhookUrl = 'https://hooks.slack.com/services/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';
    const req = await request.newContext({baseURL:webhookUrl})
    const type = fileType;
    const fileObj = fs.readFileSync(filePath); // Read the file synchronously
    const fileName = path.basename(filePath); // Extract the filename from the path
  
    const res = await req.post(webhookUrl, {
      multipart: {
        file: {
          name: fileName,
          mimeType: type,
          buffer: fileObj,
        },
      },
    });
  
    await this.response(res);
  }

    // Slack Integration Using Axios
    async sendSlackMessage(message: string) {
        // const webhookUrl = 'https://hooks.slack.com/services/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';
        const webhookUrl = 'https://hooks.slack.com/services/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'
        const channelId = 'ui-automation-results';
    try {
      const response = await axios.post(webhookUrl, {
        text: message,
      });
  
      console.log('Message sent to Slack:', response.data);
    } catch (error:any) {
      console.error('Error sending message to Slack:', error.message);
    }
    }
 

  async uploadSlackReport(message: string, filePath: string) {
    const token = 'xoxp-5115602510288-5560466739619-5829040983622-2486ebe7b77c6d8838c746907ae89903'; 
    const channelId = 'C05QDDJBHB5'; 
    const web = new WebClient(token);
  
    try {
      const result = await web.files.uploadV2({
        channels: channelId,
        initial_comment: message,
        file: fs.createReadStream(filePath),
        filename: 'TestExecutionReport.html', 
      });
  
      console.log('file sent to Slack:');
    } catch (error) {
      console.error('Error sending message to Slack:', error);
    }
  }

  async sendMessageToSlack(message) {
    const token = 'xoxb-5115602510288-5869721550198-PHQc4ChqkBUIjyZQJt1nSl9A'; 
    const channelId = 'C05QDDJBHB5'; 
    const web = new WebClient(token);
  
    try {
      const result = await web.chat.postMessage({
        channel: channelId,
        text: message,
      });
  
      //console.log('Message sent to Slack:', result);
    } catch (error) {
      console.error('Error sending message to Slack:', error);
    }
  }

  async getExecutionCityName(){
     const cityName = await this.getTrimmedText(this.executionCityName)
     await jsonUtil.appendConfigJsonData(`configData.json`,{cityName: cityName})
     return cityName
  }

  
  async navigateToBillings() {
    await this.wait(10000)
    if (await this.isVisible(this.utilitySettingsTab)) {
         await this.click(this.utilitySettingsTab)
         await this.click(this.billingTab)
     } else {
         await this.click(this.utilityBillingTab)
         await this.wait(2000)
         await this.click(this.utilitySettingsTab)
         await this.click(this.billingTab)
     }
}
async removeoverlappingImageandClickButton(buttonSelector,imageSelector){
    let cityCodeValue1= await this.getCityCodeValueforExecution()
    if(cityCodeValue1?.includes("qa")){
        await global.page.evaluate(
            ({ buttonSelector }) => {
              const button = document.querySelector(buttonSelector) as HTMLElement | null;
    
              if (button) {
                button.click();
              }
            },
            { buttonSelector } // Pass the selectors as an object
    
          );
    }
    else{
    // Use JavaScript to hide the image element
    await global.page.evaluate(
        ({ buttonSelector, imageSelector }) => {
          const button = document.querySelector(buttonSelector) as HTMLElement | null;
          const image = document.querySelector(imageSelector) as HTMLElement | null;

          if (button && image) {
            // Hide the image by setting its style to "display: none;"
            image.style.display = 'none';
            // Now, click the button
            button.click();
          }
        },
        { buttonSelector, imageSelector } // Pass the selectors as an object

      );
    }
    
    }

    /**
     * Converts a dollar amount to a number for mathematical operations
     * @param dollarAmount The amount to be converted to a number
     * @returns A number with all commas, and dollar signs removed
     */
    dollarAmountToNumber(dollarAmount: string): number {
      const regex = /\$([0-9,]+(\.[0-9]{1,2})?)/;
      const match = dollarAmount.match(regex);

      if (match) {
        const numericValue = parseFloat(match[1].replace(/,/g, ''))
        return numericValue
      } else {
        throw new Error(`Invalid dollar amount: ${dollarAmount}`);
      }
      
    }
    async getFutureDate(daysLater: number): Promise<string> {
        const today = new Date();
        const futureDate = new Date(today.getTime() + daysLater * 24 * 60 * 60 * 1000);
        
        const month = (futureDate.getMonth() + 1).toString().padStart(2, '0'); 
        const day = futureDate.getDate().toString().padStart(2, '0');
        const year = futureDate.getFullYear();
    
        return `${month}/${day}/${year}`;
    }

    getRandomAddress() {
      const address = chance.address({ country_code: 'US' })
      return address
    }

    getRandomState() {
      const state = chance.state({ full: true })
      return state
    }

    getRandomCity() {
      const city = chance.city()
      return city
    }

    getRandomZipCode() {
      const zipCode = chance.zip({ country: 'US' })
      return zipCode
    }
   
    async getTestingCityNameFinance() {
        const cityCode = process.env.cityCode
        let cityName;

        switch (cityCode) {
            case "mnd_sep_22_qa":
                cityName = 'Moundridge'
                return cityName
            case "eff_july_21":
                cityName = 'Effingham'
                return cityName
            case "wil001":
                cityName = 'Williamson'
                return cityName
            case "for_july_02":
                cityName = 'Fort Pierre'
                return cityName
            case "key001":
                cityName = 'Keystone'
                return cityName
            case "mil_july_05":
                cityName = 'Miller'
                return cityName
            case "bat_july_17_qa":
                cityName = 'Bates'
                return cityName
            case "gre_jun_28":
                cityName = 'Greenup'
                return cityName
            case "len_july_12":
                cityName = 'Lennox'
                return cityName
            case "hia_002":
                cityName = 'Hiawatha'
                return cityName
            case "lak_july_08":
                cityName = 'Lakeview'
                return cityName
            case "fon001":
                cityName = 'Fonda'
                return cityName
            case "goo_july_10":
                cityName = 'Goodman'
                return cityName
            default:
                throw new Error(`Incorrect city name for upload functionality, create folder with the city name and upload the respected files: ${cityName}`);
        }
    }
    async verifyLabelDisplayedFinance(labelName, state) {
        const labelLoc = (this.labelLocator).replace("Initial Deposit Amount", labelName)
        await this.verifyVisibility(labelLoc, state)
    }
    
    async verifyLabelValuesIgnoringCommasFinance(labelName, value) {
        const labelValueLoc = (this.labelValueLocator).replace("Initial Deposit Amount", labelName)
        await this.verifyElementValueIgnoreCommas(labelValueLoc, value)
    }
    async captureBearerTokenFiance() {
        let captured = false;
        // Capture network requests
        await global.page.route('**', async (route) => {
            if (captured) {
                route.continue();
                return;
            }
            route.continue();
            const headers = await route.request().headers();
            const authorizationHeader = headers['authorization'];
            if (authorizationHeader && authorizationHeader.startsWith('Bearer ')) {
                const token = authorizationHeader.substring('Bearer '.length);
                console.log('Bearer token:', token);
                captured = true;
            }
        });
    }
      // Get Bearer token from URL
      async bearerToken() {
        const url = await this.getUrl()
        const token1 = url.split("token=", 2)
        const token = token1[1].split("&fdCityName", 2)
        console.log('Bearer token:', token[0]);
        return token[0]
  
    }

    async captureBearerToken() {
        let captured = false;
      
        // Capture network requests
        await global.page.route('**', async (route) => {
          if (captured) {
            route.continue();
            return;
          }
      
          route.continue();
          const headers = await route.request().headers();
          const authorizationHeader = headers['authorization'];
      
          if (authorizationHeader && authorizationHeader.startsWith('Bearer ')) {
            const token = authorizationHeader.substring('Bearer '.length);
            console.log('Bearer token:', token);
            captured = true;
          }
        });
      }
   

      /** 
 * @deprecated 
 */
async removeoverlappingImageandClickButton_OPS(buttonSelector,imageSelector){
    let cityCodeValue1= await this.getCityCodeValueforExecution()
    if(cityCodeValue1?.includes("qa")){
        await global.page.evaluate(
            ({ buttonSelector }) => {
              const button = document.querySelector(buttonSelector) as HTMLElement | null;
    
              if (button) {
                button.click();
              }
            },
            { buttonSelector } // Pass the selectors as an object
    
          );
    }
    else{
    // Use JavaScript to hide the image element
    await global.page.evaluate(
        ({ buttonSelector, imageSelector }) => {
          const button = document.querySelector(buttonSelector) as HTMLElement | null;
          const image = document.querySelector(imageSelector) as HTMLElement | null;

          if (button && image) {
            // Hide the image by setting its style to "display: none;"
            image.style.display = 'none';
            // Now, click the button
            button.click();
          }
        },
        { buttonSelector, imageSelector } // Pass the selectors as an object

      );
    }
    
    }

    async approveTStoasterMessage() {
        await this.waitForSelector(this.approveTStoaster, 30000)
        const msg = await (await this.getInnerText(this.approveTStoaster)).trim();
        await log.info(`Toaster Message displayed as : ${msg}`)
        await this.waitForSelectorHidden(this.approveTStoaster, 30000)
        return msg
    }

    async clickOnColumnSortHrhubMain(column: string) {
        await this.click(`//span[text()='${column}']`)
        await this.handleLoadingSpinner()
    }

    async getTestingCityNameHrhubMain() {
        const cityCode = process.env.cityCode
        let cityName;
        
        switch (cityCode) {
            case "mnd_sep_22_qa":
                cityName = 'Moundridge'
                return cityName
            case "eff_july_21":
                cityName = 'Effingham'
                return cityName
            case "wil001":
                cityName = 'Williamson'
                return cityName
            case "for_july_02":
                cityName = 'Fort Pierre'
                return cityName
            case "key001":
                cityName = 'Keystone'
                return cityName
            case "mil_july_05":
                cityName = 'Miller'
                return cityName
            case "bat_july_17_qa":
                cityName = 'Bates'
                return cityName
            case "gre_jun_28":
                cityName = 'Greenup'
                return cityName
            case "len_july_12":
                cityName = 'Lennox'
                return cityName
            case "hia_002":
                cityName = 'Hiawatha'
                return cityName
            case "lak_july_08":
                cityName = 'Lakeview'
                return cityName
            case "fon001":
                cityName = 'Fonda'
                return cityName
            case "goo_july_10":
                cityName = 'Goodman'
                return cityName
            default:
                throw new Error(`Incorrect city name for upload functionality, create folder with the city name and upload the respected files: ${cityName}`);
        }
    }
    async captureBearerTokenHrhubMain() {
        let captured = false;
      
        // Capture network requests
        await global.page.route('**', async (route) => {
          if (captured) {
            route.continue();
            return;
          }
      
          route.continue();
          const headers = await route.request().headers();
          const authorizationHeader = headers['authorization'];
      
          if (authorizationHeader && authorizationHeader.startsWith('Bearer ')) {
            const token = authorizationHeader.substring('Bearer '.length);
            console.log('Bearer token:', token);
            captured = true;
          }
        });
      }
      // Get Bearer token from URL
    async bearerTokenHrhubMain(){
        const url = await this.getUrl()
        const token1 = url.split("token=",2)
        const token = token1[1].split("&fdCityName",2) 
        console.log('Bearer token:', token[0]);
        return token[0]  
    }
    async closeToastMessage(){
        if(await this.isVisible(this.toasterClose)){
            await this.click(this.toasterClose)
        }
      }
      async logOutCurrentUser() {
        if (await this.isVisible(this.userProfileIcon)) {
          await this.click(this.userProfileIcon)
          await this.click(this.logOut);
        } else {
          await this.click(this.hubUserProfile)
          await this.click(this.hubLogout)
        }
      }
    
      /**
       * To be used when the login for an Employee is static (can use a DataTable)
       * @param data The employees username, password, and agency for logging in
       */
      async logInToEmployeeUsingCreds(data: DataTable) {
        const loginInfo: string[][] = data.rows()
        const username: string = loginInfo[0][0]
        const password: string = loginInfo[0][1]
        const agency: string = loginInfo[0][2]
    
        await this.enter(this.emailField, username)
        await this.enter(this.passwordField, password)
        await this.click(this.loginBtn)
        await this.wait(3000)
    
        if (await this.isVisible(this.agencySelect)) {
          this.selectAgencyFromMultipleAgencies(agency)
          await this.wait(8000)
        }
      }
    
      /**
       * To be used when the Employee credentials are not static
       * @param username The email of the Employee
       * @param password The password of the Employee
       */
      async logInToEmployee(username: string, password: string, agency?: string) {
        await this.enter(this.emailField, username)
        await this.enter(this.passwordField, password)
        await this.click(this.loginBtn)
        await this.wait(3000)
    
        if (await this.isVisible(this.agencySelect) && agency !== undefined) {
          this.selectAgencyFromMultipleAgencies(agency)
          await this.wait(8000)
        }
    
        while(await this.isVisible(this.closeLoginPopUp)) {
          await this.click(this.closeLoginPopUp)
          await this.wait(500)
        }
      }
    
      async logInToEmployeeUsingFile(employeeName: string, fileName: string, agency?: string) {
        const jsonData = await jsonUtil.readData(`/HR_login_data/${fileName}.json`)
        let employee = jsonData.employees.filter(function(item: { name: string; }) { return item.name === employeeName })
    
        await this.enter(this.emailField, employee[0].email)
        await this.wait(2000)
        await this.enter(this.passwordField, employee[0].password)
        await this.wait(2000)
        await this.click(this.loginBtn)
        await this.wait(5000)
    
        if (await this.isVisible(this.agencySelect) && agency !== undefined) {
          this.selectAgencyFromMultipleAgencies(agency)
          await this.wait(8000)
        }
    
        while(await this.isVisible(this.closeLoginPopUp)) {
          await this.click(this.closeLoginPopUp)
          await this.wait(500)
        }
      }
    
      /**
       * When logging in with credentials that have been used in other cities, this method will select
       * the city that you want to log in to
       * @param agencyToSelect Desired city to log in to
       */
      async selectAgencyFromMultipleAgencies(agencyToSelect: string) {
        await this.click(this.agencySelect)
        await this.wait(500)
        let position = 0;
        const elements = await this.getTextsInList(this.agencySelectDropdownOptions)
        elements.forEach(async (element) => {
          if (element === agencyToSelect) {
            for (let i = 0; i <= position; i++) {
              await this.pressKey('ArrowDown')
              await this.pressEnter()
            }
          } else {
            position++
          }
        })
        await this.click(this.loginBtn)
      }
      async clickOnColumnSortPlayRollCalculation(column: string) {
        await this.click(`//span[text()='${column}']`)
        await this.handleLoadingSpinner()
    }
    async captureBearerTokenPlayRollCalculation() {
        let captured = false;
      
        // Capture network requests
        await global.page.route('**', async (route) => {
          if (captured) {
            route.continue();
            return;
          }
      
          route.continue();
          const headers = await route.request().headers();
          const authorizationHeader = headers['authorization'];
      
          if (authorizationHeader && authorizationHeader.startsWith('Bearer ')) {
            const token = authorizationHeader.substring('Bearer '.length);
            console.log('Bearer token:', token);
            captured = true;
          }
        });
      }
      
     // Get Bearer token from URL
     async bearerTokenPlayRollCalculation(){
        const url = await this.getUrl()
        const token1 = url.split("token=",2)
        const token = token1[1].split("&fdCityName",2) 
        console.log('Bearer token:', token[0]);
        return token[0];  
    }
}




