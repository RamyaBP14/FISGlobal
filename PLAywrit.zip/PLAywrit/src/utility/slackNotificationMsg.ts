import { expect } from '@playwright/test'
import { LoggerUtil } from './logger'
import { PageBase } from './PageBase'
import axios from 'axios';
import { request } from "playwright";
import mime from "mime-lib";
import { WebClient } from '@slack/web-api';
import * as fs from 'fs';
import path from 'path';
import { errorMessage } from 'aws-sdk/clients/datapipeline';
// import {citycode, executionOptions} from '../../cucumber.js'


let log = new LoggerUtil()




export class slackNotificationMsg extends PageBase {
    

    async slackNotificationMessage(TestSuitName,TestExecutionCity,TestEnvironment,TotalTests,PassedTest,FailedTest,SkippedTest,AmbiguousTest){
        // * Test Execution Suit = ${TestSuitName}       \n
         // * Total Tests Executed = ${TotalTests}        \n                                           
        // * Total Tests Passed   = ${PassedTest}            * Total Tests Failed   = ${FailedTest}        \n                   
        // * Total Tests Skipped  = ${SkippedTest}           * Total Tests Ambiguous = ${AmbiguousTest}    \n        
        const currentTime = await this.getCurrentTime()
        const slackMessage = 
        `=============================Test Execution Details===============================================================
        *Test Execution City*   = *${TestExecutionCity}*  \n 
        *Test Environment*      = *${TestEnvironment}*    \n                     
        *Execution Date*        = *${currentTime}*         `;
        return slackMessage
    }


}