import { expect } from '@playwright/test'
import { LoggerUtil } from './logger'
import { PageBase } from './PageBase'
import { CommonUtils } from './commonUtils';
import * as path from 'path';
import { promises as fs } from 'fs';


let log = new LoggerUtil()

interface TaxBracket {
    min: number;
    max: number;
    base: number;
    rate: number;
    standardDeduction: number;
    divide: number;
}

export class PayrollUtils extends PageBase {

    async getPayPeriodforFrequency(frequency: string) {
        switch (frequency) {
            case "Weekly":
                return 52;
            case "Bi-weekly":
                return 26;
            case "Monthly":
                return 12;
            case "Semi-monthly":
                return 24;
            case "Quarterly":
                return 4;
            case "Semi-annual":
                return 2;
            case "Annual":
                return 1;
            default:
                throw new Error(`Unsupported frequency: ${frequency}`);
        }
    }

    async getStateAnnualTaxRate(state: string) {
        switch (state) {
            case "Colorado":
                return 4.40;
            case "Georgia":
                return 0;
            case "Illinois":
                return 4.95;
            case "Iowa":
                return 0;
            case "Kansas":
                return 0;
            case "Minnesota":
                return 0;
            default:
                throw new Error(`Unsupported state: ${state}`);
        }
    }

    async getStateCode(state: string) {
        switch (state) {
            case "Colorado":
                return "CO";
            case "Georgia":
                return "GA";
            case "Illinois":
                return "IL";
            case "Iowa":
                return "IA";
            case "Kansas":
                return "KS";
            case "Minnesota":
                return "MN";
            case "Missouri":
                return "MO";
            case "Nebraska":
                return "NE";
            case "Oklahoma":
                return "OK";
            case "New York":
                return "NY";
            case "Massachusetts":
                return "MA";
            case "North Dakota":
                return "ND";
            case "Wisconsin":
                return "WI";
            case "California":
                return "CA";
            case "Oregon":
                return "OR";
            case "Pennsylvania":
                return "PA";
            case "Connecticut":
                return "CT";
            case "New Hampshire":
                return "NH";
            case "Tennessee":
                return "TN";
            case "Florida":
                return "FL";
            case "Vermont":
                return "VT";
            case "Maine":
                return "ME";
            default:
                throw new Error(`Unsupported state: ${state}`);
        }
    }

    async getGeorgiaAnnualTax(fillingStatus: string, AnnualTaxableWageslessExemptionAllowance) {
        let annualTax
        annualTax = Number((AnnualTaxableWageslessExemptionAllowance * 0.0549).toFixed(2));
                        return annualTax;
        // switch (fillingStatus) {
        //     case "Single":
        //         switch (true) {
        //             case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 750:
        //                 annualTax = Number(((AnnualTaxableWageslessExemptionAllowance * 1) / 100).toFixed(2));
        //                 return annualTax;
        //             case AnnualTaxableWageslessExemptionAllowance >= 750 && AnnualTaxableWageslessExemptionAllowance < 2250:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 750) * 2) / 100 + 7.50).toFixed(2));
        //                 return annualTax;
        //             case AnnualTaxableWageslessExemptionAllowance >= 2250 && AnnualTaxableWageslessExemptionAllowance < 3750:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 2250) * 3) / 100 + 37.50).toFixed(2));
        //                 return annualTax;
        //             case AnnualTaxableWageslessExemptionAllowance >= 3750 && AnnualTaxableWageslessExemptionAllowance < 5250:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 3750) * 4) / 100 + 82.50).toFixed(2));
        //                 return annualTax;
        //             case AnnualTaxableWageslessExemptionAllowance >= 5250 && AnnualTaxableWageslessExemptionAllowance < 7000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 5250) * 5) / 100 + 142.50).toFixed(2));
        //                 return annualTax;
        //             case AnnualTaxableWageslessExemptionAllowance >= 7000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 7000) * 5.75) / 100 + 230).toFixed(2));
        //                 return annualTax;
        //             default:
        //                 throw new Error(`Unsupported Tax for : ${AnnualTaxableWageslessExemptionAllowance}`);
        //         }

        //     case "Married Filing Joint, both spouses working":
        //         switch (true) {
        //             case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 500:
        //                 annualTax = Number(((AnnualTaxableWageslessExemptionAllowance * 1) / 100).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 500 && AnnualTaxableWageslessExemptionAllowance < 1500:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 500) * 2) / 100 + 5).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 1500 && AnnualTaxableWageslessExemptionAllowance < 2500:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 1500) * 3) / 100 + 25).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 2500 && AnnualTaxableWageslessExemptionAllowance < 3500:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 2500) * 4) / 100 + 55).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 3500 && AnnualTaxableWageslessExemptionAllowance < 5000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 3500) * 5) / 100 + 95).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 5000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 5000) * 5.75) / 100 + 170).toFixed(2))
        //                 return annualTax

        //             default:
        //                 throw new Error(`Unsupported Tax for : ${AnnualTaxableWageslessExemptionAllowance}`);
        //         }

        //     case "Married Filing Joint, one spouse working":
        //         switch (true) {
        //             case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 1000:
        //                 annualTax = Number(((AnnualTaxableWageslessExemptionAllowance * 1) / 100).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 1000 && AnnualTaxableWageslessExemptionAllowance < 3000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 500) * 2) / 100 + 10).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 3000 && AnnualTaxableWageslessExemptionAllowance < 5000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 3000) * 3) / 100 + 50).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 5000 && AnnualTaxableWageslessExemptionAllowance < 7000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 5000) * 4) / 100 + 110).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 7000 && AnnualTaxableWageslessExemptionAllowance < 10000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 7000) * 5) / 100 + 190).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 10000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 10000) * 5.75) / 100 + 340).toFixed(2))
        //                 return annualTax
        //             default:
        //                 throw new Error(`Unsupported Tax for : ${AnnualTaxableWageslessExemptionAllowance}`);
        //         }

        //     case "Married Filing Separate":
        //         switch (true) {
        //             case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 500:
        //                 annualTax = Number(((AnnualTaxableWageslessExemptionAllowance * 1) / 100).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 500 && AnnualTaxableWageslessExemptionAllowance < 1500:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 500) * 2) / 100 + 5).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 1500 && AnnualTaxableWageslessExemptionAllowance < 2500:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 1500) * 3) / 100 + 25).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 2500 && AnnualTaxableWageslessExemptionAllowance < 3500:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 2500) * 4) / 100 + 55).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 3500 && AnnualTaxableWageslessExemptionAllowance < 5000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 3500) * 5) / 100 + 95).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 5000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 5000) * 5.75) / 100 + 170).toFixed(2))
        //                 return annualTax
        //             default:
        //                 throw new Error(`Unsupported Tax for : ${AnnualTaxableWageslessExemptionAllowance}`);
        //         }

        //     case "Head of Household":
        //         switch (true) {
        //             case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 1000:
        //                 annualTax = Number(((AnnualTaxableWageslessExemptionAllowance * 1) / 100).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 1000 && AnnualTaxableWageslessExemptionAllowance < 3000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 500) * 2) / 100 + 10).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 3000 && AnnualTaxableWageslessExemptionAllowance < 5000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 3000) * 3) / 100 + 50).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 5000 && AnnualTaxableWageslessExemptionAllowance < 7000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 5000) * 4) / 100 + 110).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 7000 && AnnualTaxableWageslessExemptionAllowance < 10000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 7000) * 5) / 100 + 190).toFixed(2))
        //                 return annualTax
        //             case AnnualTaxableWageslessExemptionAllowance >= 10000:
        //                 annualTax = Number((((AnnualTaxableWageslessExemptionAllowance - 10000) * 5.75) / 100 + 340).toFixed(2))
        //                 return annualTax
        //             default:
        //                 throw new Error(`Unsupported Tax for : ${AnnualTaxableWageslessExemptionAllowance}`);
        //         }
        //     default:
        //         throw new Error(`Unsupported fillingStatus: ${fillingStatus}`);
        // }
    }


    async getIowaAnnualTax(AnnualTaxableWageslessExemptionAllowance) {

        let annualTax: number = 0;
        switch (true) {
            case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 4896:
                annualTax = Number((AnnualTaxableWageslessExemptionAllowance * 0.044).toFixed(2));
                return annualTax;
            case AnnualTaxableWageslessExemptionAllowance >= 4896 && AnnualTaxableWageslessExemptionAllowance < 24480:
                annualTax = Number((215.42 + (AnnualTaxableWageslessExemptionAllowance - 4896) * 0.0482).toFixed(2));
                return annualTax;
            case AnnualTaxableWageslessExemptionAllowance >= 24480:
                annualTax = Number((1159.37 + (AnnualTaxableWageslessExemptionAllowance - 24480) * 0.057).toFixed(2));
                return annualTax;
            default:
                throw new Error(`Unsupported Tax for: ${AnnualTaxableWageslessExemptionAllowance}`);
        }
    }

    async getMissouriAnnualTax(AnnualTaxableWageslessExemptionAllowance) {
        switch (true) {
            case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance <= 1273:
                return 0;
            case AnnualTaxableWageslessExemptionAllowance > 1273 && AnnualTaxableWageslessExemptionAllowance <= 2546:
              return Number(((AnnualTaxableWageslessExemptionAllowance - 1273) * 0.02 + 0).toFixed(2));
            case AnnualTaxableWageslessExemptionAllowance > 2546 && AnnualTaxableWageslessExemptionAllowance <= 3819:
              return Number(((AnnualTaxableWageslessExemptionAllowance - 2546) * 0.025 + 25).toFixed(2));
            case AnnualTaxableWageslessExemptionAllowance > 3819 && AnnualTaxableWageslessExemptionAllowance <= 5092:
              return Number(((AnnualTaxableWageslessExemptionAllowance - 3819) * 0.03 + 57).toFixed(2));
            case AnnualTaxableWageslessExemptionAllowance > 5092 && AnnualTaxableWageslessExemptionAllowance <= 6365:
              return Number(((AnnualTaxableWageslessExemptionAllowance - 5092) * 0.035 + 95).toFixed(2));
            case AnnualTaxableWageslessExemptionAllowance > 6365 && AnnualTaxableWageslessExemptionAllowance <= 7638:
              return Number(((AnnualTaxableWageslessExemptionAllowance - 6365) * 0.04 + 140).toFixed(2));
            case AnnualTaxableWageslessExemptionAllowance > 7638 && AnnualTaxableWageslessExemptionAllowance <= 8911:
              return Number(((AnnualTaxableWageslessExemptionAllowance - 7638) * 0.045 + 191).toFixed(2));
            case AnnualTaxableWageslessExemptionAllowance > 8911:
                return Number(((AnnualTaxableWageslessExemptionAllowance - 8911) * 0.048 + 248).toFixed(2));
            default:
                throw new Error(`Unsupported Tax for : ${AnnualTaxableWageslessExemptionAllowance}`);
        }
    }

    async getKansasAnnualTax(fillingStatus: string, AnnualTaxableWageslessExemptionAllowance) {
        switch (fillingStatus) {
            case "Single":
                switch (true) {
                    case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance <= 3500:
                        return 0;
                    case AnnualTaxableWageslessExemptionAllowance > 3500 && AnnualTaxableWageslessExemptionAllowance <= 18500:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 3500) * 0.031).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 18500 && AnnualTaxableWageslessExemptionAllowance <= 33500:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 18500) * 0.0525 + 465).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 33500:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 33500) * 0.057 + 1252.5).toFixed(2));
                    default:
                        throw new Error(`Unsupported Tax for : ${AnnualTaxableWageslessExemptionAllowance}`);
                }

            case "Joint":
                switch (true) {
                    case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance <= 8000:
                        return Number(((AnnualTaxableWageslessExemptionAllowance * 0) / 100).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 8000 && AnnualTaxableWageslessExemptionAllowance <= 38000:
                        return Number((((AnnualTaxableWageslessExemptionAllowance - 8000) * 3.1) / 100 + 0).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 38000 && AnnualTaxableWageslessExemptionAllowance <= 68000:
                        return Number((((AnnualTaxableWageslessExemptionAllowance - 38000) * 5.25) / 100 + 930).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 68000:
                        return Number((((AnnualTaxableWageslessExemptionAllowance - 68000) * 5.7) / 100 + 2505).toFixed(2));
                    default:
                        throw new Error(`Unsupported Tax for: ${AnnualTaxableWageslessExemptionAllowance}`);
                }
            default:
                throw new Error(`Unsupported fillingStatus: ${fillingStatus}`);
        }
    }

    async getMinnesotaAnnualTax(fillingStatus: string, AnnualTaxableWageslessExemptionAllowance) {
        switch (fillingStatus) {
            case "Single":
                switch (true) {
                    case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance <= 4475:
                        return 0;
                    case AnnualTaxableWageslessExemptionAllowance > 4475 && AnnualTaxableWageslessExemptionAllowance <= 36165:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 4475) * 0.0535).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 36165 && AnnualTaxableWageslessExemptionAllowance <= 108565:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 36165) * 0.068 + 1695.42).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 108565 && AnnualTaxableWageslessExemptionAllowance <= 197715:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 108565) * 0.0785 + 6618.62).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 197715:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 197715) * 0.0985 + 13616.90).toFixed(2));
                    default:
                        throw new Error(`Unsupported Tax for : ${AnnualTaxableWageslessExemptionAllowance}`);
                }

            case "Married":
                switch (true) {
                    case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance <= 14000:
                        return 0;
                    case AnnualTaxableWageslessExemptionAllowance > 14000 && AnnualTaxableWageslessExemptionAllowance <= 60330:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 14000) * 0.0535).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 60330 && AnnualTaxableWageslessExemptionAllowance <= 198040:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 60330) * 0.068 + 2478.66).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 198040 && AnnualTaxableWageslessExemptionAllowance <= 335450:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 198040) * 0.0785 + 11842.94).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 335450:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 335450) * 0.0985 + 22629.63).toFixed(2));
                    default:
                        throw new Error(`Unsupported Tax for : ${AnnualTaxableWageslessExemptionAllowance}`);
                }
            default:
                throw new Error(`Unsupported fillingStatus: ${fillingStatus}`);
        }
    }

    async getNebraskaAnnualTax(fillingStatus: string, AnnualTaxableWageslessExemptionAllowance) {
        switch (fillingStatus) {
            case "Single":
                switch (true) {
                    case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance <= 3210:
                        return 0;
                    case AnnualTaxableWageslessExemptionAllowance > 3210 && AnnualTaxableWageslessExemptionAllowance <= 6290:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 3210) * 0.0226).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 6290 && AnnualTaxableWageslessExemptionAllowance <= 20440:
                        return Number((69.61 + (AnnualTaxableWageslessExemptionAllowance - 6290) * 0.0322).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 20440 && AnnualTaxableWageslessExemptionAllowance <= 29620:
                        return Number((525.24 + (AnnualTaxableWageslessExemptionAllowance - 20440) * 0.0491).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 29620 && AnnualTaxableWageslessExemptionAllowance <= 37610:
                        return Number((975.98 + (AnnualTaxableWageslessExemptionAllowance - 29620) * 0.0577).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 37610 && AnnualTaxableWageslessExemptionAllowance <= 70630:
                        return Number((1437.00+ (AnnualTaxableWageslessExemptionAllowance - 37610) * 0.0594).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 70630:
                        return Number((3398.39 + (AnnualTaxableWageslessExemptionAllowance - 70630) * 0.0610).toFixed(2));
                    default:
                        throw new Error(`Unsupported Tax for : ${AnnualTaxableWageslessExemptionAllowance}`);
                }

            case "Married":
                switch (true) {
                    case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance <= 7680:
                        return 0;
                    case AnnualTaxableWageslessExemptionAllowance > 7680 && AnnualTaxableWageslessExemptionAllowance <= 12190:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 7680) * 0.0226).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 12190 && AnnualTaxableWageslessExemptionAllowance <= 30360:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 12190) * 0.0322 + 101.93).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 30360 && AnnualTaxableWageslessExemptionAllowance <= 47230:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 30360) * 0.0491 + 687.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 47230 && AnnualTaxableWageslessExemptionAllowance <= 58600:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 47230) * 0.0577 + 1515.32).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 58600 && AnnualTaxableWageslessExemptionAllowance <= 77710:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 58600) * 0.0594 + 2171.37).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 77710:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 77710) * 0.0610 + 3306.50).toFixed(2));
                    default:
                        throw new Error(`Unsupported Tax for : ${AnnualTaxableWageslessExemptionAllowance}`);
                }
            default:
                throw new Error(`Unsupported fillingStatus: ${fillingStatus}`);
        }
    }

    async getOklahomaAnnualTax(fillingStatus: string, AnnualTaxableWageslessExemptionAllowance) {
        switch (fillingStatus) {
            case "Single":
                switch (true) {
                    case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance <= 6350:
                        return 0;
                    case AnnualTaxableWageslessExemptionAllowance > 6350 && AnnualTaxableWageslessExemptionAllowance <= 7350:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 6350) * 0.0025).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 7350 && AnnualTaxableWageslessExemptionAllowance <= 8850:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 7350) * 0.0075 + 2.5).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 8850 && AnnualTaxableWageslessExemptionAllowance <= 10100:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 8850) * 0.0175 + 13.75).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 10100 && AnnualTaxableWageslessExemptionAllowance <= 11250:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 10100) * 0.0275 + 35.63).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 11250 && AnnualTaxableWageslessExemptionAllowance <= 13550:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 11250) * 0.0375 + 67.25).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 13550:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 13550) * 0.0475 + 153.50).toFixed(2));
                    default:
                        throw new Error(`Unsupported Tax for: ${AnnualTaxableWageslessExemptionAllowance}`);
                }

            case "Married":
                switch (true) {
                    case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance <= 12700:
                        return 0;
                    case AnnualTaxableWageslessExemptionAllowance > 12700 && AnnualTaxableWageslessExemptionAllowance <= 14700:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 12700) * 0.0025).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 14700 && AnnualTaxableWageslessExemptionAllowance <= 17700:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 14700) * 0.0075 + 5).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 17700 && AnnualTaxableWageslessExemptionAllowance <= 20200:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 17700) * 0.0175 + 27.5).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 20200 && AnnualTaxableWageslessExemptionAllowance <= 22500:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 20200) * 0.0275 + 71.25).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 22500 && AnnualTaxableWageslessExemptionAllowance <= 27100:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 22500) * 0.0375 + 134.5).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance > 27100:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 27100) * 0.0475 + 307).toFixed(2));
                    default:
                        throw new Error(`Unsupported Tax for : ${AnnualTaxableWageslessExemptionAllowance}`);
                }
            default:
                throw new Error(`Unsupported fillingStatus: ${fillingStatus}`);
        }
    }

    //Is done
    async getNewYorkAnnualTax(fillingStatus: string, AnnualTaxableWageslessExemptionAllowance) {
        switch (fillingStatus) {
            case "Single":
                switch (true) {
                    case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 8500:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 0) * 0.0400).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 8500 && AnnualTaxableWageslessExemptionAllowance < 11700:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 8500) * 0.0450 + 340.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 11700 && AnnualTaxableWageslessExemptionAllowance < 13900:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 11700) * 0.0525 + 484.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 13900 && AnnualTaxableWageslessExemptionAllowance < 80650:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 13900) * 0.0585 + 600.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 80650 && AnnualTaxableWageslessExemptionAllowance < 96800:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 80650) * 0.0625 + 4504.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 96800 && AnnualTaxableWageslessExemptionAllowance < 107650:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 96800) * 0.0732 + 5514.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 107650 && AnnualTaxableWageslessExemptionAllowance < 157650:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 107650) * 0.0782 + 6308.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 157650 && AnnualTaxableWageslessExemptionAllowance < 215400:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 157650) * 0.0675 + 10219.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 215400 && AnnualTaxableWageslessExemptionAllowance < 265400:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 215400) * 0.0994 + 14117.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 265400 && AnnualTaxableWageslessExemptionAllowance < 1077550:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 265400) * 0.0735 + 19085.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 1077550 && AnnualTaxableWageslessExemptionAllowance < 5000000:
                        return Number(((AnnualTaxableWageslessExemptionAllowance) * 0.1045).toFixed(2)); 
                    case AnnualTaxableWageslessExemptionAllowance >= 5000000 && AnnualTaxableWageslessExemptionAllowance < 25000000:
                        return Number(((AnnualTaxableWageslessExemptionAllowance) * 0.1110).toFixed(2)); 
                    case AnnualTaxableWageslessExemptionAllowance >= 25000000:
                        return Number(((AnnualTaxableWageslessExemptionAllowance) * 0.1170).toFixed(2));                   
                    default:
                        throw new Error(`Unsupported Tax for: ${AnnualTaxableWageslessExemptionAllowance}`);
                }

            case "Married":
                switch (true) {
                    case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 8500:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 0) * 0.0400).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 8500 && AnnualTaxableWageslessExemptionAllowance < 11700:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 8500) * 0.0450 + 340.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 11700 && AnnualTaxableWageslessExemptionAllowance < 13900:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 11700) * 0.0525 + 484.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 13900 && AnnualTaxableWageslessExemptionAllowance < 80650:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 13900) * 0.0585 + 600.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 80650 && AnnualTaxableWageslessExemptionAllowance < 96800:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 80650) * 0.0625 + 4504.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 96800 && AnnualTaxableWageslessExemptionAllowance < 107650:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 96800) * 0.0711 + 5514.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 107650 && AnnualTaxableWageslessExemptionAllowance < 157650:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 107650) * 0.0761 + 6285.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 157650 && AnnualTaxableWageslessExemptionAllowance < 211550:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 157650) * 0.0804 + 10090.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 211550 && AnnualTaxableWageslessExemptionAllowance < 323200:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 211550) * 0.0675 + 14425.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 323200 && AnnualTaxableWageslessExemptionAllowance < 373200:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 323200) * 0.1123 + 21961.00).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 373200 && AnnualTaxableWageslessExemptionAllowance < 1077500:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 373200) * 0.0735 + 27576.00).toFixed(2)); 
                    case AnnualTaxableWageslessExemptionAllowance >= 1077500 && AnnualTaxableWageslessExemptionAllowance < 2155350:
                        return Number(((AnnualTaxableWageslessExemptionAllowance - 1077500) * 0.0765 + 79346.00).toFixed(2)); 
                    case AnnualTaxableWageslessExemptionAllowance >= 2155350 && AnnualTaxableWageslessExemptionAllowance < 5000000:
                        return Number(((AnnualTaxableWageslessExemptionAllowance) * 0.1045).toFixed(2));
                    case AnnualTaxableWageslessExemptionAllowance >= 5000000 && AnnualTaxableWageslessExemptionAllowance < 25000000:
                        return Number(((AnnualTaxableWageslessExemptionAllowance) * 0.1110).toFixed(2)); 
                    case AnnualTaxableWageslessExemptionAllowance >= 25000000:
                        return Number(((AnnualTaxableWageslessExemptionAllowance) * 0.1170).toFixed(2));     
                    default:
                        throw new Error(`Unsupported Tax for : ${AnnualTaxableWageslessExemptionAllowance}`);
                }
            default:
                throw new Error(`Unsupported fillingStatus: ${fillingStatus}`);
        }
    }

    async getMassachusettsAnnualTax(AnnualTaxableWageslessExemptionAllowance) {
        if(AnnualTaxableWageslessExemptionAllowance <= 1053750){
            return Number((AnnualTaxableWageslessExemptionAllowance *0.05).toFixed(2))
        }else{
            return Number((52687.50 + ((AnnualTaxableWageslessExemptionAllowance - 1053750) * 0.09)).toFixed(2))
        }
    }

    async getNorthDakotaAnnualTax(fillingStatus: string,AnnualTaxableWageslessExemptionAllowance,version) {
        if (version == "2020 and later"){
            switch (fillingStatus) {
                case "Single":
                    switch (true) {
                        case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 52025:
                            return 0;
                        case AnnualTaxableWageslessExemptionAllowance >= 52025 && AnnualTaxableWageslessExemptionAllowance < 233275:
                            return Number(((AnnualTaxableWageslessExemptionAllowance - 52025)*0.0195).toFixed(2));
                        case AnnualTaxableWageslessExemptionAllowance >= 233275:
                            return Number((3534.38 + (AnnualTaxableWageslessExemptionAllowance - 233275)*0.025).toFixed(2));                
                        default:
                            throw new Error(`Unsupported Tax for: ${AnnualTaxableWageslessExemptionAllowance}`);
                    }
                case "Head of Household":
                    switch (true) {
                        case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 70900:
                            return 0;
                        case AnnualTaxableWageslessExemptionAllowance >= 70900 && AnnualTaxableWageslessExemptionAllowance < 261500:
                            return Number(((AnnualTaxableWageslessExemptionAllowance - 70900)*0.0195).toFixed(2));
                        case AnnualTaxableWageslessExemptionAllowance >= 261500:
                            return Number((3716.70 + (AnnualTaxableWageslessExemptionAllowance - 261500)*0.025).toFixed(2));                
                        default:
                            throw new Error(`Unsupported Tax for: ${AnnualTaxableWageslessExemptionAllowance}`);
                    }
                case "Married":
                    switch (true) {
                        case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 51975:
                            return 0;
                        case AnnualTaxableWageslessExemptionAllowance >= 51975 && AnnualTaxableWageslessExemptionAllowance < 152150:
                            return Number(((AnnualTaxableWageslessExemptionAllowance - 51975)*0.0195).toFixed(2));
                        case AnnualTaxableWageslessExemptionAllowance >= 152150:
                            return Number((1953.41 + (AnnualTaxableWageslessExemptionAllowance - 152150)*0.025).toFixed(2));                
                        default:
                            throw new Error(`Unsupported Tax for: ${AnnualTaxableWageslessExemptionAllowance}`);
                    }
                default:
                    throw new Error(`Unsupported fillingStatus: ${fillingStatus}`);
            }
        } else{
            switch (fillingStatus) {
                case "Single":
                    switch (true) {
                        case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 52025:
                            return 0;
                        case AnnualTaxableWageslessExemptionAllowance >= 52025 && AnnualTaxableWageslessExemptionAllowance < 233275:
                            return Number(((AnnualTaxableWageslessExemptionAllowance - 52025)*0.0195).toFixed(2));
                        case AnnualTaxableWageslessExemptionAllowance >= 233275:
                            return Number((3534.38 + (AnnualTaxableWageslessExemptionAllowance - 233275)*0.025).toFixed(2));                
                        default:
                            throw new Error(`Unsupported Tax for: ${AnnualTaxableWageslessExemptionAllowance}`);
                    }
                case "Head of Household":
                    switch (true) {
                        case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 70900:
                            return 0;
                        case AnnualTaxableWageslessExemptionAllowance >= 70900 && AnnualTaxableWageslessExemptionAllowance < 261500:
                            return Number(((AnnualTaxableWageslessExemptionAllowance - 70900)*0.0195).toFixed(2));
                        case AnnualTaxableWageslessExemptionAllowance >= 261500:
                            return Number((3716.70 + (AnnualTaxableWageslessExemptionAllowance - 261500)*0.025).toFixed(2));                
                        default:
                            throw new Error(`Unsupported Tax for: ${AnnualTaxableWageslessExemptionAllowance}`);
                    }
                case "Married":
                    switch (true) {
                        case AnnualTaxableWageslessExemptionAllowance >= 0 && AnnualTaxableWageslessExemptionAllowance < 51975:
                            return 0;
                        case AnnualTaxableWageslessExemptionAllowance >= 51975 && AnnualTaxableWageslessExemptionAllowance < 152150:
                            return Number(((AnnualTaxableWageslessExemptionAllowance - 51975)*0.0195).toFixed(2));
                        case AnnualTaxableWageslessExemptionAllowance >= 152150:
                            return Number((1953.41 + (AnnualTaxableWageslessExemptionAllowance - 152150)*0.025).toFixed(2));                
                        default:
                            throw new Error(`Unsupported Tax for: ${AnnualTaxableWageslessExemptionAllowance}`);
                    }
                default:
                    throw new Error(`Unsupported fillingStatus: ${fillingStatus}`);
            }
        }
    }

    async getWisconsinAnnualNetWage(fillingStatus: string, annualTaxableWages){
        switch (fillingStatus) {
            case "Single":
                switch (true) {
                    case annualTaxableWages >= 0 && annualTaxableWages < 17780:
                        let result = annualTaxableWages - 6702
                        if(result < 0){
                            return 0
                        } else{
                            return result;
                        }
                    case annualTaxableWages >= 17780 && annualTaxableWages < 73630:
                        return annualTaxableWages - (6702 - (0.12 * (annualTaxableWages - 17780)));
                    case annualTaxableWages >= 73630:
                        return annualTaxableWages;               
                }
            case "Married":
                switch (true) {
                    case annualTaxableWages >= 0 && annualTaxableWages < 25727:
                        let result = annualTaxableWages - 9461
                        if(result < 0){
                            return 0
                        } else{
                            return result;
                        }
                    case annualTaxableWages >= 25727 && annualTaxableWages < 73032:
                        return annualTaxableWages - (9461 - (0.2 * (annualTaxableWages - 25727)));
                    case annualTaxableWages >= 73032:
                        return annualTaxableWages;               
                    default:
                        throw new Error(`Unsupported Tax for: ${annualTaxableWages}`);
                }
        }
    }

    async getWisconsinAnnualTax(AnnualTaxableWageslessExemptionAllowance) {
        if(AnnualTaxableWageslessExemptionAllowance <= 12760){
            return 0.0354 * AnnualTaxableWageslessExemptionAllowance;
        }else if(AnnualTaxableWageslessExemptionAllowance > 12760 && AnnualTaxableWageslessExemptionAllowance <= 25520){
            return 451.70 + (0.0465 * (AnnualTaxableWageslessExemptionAllowance - 12760));
        }else if(AnnualTaxableWageslessExemptionAllowance > 25520 && AnnualTaxableWageslessExemptionAllowance <= 280950){
            return 1045.04 + (0.053 * (AnnualTaxableWageslessExemptionAllowance - 25520));
        }else if(AnnualTaxableWageslessExemptionAllowance > 280950){
            return 14582.83 + (0.0765 * (AnnualTaxableWageslessExemptionAllowance - 280950))
        }else{
            throw new Error(`Unsupported annual tax ammount: ${AnnualTaxableWageslessExemptionAllowance}`);
        }
    }

    async getCaliforniacomputedTaxLiability(fillingStatus: string,employeesTaxableIncome,version) {
        switch (fillingStatus) {
            case "Single":
                switch (true) {
                    case employeesTaxableIncome >= 0 && employeesTaxableIncome <= 10412:
                        return Number(((employeesTaxableIncome)*0.011).toFixed(2));
                    case employeesTaxableIncome > 10412 && employeesTaxableIncome <= 24684:
                        return Number((114.53 + (employeesTaxableIncome - 10412)*0.022).toFixed(2));
                    case employeesTaxableIncome > 24684 && employeesTaxableIncome <= 38959:
                        return Number((428.51 + (employeesTaxableIncome - 24684)*0.044).toFixed(2));    
                    case employeesTaxableIncome > 38959 && employeesTaxableIncome <= 54081:
                        return Number((1056.61 + (employeesTaxableIncome - 38959)*0.066).toFixed(2));   
                    case employeesTaxableIncome > 54081 && employeesTaxableIncome <= 68350:
                        return Number((2054.66 + (employeesTaxableIncome - 54081)*0.088).toFixed(2));   
                    case employeesTaxableIncome > 68350 && employeesTaxableIncome <= 349137:
                        return Number((3310.33 + (employeesTaxableIncome - 68350)*0.1023).toFixed(2));   
                    case employeesTaxableIncome > 349137 && employeesTaxableIncome <= 418961:
                        return Number((32034.84 + (employeesTaxableIncome - 349137)*0.1133).toFixed(2));   
                    case employeesTaxableIncome > 418961 && employeesTaxableIncome <= 698271:
                        return Number((39945.90 + (employeesTaxableIncome - 418961)*0.1243).toFixed(2));   
                    case employeesTaxableIncome > 698271 && employeesTaxableIncome <= 1000000:
                        return Number((74664.13 + (employeesTaxableIncome - 698271)*0.1353).toFixed(2));
                    case employeesTaxableIncome > 1000000:
                        return Number((115488.06 + (employeesTaxableIncome - 1000000)*0.1463).toFixed(2));               
                    default:
                        throw new Error(`Unsupported Tax for: ${employeesTaxableIncome}`);
                }
            case "Head of Household":
                switch (true) {
                    case employeesTaxableIncome >= 0 && employeesTaxableIncome <= 20839:
                        return Number(((employeesTaxableIncome)*0.011).toFixed(2));
                    case employeesTaxableIncome > 20839 && employeesTaxableIncome <= 49371:
                        return Number((229.23 + (employeesTaxableIncome - 20839)*0.022).toFixed(2));
                    case employeesTaxableIncome > 49371 && employeesTaxableIncome <= 63644:
                        return Number((856.93 + (employeesTaxableIncome - 49371)*0.044).toFixed(2));    
                    case employeesTaxableIncome > 63644 && employeesTaxableIncome <= 78765:
                        return Number((1484.94 + (employeesTaxableIncome - 63644)*0.066).toFixed(2));   
                    case employeesTaxableIncome > 78765 && employeesTaxableIncome <= 93037:
                        return Number((2482.93 + (employeesTaxableIncome - 78765)*0.088).toFixed(2));   
                    case employeesTaxableIncome > 93037 && employeesTaxableIncome <= 474824:
                        return Number((3738.87 + (employeesTaxableIncome - 93037)*0.1023).toFixed(2));   
                    case employeesTaxableIncome > 474824 && employeesTaxableIncome <= 569790:
                        return Number((42795.68 + (employeesTaxableIncome - 474824)*0.1133).toFixed(2));   
                    case employeesTaxableIncome > 569790 && employeesTaxableIncome <= 949649:
                        return Number((53555.33 + (employeesTaxableIncome - 569790)*0.1243).toFixed(2));   
                    case employeesTaxableIncome > 949649 && employeesTaxableIncome <= 1000000:
                        return Number((100771.80 + (employeesTaxableIncome - 949649)*0.1353).toFixed(2));
                    case employeesTaxableIncome > 1000000:
                        return Number((107584.29 + (employeesTaxableIncome - 1000000)*0.1463).toFixed(2));                    
                    default:
                        throw new Error(`Unsupported Tax for: ${employeesTaxableIncome}`);
                }
            case "Married":
                switch (true) {
                    case employeesTaxableIncome >= 0 && employeesTaxableIncome <= 20824:
                        return Number(((employeesTaxableIncome)*0.011).toFixed(2));
                    case employeesTaxableIncome > 10412 && employeesTaxableIncome <= 49368:
                        return Number((229.06 + (employeesTaxableIncome - 10412)*0.022).toFixed(2));
                    case employeesTaxableIncome > 49368 && employeesTaxableIncome <= 77918:
                        return Number((857.03 + (employeesTaxableIncome - 49368)*0.044).toFixed(2));    
                    case employeesTaxableIncome > 77918 && employeesTaxableIncome <= 108162:
                        return Number((2113.23 + (employeesTaxableIncome - 77918)*0.066).toFixed(2));   
                    case employeesTaxableIncome > 108162 && employeesTaxableIncome <= 136700:
                        return Number((4109.33 + (employeesTaxableIncome - 108162)*0.088).toFixed(2));   
                    case employeesTaxableIncome > 136700 && employeesTaxableIncome <= 698274:
                        return Number((6620.67 + (employeesTaxableIncome - 136700)*0.1023).toFixed(2));   
                    case employeesTaxableIncome > 698274 && employeesTaxableIncome <= 837922:
                        return Number((64069.69 + (employeesTaxableIncome - 698274)*0.1133).toFixed(2));   
                    case employeesTaxableIncome > 837922 && employeesTaxableIncome <= 1000000:
                        return Number((79891.81 + (employeesTaxableIncome - 837922)*0.1243).toFixed(2));   
                    case employeesTaxableIncome > 1000000 && employeesTaxableIncome <= 1396542:
                        return Number((100038.11 + (employeesTaxableIncome - 1000000)*0.1353).toFixed(2));
                    case employeesTaxableIncome > 1396542:
                        return Number((153690.24 + (employeesTaxableIncome - 1396542)*0.1463).toFixed(2));                   
                    default:
                        throw new Error(`Unsupported Tax for: ${employeesTaxableIncome}`);
                }
            default:
                throw new Error(`Unsupported fillingStatus: ${fillingStatus}`);
        }
    }

    async getCaliforniaAnnualTax(computedTaxLiability,allowances) {
        return Number((computedTaxLiability - (158.4 * allowances)).toFixed(2))
    }

    async getOregonAnnualTax(fillingStatus: string, base, allowances, annualWage) {
        if(annualWage < 50000){
            if((allowances < 3 && fillingStatus == "Single") || fillingStatus == "Head of Household"){
                switch (true) {
                    case base >= 0 && base < 4300:
                        return Number((249 + (base * 0.0475) - (249 * allowances)).toFixed(2));
                    case base >= 4300 && base < 10750:
                        return Number((453 + ((base - 4300) * 0.0675) - (249 * allowances)).toFixed(2));
                    case base >= 10750 && base < 50000:
                        return Number((888 + ((base - 10750) * 0.0875) - (249 * allowances)).toFixed(2));
                    default:
                        throw new Error(`Unsupported Base for allowance < 3 and < 50000: ${base}`);
                } 
            } else if ((allowances >= 3 && fillingStatus == "Single") || fillingStatus == "Married"){
                switch (true) {
                    case base >= 0 && base < 8600:
                        return Number((249 + (base * 0.0475) - (249 * allowances)).toFixed(2));
                    case base >= 8600 && base < 21500:
                        return Number((658 + ((base - 8600) * 0.0675) - (249 * allowances)).toFixed(2));
                    case base >= 21500 && base < 50000:
                        return Number((1529 + ((base - 21500) * 0.0875) - (249 * allowances)).toFixed(2));
                    default:
                        throw new Error(`Unsupported Base for allowance > 3 and < 50000: ${base}`);
                } 
            }else{
                throw new Error(`Failed in lower than 50000, mis-match on filing type`);
            }
        } else{
            if((allowances < 3 && fillingStatus == "Single") || fillingStatus == "Head of Household"){
                switch (true) {
                    case base >= 39005 && base < 125000:
                        return Number((639 + ((base - 10750) * 0.0875) - (249 * allowances)).toFixed(2));
                    case base >= 125000:
                        return Number((10636 + ((base - 125000) * 0.099) - (249 * allowances)).toFixed(2));
                    default:
                        throw new Error(`Unsupported Base for allowance < 3 and > 50000: ${base}`);
                } 
            } else if ((allowances >= 3 && fillingStatus == "Single") || fillingStatus == "Married"){
                switch (true) {
                    case base >= 36255 && base < 250000:
                        return Number((1280 + ((base - 21500) * 0.0875) - (249 * allowances)).toFixed(2));
                    case base >= 250000:
                        return Number((21274 + ((base - 250000) * 0.099) - (249 * allowances)).toFixed(2));
                    default:
                        throw new Error(`Unsupported Base for allowance > 3 and > 50000: ${base}`);
                } 
            }else{
                throw new Error(`Failed in Higher than 50000, mis-match on filing type`);
            }
        }
    }

    async getPennsylvaniaAnnualTax(annualTaxableWages) {
        return (annualTaxableWages * 0.0307);
    }

    async loadVermontTaxBrackets(filingType): Promise<TaxBracket[]> {
        if(filingType == 'Single'){
            const filePath = path.join('src/resources/data/PayrollCalculationData/stateData', 'vermontDataSingle.json');
            const data = await fs.readFile(filePath, 'utf8');
            return JSON.parse(data) as TaxBracket[];
        }else{
            const filePath = path.join('src/resources/data/PayrollCalculationData/stateData', 'vermontDataMarried.json');
            const data = await fs.readFile(filePath, 'utf8');
            return JSON.parse(data) as TaxBracket[];
        }
    }

    //Test to lower required methods
    async loadFile(filingType, state, sDorTax): Promise<TaxBracket[]> {
        let stateLowerCase: string = state.toLowerCase();
        const filePath = path.join('src/resources/data/PayrollCalculationData/stateData/' + state, stateLowerCase + sDorTax + filingType + '.json');
        const data = await fs.readFile(filePath, 'utf8');
        return JSON.parse(data) as TaxBracket[];
    }

    async computeTaxBothEqual(annualizedTaxableIncome, taxBrackets: TaxBracket[]) {
        for (const bracket of taxBrackets) {
            if (annualizedTaxableIncome >= bracket.min && annualizedTaxableIncome <= bracket.max) {
                return Number((bracket.base + ((annualizedTaxableIncome - bracket.min) * bracket.rate)).toFixed(2));
            }
        }
        throw new Error("Income out of range");
    }

    async getVermontAnnualTax(annualizedTaxableIncome, filingType) {
        try {
            const taxBrackets = this.loadVermontTaxBrackets(filingType);
            const tax = this.computeTaxBothEqual(annualizedTaxableIncome, await taxBrackets);
            console.log(`The tax for an income of ${annualizedTaxableIncome} with ${filingType} filing is ${tax}`);
            return tax;
        } catch (error) {
            console.error("Error computing tax:", error);
            throw error;
        }
    }

    async computeMaineSD(annualizedTaxableIncome, taxBrackets: TaxBracket[]) {
        for (const bracket of taxBrackets) {
            if (annualizedTaxableIncome >= bracket.min && annualizedTaxableIncome <= bracket.max) {
                if(bracket.base == null){
                    console.log("SD in loop is " + bracket.standardDeduction);
                    return Number(bracket.standardDeduction);
                }else{
                    console.log("SD in loop is " + Number((bracket.base * ((bracket.max - annualizedTaxableIncome)) / bracket.divide).toFixed(4)));
                    return Number((bracket.base * ((bracket.max - annualizedTaxableIncome)) / bracket.divide).toFixed(4));
                }
            }
        }
        throw new Error("SD out of range");
    }

    async computeMaineTax(annualizedTaxableIncome, taxBrackets: TaxBracket[]) {
        for (const bracket of taxBrackets) {
            if (annualizedTaxableIncome >= bracket.min && annualizedTaxableIncome <= bracket.max) {
                console.log("Min: " + bracket.min + "| Max: " + bracket.max + "| Base: " + bracket.base + "| Rate: " + bracket.rate)
                return Number((bracket.base + (bracket.rate * (annualizedTaxableIncome - bracket.min))).toFixed(2));
            }
        }
        throw new Error("Maine Income out of range");
    }

    async getMaineStandardDeduction(annualTaxableWages, filingType) {
        try {
            const taxBrackets = this.loadFile(filingType, "Maine", "StandardDeduction");
            const tax = this.computeMaineSD(annualTaxableWages, await taxBrackets);
            return tax;
        } catch (error) {
            console.error("Error computing Standard Deduction:", error);
            throw error;
        }
    }

    async getMaineTax(annualTaxableWages, filingType) {
        try {
            const taxBrackets = this.loadFile(filingType, "Maine", "Tax");
            const tax = this.computeMaineTax(annualTaxableWages, await taxBrackets);
            return tax;
        } catch (error) {
            console.error("Error computing Maine tax:", error);
            throw error;
        }
    }

    async getInitalTaxConnecticut(stateFilingType, annualizedTaxableIncome){
        if(stateFilingType == "withholding code A" || stateFilingType == "withholding code D" || stateFilingType == "withholding code F"){
            console.log("in A, D and F")
            switch(true){
                case annualizedTaxableIncome <= 10000:
                    return Number((annualizedTaxableIncome * 0.02).toFixed(2));
                case annualizedTaxableIncome > 10000 && annualizedTaxableIncome <= 50000:
                    return Number((200 + ((annualizedTaxableIncome - 10000) * 0.045)).toFixed(2));
                case annualizedTaxableIncome > 50000 && annualizedTaxableIncome <= 100000:
                    return Number((2000 + ((annualizedTaxableIncome - 50000) * 0.055)).toFixed(2));
                case annualizedTaxableIncome > 100000 && annualizedTaxableIncome <= 200000:
                    return Number((4750 + ((annualizedTaxableIncome - 100000) * 0.060)).toFixed(2));
                case annualizedTaxableIncome > 200000 && annualizedTaxableIncome <= 250000:
                    return Number((10750 + ((annualizedTaxableIncome - 200000) * 0.065)).toFixed(2));
                case annualizedTaxableIncome > 250000 && annualizedTaxableIncome <= 500000:
                    return Number((14000 + ((annualizedTaxableIncome - 250000) * 0.069)).toFixed(2));
                case annualizedTaxableIncome > 500000:
                    return Number((31250 + ((annualizedTaxableIncome - 500000) * 0.0699)).toFixed(2));
                default:
                    throw new Error(`Unsupported annualizedTaxableIncome: ${annualizedTaxableIncome}`);
            }
        }else if(stateFilingType == "withholding code B"){
            switch(true){
                case annualizedTaxableIncome <= 16000:
                    return Number((annualizedTaxableIncome * 0.02).toFixed(2));
                case annualizedTaxableIncome > 16000 && annualizedTaxableIncome <= 80000:
                    return Number((320 + ((annualizedTaxableIncome - 16000) * 0.045)).toFixed(2));
                case annualizedTaxableIncome > 80000 && annualizedTaxableIncome <= 160000:
                    return Number((3200 + ((annualizedTaxableIncome - 80000) * 0.055)).toFixed(2));
                case annualizedTaxableIncome > 160000 && annualizedTaxableIncome <= 320000:
                    return Number((7600 + ((annualizedTaxableIncome - 160000) * 0.060)).toFixed(2));
                case annualizedTaxableIncome > 320000 && annualizedTaxableIncome <= 400000:
                    return Number((17200 + ((annualizedTaxableIncome - 320000) * 0.065)).toFixed(2));
                case annualizedTaxableIncome > 400000 && annualizedTaxableIncome <= 800000:
                    return Number((22400 + ((annualizedTaxableIncome - 400000) * 0.069)).toFixed(2));
                case annualizedTaxableIncome > 800000:
                    return Number((50000 + ((annualizedTaxableIncome - 800000) * 0.0699)).toFixed(2));
                default:
                    throw new Error(`Unsupported annualizedTaxableIncome: ${annualizedTaxableIncome}`);
            }
        }else if(stateFilingType =="withholding code C"){
            switch(true) {
                case annualizedTaxableIncome <= 20000:
                    return Number((annualizedTaxableIncome * 0.02).toFixed(2));
                case annualizedTaxableIncome > 20000 && annualizedTaxableIncome <= 100000:
                    return Number((400 + ((annualizedTaxableIncome - 20000) * 0.045)).toFixed(2));
                case annualizedTaxableIncome > 100000 && annualizedTaxableIncome <= 200000:
                    return Number((4000 + ((annualizedTaxableIncome - 100000) * 0.055)).toFixed(2));
                case annualizedTaxableIncome > 200000 && annualizedTaxableIncome <= 400000:
                    return Number((9500 + ((annualizedTaxableIncome - 200000) * 0.060)).toFixed(2));
                case annualizedTaxableIncome > 400000 && annualizedTaxableIncome <= 500000:
                    return Number((21500 + ((annualizedTaxableIncome - 400000) * 0.065)).toFixed(2));
                case annualizedTaxableIncome > 500000 && annualizedTaxableIncome <= 1000000:
                    return Number((28000 + ((annualizedTaxableIncome - 500000) * 0.069)).toFixed(2));
                case annualizedTaxableIncome > 1000000:
                    return Number((62500 + ((annualizedTaxableIncome - 1000000) * 0.0699)).toFixed(2));
                default:
                    throw new Error(`Unsupported annualizedTaxableIncome: ${annualizedTaxableIncome}`);
            }
        } else{
            throw new Error(`incorrect filing type ${stateFilingType}` );
        }
    }
    
    async getTwoPercentConnecticut(stateFilingType, annualizedTaxableIncome){
        if(stateFilingType == "withholding code A" || stateFilingType == "withholding code D"){
            switch(true){
                case annualizedTaxableIncome > 0 && annualizedTaxableIncome <= 50250:
                    return 0;
                case annualizedTaxableIncome > 50250 && annualizedTaxableIncome <= 52750:
                    return 25;
                case annualizedTaxableIncome > 52750 && annualizedTaxableIncome <= 55250:
                    return 50;
                case annualizedTaxableIncome > 55250 && annualizedTaxableIncome <= 57750:
                    return 75;
                case annualizedTaxableIncome > 57750 && annualizedTaxableIncome <= 60250:
                    return 100;
                case annualizedTaxableIncome > 60250 && annualizedTaxableIncome <= 62750:
                    return 125;
                case annualizedTaxableIncome > 62750 && annualizedTaxableIncome <= 65250:
                    return 150;
                case annualizedTaxableIncome > 65250 && annualizedTaxableIncome <= 67750:
                    return 175;
                case annualizedTaxableIncome > 67750 && annualizedTaxableIncome <= 70250:
                    return 200;
                case annualizedTaxableIncome > 70250 && annualizedTaxableIncome <= 72750:
                    return 225;
                case annualizedTaxableIncome > 72750:
                    return 250;
                default:
                    throw new Error(`Unsupported annualizedTaxableIncome: ${annualizedTaxableIncome}`);
            }
        }else if(stateFilingType == "withholding code B"){ //Need to add
            switch(true){
                case annualizedTaxableIncome > 0 && annualizedTaxableIncome <= 78500:
                    return 0;
                case annualizedTaxableIncome > 78500 && annualizedTaxableIncome <= 82500:
                    return 40;
                case annualizedTaxableIncome > 82500 && annualizedTaxableIncome <= 86500:
                    return 80;
                case annualizedTaxableIncome > 86500 && annualizedTaxableIncome <= 90500:
                    return 120;
                case annualizedTaxableIncome > 90500 && annualizedTaxableIncome <= 94500:
                    return 160;
                case annualizedTaxableIncome > 94500 && annualizedTaxableIncome <= 98500:
                    return 200;
                case annualizedTaxableIncome > 98500 && annualizedTaxableIncome <= 102500:
                    return 240;
                case annualizedTaxableIncome > 102500 && annualizedTaxableIncome <= 106500:
                    return 280;
                case annualizedTaxableIncome > 106500 && annualizedTaxableIncome <= 110500:
                    return 320;
                case annualizedTaxableIncome > 110500 && annualizedTaxableIncome <= 114500:
                    return 360;
                case annualizedTaxableIncome > 114500:
                    return 400;
                default:
                    throw new Error(`Unsupported annualizedTaxableIncome: ${annualizedTaxableIncome}`);
            }
        }else if(stateFilingType =="withholding code C"){ //Need to add
            switch(true){
                case annualizedTaxableIncome > 0 && annualizedTaxableIncome <= 100500:
                    return 0;
                case annualizedTaxableIncome > 100500 && annualizedTaxableIncome <= 105500:
                    return 50;
                case annualizedTaxableIncome > 105500 && annualizedTaxableIncome <= 110500:
                    return 100;
                case annualizedTaxableIncome > 110500 && annualizedTaxableIncome <= 115500:
                    return 150
                case annualizedTaxableIncome > 115500 && annualizedTaxableIncome <= 120500:
                    return 200;
                case annualizedTaxableIncome > 120500 && annualizedTaxableIncome <= 125500:
                    return 250;
                case annualizedTaxableIncome > 125500 && annualizedTaxableIncome <= 130500:
                    return 300;
                case annualizedTaxableIncome > 130500 && annualizedTaxableIncome <= 135500:
                    return 350;
                case annualizedTaxableIncome > 135500 && annualizedTaxableIncome <= 140500:
                    return 400;
                case annualizedTaxableIncome > 140500 && annualizedTaxableIncome <= 145500:
                    return 450;
                case annualizedTaxableIncome > 145500:
                    return 500;
                default:
                    throw new Error(`Unsupported annualizedTaxableIncome: ${annualizedTaxableIncome}`);
            }
        } else if(stateFilingType =="withholding code F"){ //Need to add
            switch(true){
                case annualizedTaxableIncome > 0 && annualizedTaxableIncome <= 56500:
                    return 0;
                case annualizedTaxableIncome > 56500 && annualizedTaxableIncome <= 61500:
                    return 25;
                case annualizedTaxableIncome > 61500 && annualizedTaxableIncome <= 66500:
                    return 50;
                case annualizedTaxableIncome > 66500 && annualizedTaxableIncome <= 71500:
                    return 75;
                case annualizedTaxableIncome > 71500 && annualizedTaxableIncome <= 76500:
                    return 100;
                case annualizedTaxableIncome > 76500 && annualizedTaxableIncome <= 81500:
                    return 125;
                case annualizedTaxableIncome > 81500 && annualizedTaxableIncome <= 86500:
                    return 150;
                case annualizedTaxableIncome > 86500 && annualizedTaxableIncome <= 91500:
                    return 175;
                case annualizedTaxableIncome > 91500 && annualizedTaxableIncome <= 96500:
                    return 200;
                case annualizedTaxableIncome > 96500 && annualizedTaxableIncome <= 101500:
                    return 225;
                case annualizedTaxableIncome > 101500:
                    return 250;
                default:
                    throw new Error(`Unsupported annualizedTaxableIncome: ${annualizedTaxableIncome}`);
            }
        }else{
            throw new Error(`incorrect filing type ${stateFilingType}` );
        }
    }

    async getTaxRecaptureAmountConnecticut(stateFilingType, annualizedTaxableIncome){
        if(stateFilingType == "withholding code A" || stateFilingType == "withholding code D" || stateFilingType == "withholding code F"){
            switch(true){
                case annualizedTaxableIncome > 0 && annualizedTaxableIncome <= 105000:
                    return 0;
                case annualizedTaxableIncome > 105000 && annualizedTaxableIncome <= 110000:
                    return 25;
                case annualizedTaxableIncome > 110000 && annualizedTaxableIncome <= 115000:
                    return 50;
                case annualizedTaxableIncome > 115000 && annualizedTaxableIncome <= 120000:
                    return 75;
                case annualizedTaxableIncome > 120000 && annualizedTaxableIncome <= 125000:
                    return 100;
                case annualizedTaxableIncome > 125000 && annualizedTaxableIncome <= 130000:
                    return 125;
                case annualizedTaxableIncome > 130000 && annualizedTaxableIncome <= 135000:
                    return 150;
                case annualizedTaxableIncome > 135000 && annualizedTaxableIncome <= 140000:
                    return 175;
                case annualizedTaxableIncome > 140000 && annualizedTaxableIncome <= 145000:
                    return 200;
                case annualizedTaxableIncome > 145000 && annualizedTaxableIncome <= 150000:
                    return 225;
                case annualizedTaxableIncome > 150000 && annualizedTaxableIncome <= 200000:
                    return 250;
                case annualizedTaxableIncome > 200000 && annualizedTaxableIncome <= 205000:
                    return 340;
                case annualizedTaxableIncome > 205000 && annualizedTaxableIncome <= 210000:
                    return 430;
                case annualizedTaxableIncome > 210000 && annualizedTaxableIncome <= 215000:
                    return 520;
                case annualizedTaxableIncome > 215000 && annualizedTaxableIncome <= 220000:
                    return 610;
                case annualizedTaxableIncome > 220000 && annualizedTaxableIncome <= 225000:
                    return 700;
                case annualizedTaxableIncome > 225000 && annualizedTaxableIncome <= 230000:
                    return 790;
                case annualizedTaxableIncome > 230000 && annualizedTaxableIncome <= 235000:
                    return 880;
                case annualizedTaxableIncome > 235000 && annualizedTaxableIncome <= 240000:
                    return 970;
                case annualizedTaxableIncome > 240000 && annualizedTaxableIncome <= 245000:
                    return 1060;
                case annualizedTaxableIncome > 245000 && annualizedTaxableIncome <= 250000:
                    return 1150;
                case annualizedTaxableIncome > 250000 && annualizedTaxableIncome <= 255000:
                    return 1240;
                case annualizedTaxableIncome > 255000 && annualizedTaxableIncome <= 260000:
                    return 1330;
                case annualizedTaxableIncome > 260000 && annualizedTaxableIncome <= 265000:
                    return 1420;
                case annualizedTaxableIncome > 265000 && annualizedTaxableIncome <= 270000:
                    return 1510;
                case annualizedTaxableIncome > 270000 && annualizedTaxableIncome <= 275000:
                    return 1600;
                case annualizedTaxableIncome > 275000 && annualizedTaxableIncome <= 280000:
                    return 1690;
                case annualizedTaxableIncome > 280000 && annualizedTaxableIncome <= 285000:
                    return 1780;
                case annualizedTaxableIncome > 285000 && annualizedTaxableIncome <= 290000:
                    return 1870;
                case annualizedTaxableIncome > 290000 && annualizedTaxableIncome <= 295000:
                    return 1960;
                case annualizedTaxableIncome > 295000 && annualizedTaxableIncome <= 300000:
                    return 2050;
                case annualizedTaxableIncome > 300000 && annualizedTaxableIncome <= 305000:
                    return 2140;
                case annualizedTaxableIncome > 305000 && annualizedTaxableIncome <= 310000:
                    return 2230;
                case annualizedTaxableIncome > 310000 && annualizedTaxableIncome <= 315000:
                    return 2320;
                case annualizedTaxableIncome > 315000 && annualizedTaxableIncome <= 320000:
                    return 2410;
                case annualizedTaxableIncome > 320000 && annualizedTaxableIncome <= 325000:
                    return 2500;
                case annualizedTaxableIncome > 325000 && annualizedTaxableIncome <= 330000:
                    return 2590;
                case annualizedTaxableIncome > 330000 && annualizedTaxableIncome <= 335000:
                    return 2680;
                case annualizedTaxableIncome > 335000 && annualizedTaxableIncome <= 340000:
                    return 2770;
                case annualizedTaxableIncome > 340000 && annualizedTaxableIncome <= 345000:
                    return 2860;
                case annualizedTaxableIncome > 345000 && annualizedTaxableIncome <= 500000:
                    return 2950;
                case annualizedTaxableIncome > 500000 && annualizedTaxableIncome <= 505000:
                    return 3000;
                case annualizedTaxableIncome > 505000 && annualizedTaxableIncome <= 510000:
                    return 3050;
                case annualizedTaxableIncome > 510000 && annualizedTaxableIncome <= 515000:
                    return 3100;
                case annualizedTaxableIncome > 515000 && annualizedTaxableIncome <= 520000:
                    return 3150;
                case annualizedTaxableIncome > 520000 && annualizedTaxableIncome <= 525000:
                    return 3200;
                case annualizedTaxableIncome > 525000 && annualizedTaxableIncome <= 530000:
                    return 3250;
                case annualizedTaxableIncome > 530000 && annualizedTaxableIncome <= 535000:
                    return 3300;
                case annualizedTaxableIncome > 535000 && annualizedTaxableIncome <= 540000:
                    return 3350;
                case annualizedTaxableIncome > 540000:
                    return 3400;
                default:
                    throw new Error(`Unsupported annualizedTaxableIncome: ${annualizedTaxableIncome}`);
            }
        }else if(stateFilingType == "withholding code B"){ //Need to add
            switch (true) {
                case annualizedTaxableIncome > 0 && annualizedTaxableIncome <= 168000:
                    return 0;
                case annualizedTaxableIncome > 168000 && annualizedTaxableIncome <= 176000:
                    return 40;
                case annualizedTaxableIncome > 176000 && annualizedTaxableIncome <= 184000:
                    return 80;
                case annualizedTaxableIncome > 184000 && annualizedTaxableIncome <= 192000:
                    return 120;
                case annualizedTaxableIncome > 192000 && annualizedTaxableIncome <= 200000:
                    return 160;
                case annualizedTaxableIncome > 200000 && annualizedTaxableIncome <= 208000:
                    return 200;
                case annualizedTaxableIncome > 208000 && annualizedTaxableIncome <= 216000:
                    return 240;
                case annualizedTaxableIncome > 216000 && annualizedTaxableIncome <= 224000:
                    return 280;
                case annualizedTaxableIncome > 224000 && annualizedTaxableIncome <= 232000:
                    return 320;
                case annualizedTaxableIncome > 232000 && annualizedTaxableIncome <= 240000:
                    return 360;
                case annualizedTaxableIncome > 240000 && annualizedTaxableIncome <= 320000:
                    return 400;
                case annualizedTaxableIncome > 320000 && annualizedTaxableIncome <= 328000:
                    return 540;
                case annualizedTaxableIncome > 328000 && annualizedTaxableIncome <= 336000:
                    return 680;
                case annualizedTaxableIncome > 336000 && annualizedTaxableIncome <= 344000:
                    return 820;
                case annualizedTaxableIncome > 344000 && annualizedTaxableIncome <= 352000:
                    return 960;
                case annualizedTaxableIncome > 352000 && annualizedTaxableIncome <= 360000:
                    return 1100;
                case annualizedTaxableIncome > 360000 && annualizedTaxableIncome <= 368000:
                    return 1240;
                case annualizedTaxableIncome > 368000 && annualizedTaxableIncome <= 376000:
                    return 1380;
                case annualizedTaxableIncome > 376000 && annualizedTaxableIncome <= 384000:
                    return 1520;
                case annualizedTaxableIncome > 384000 && annualizedTaxableIncome <= 392000:
                    return 1660;
                case annualizedTaxableIncome > 392000 && annualizedTaxableIncome <= 400000:
                    return 1800;
                case annualizedTaxableIncome > 400000 && annualizedTaxableIncome <= 408000:
                    return 1940;
                case annualizedTaxableIncome > 408000 && annualizedTaxableIncome <= 416000:
                    return 2080;
                case annualizedTaxableIncome > 416000 && annualizedTaxableIncome <= 424000:
                    return 2220;
                case annualizedTaxableIncome > 424000 && annualizedTaxableIncome <= 432000:
                    return 2360;
                case annualizedTaxableIncome > 432000 && annualizedTaxableIncome <= 440000:
                    return 2500;
                case annualizedTaxableIncome > 440000 && annualizedTaxableIncome <= 448000:
                    return 2640;
                case annualizedTaxableIncome > 448000 && annualizedTaxableIncome <= 456000:
                    return 2780;
                case annualizedTaxableIncome > 456000 && annualizedTaxableIncome <= 464000:
                    return 2920;
                case annualizedTaxableIncome > 464000 && annualizedTaxableIncome <= 472000:
                    return 3060;
                case annualizedTaxableIncome > 472000 && annualizedTaxableIncome <= 480000:
                    return 3200;
                case annualizedTaxableIncome > 480000 && annualizedTaxableIncome <= 488000:
                    return 3340;
                case annualizedTaxableIncome > 488000 && annualizedTaxableIncome <= 496000:
                    return 3480;
                case annualizedTaxableIncome > 496000 && annualizedTaxableIncome <= 504000:
                    return 3620;
                case annualizedTaxableIncome > 504000 && annualizedTaxableIncome <= 512000:
                    return 3760;
                case annualizedTaxableIncome > 512000 && annualizedTaxableIncome <= 520000:
                    return 3900;
                case annualizedTaxableIncome > 520000 && annualizedTaxableIncome <= 528000:
                    return 4040;
                case annualizedTaxableIncome > 528000 && annualizedTaxableIncome <= 536000:
                    return 4180;
                case annualizedTaxableIncome > 536000 && annualizedTaxableIncome <= 544000:
                    return 4320;
                case annualizedTaxableIncome > 544000 && annualizedTaxableIncome <= 552000:
                    return 4460;
                case annualizedTaxableIncome > 552000 && annualizedTaxableIncome <= 800000:
                    return 4600;
                case annualizedTaxableIncome > 800000 && annualizedTaxableIncome <= 808000:
                    return 4680;
                case annualizedTaxableIncome > 808000 && annualizedTaxableIncome <= 816000:
                    return 4760;
                case annualizedTaxableIncome > 816000 && annualizedTaxableIncome <= 824000:
                    return 4840;
                case annualizedTaxableIncome > 824000 && annualizedTaxableIncome <= 832000:
                    return 4920;
                case annualizedTaxableIncome > 832000 && annualizedTaxableIncome <= 840000:
                    return 5000;
                case annualizedTaxableIncome > 840000 && annualizedTaxableIncome <= 848000:
                    return 5080;
                case annualizedTaxableIncome > 848000 && annualizedTaxableIncome <= 856000:
                    return 5160;
                case annualizedTaxableIncome > 856000 && annualizedTaxableIncome <= 864000:
                    return 5240;
                case annualizedTaxableIncome > 864000:
                    return 5320;
                default:
                    return 0;
            }
        }else if(stateFilingType =="withholding code C"){ //Need to add
            switch (true) {
                case annualizedTaxableIncome > 0 && annualizedTaxableIncome <= 210000:
                    return 0;
                case annualizedTaxableIncome > 210000 && annualizedTaxableIncome <= 220000:
                    return 50;
                case annualizedTaxableIncome > 220000 && annualizedTaxableIncome <= 230000:
                    return 100;
                case annualizedTaxableIncome > 230000 && annualizedTaxableIncome <= 240000:
                    return 150;
                case annualizedTaxableIncome > 240000 && annualizedTaxableIncome <= 250000:
                    return 200;
                case annualizedTaxableIncome > 250000 && annualizedTaxableIncome <= 260000:
                    return 250;
                case annualizedTaxableIncome > 260000 && annualizedTaxableIncome <= 270000:
                    return 300;
                case annualizedTaxableIncome > 270000 && annualizedTaxableIncome <= 280000:
                    return 350;
                case annualizedTaxableIncome > 280000 && annualizedTaxableIncome <= 290000:
                    return 400;
                case annualizedTaxableIncome > 290000 && annualizedTaxableIncome <= 300000:
                    return 450;
                case annualizedTaxableIncome > 300000 && annualizedTaxableIncome <= 400000:
                    return 500;
                case annualizedTaxableIncome > 400000 && annualizedTaxableIncome <= 410000:
                    return 680;
                case annualizedTaxableIncome > 410000 && annualizedTaxableIncome <= 420000:
                    return 860;
                case annualizedTaxableIncome > 420000 && annualizedTaxableIncome <= 430000:
                    return 1040;
                case annualizedTaxableIncome > 430000 && annualizedTaxableIncome <= 440000:
                    return 1220;
                case annualizedTaxableIncome > 440000 && annualizedTaxableIncome <= 450000:
                    return 1400;
                case annualizedTaxableIncome > 450000 && annualizedTaxableIncome <= 460000:
                    return 1580;
                case annualizedTaxableIncome > 460000 && annualizedTaxableIncome <= 470000:
                    return 1760;
                case annualizedTaxableIncome > 470000 && annualizedTaxableIncome <= 480000:
                    return 1940;
                case annualizedTaxableIncome > 480000 && annualizedTaxableIncome <= 490000:
                    return 2120;
                case annualizedTaxableIncome > 490000 && annualizedTaxableIncome <= 500000:
                    return 2300;
                case annualizedTaxableIncome > 500000 && annualizedTaxableIncome <= 510000:
                    return 2480;
                case annualizedTaxableIncome > 510000 && annualizedTaxableIncome <= 520000:
                    return 2660;
                case annualizedTaxableIncome > 520000 && annualizedTaxableIncome <= 530000:
                    return 2840;
                case annualizedTaxableIncome > 530000 && annualizedTaxableIncome <= 540000:
                    return 3020;
                case annualizedTaxableIncome > 540000 && annualizedTaxableIncome <= 550000:
                    return 3200;
                case annualizedTaxableIncome > 550000 && annualizedTaxableIncome <= 560000:
                    return 3380;
                case annualizedTaxableIncome > 560000 && annualizedTaxableIncome <= 570000:
                    return 3560;
                case annualizedTaxableIncome > 570000 && annualizedTaxableIncome <= 580000:
                    return 3740;
                case annualizedTaxableIncome > 580000 && annualizedTaxableIncome <= 590000:
                    return 3920;
                case annualizedTaxableIncome > 590000 && annualizedTaxableIncome <= 600000:
                    return 4100;
                case annualizedTaxableIncome > 600000 && annualizedTaxableIncome <= 610000:
                    return 4280;
                case annualizedTaxableIncome > 610000 && annualizedTaxableIncome <= 620000:
                    return 4460;
                case annualizedTaxableIncome > 620000 && annualizedTaxableIncome <= 630000:
                    return 4640;
                case annualizedTaxableIncome > 630000 && annualizedTaxableIncome <= 640000:
                    return 4820;
                case annualizedTaxableIncome > 640000 && annualizedTaxableIncome <= 650000:
                    return 5000;
                case annualizedTaxableIncome > 650000 && annualizedTaxableIncome <= 660000:
                    return 5180;
                case annualizedTaxableIncome > 660000 && annualizedTaxableIncome <= 670000:
                    return 5360;
                case annualizedTaxableIncome > 670000 && annualizedTaxableIncome <= 680000:
                    return 5540;
                case annualizedTaxableIncome > 680000 && annualizedTaxableIncome <= 690000:
                    return 5720;
                case annualizedTaxableIncome > 690000 && annualizedTaxableIncome <= 1000000:
                    return 5900;
                case annualizedTaxableIncome > 1000000 && annualizedTaxableIncome <= 1010000:
                    return 6000;
                case annualizedTaxableIncome > 1010000 && annualizedTaxableIncome <= 1020000:
                    return 6100;
                case annualizedTaxableIncome > 1020000 && annualizedTaxableIncome <= 1030000:
                    return 6200;
                case annualizedTaxableIncome > 1030000 && annualizedTaxableIncome <= 1040000:
                    return 6300;
                case annualizedTaxableIncome > 1040000 && annualizedTaxableIncome <= 1050000:
                    return 6400;
                case annualizedTaxableIncome > 1050000 && annualizedTaxableIncome <= 1060000:
                    return 6500;
                case annualizedTaxableIncome > 1060000 && annualizedTaxableIncome <= 1070000:
                    return 6600;
                case annualizedTaxableIncome > 1070000 && annualizedTaxableIncome <= 1080000:
                    return 6700;
                case annualizedTaxableIncome > 1080000:
                    return 6800;
                default:
                    throw new Error(`Unsupported annualizedTaxableIncome: ${annualizedTaxableIncome}`);
            }
        } else{
            throw new Error(`incorrect filing type ${stateFilingType}` );
        }
    }

    async getPersonalTaxCreditsAmountConnecticut(stateFilingType, annualizedTaxableIncome){
        if(stateFilingType == "withholding code A"){
            switch(true){
                case annualizedTaxableIncome <= 12000:
                    return 1;
                case annualizedTaxableIncome > 12000 && annualizedTaxableIncome <= 15000:
                    return 0.75;
                case annualizedTaxableIncome > 15000 && annualizedTaxableIncome <= 15500:
                    return 0.70;
                case annualizedTaxableIncome > 15500 && annualizedTaxableIncome <= 16000:
                    return 0.65;
                case annualizedTaxableIncome > 16000 && annualizedTaxableIncome <= 16500:
                    return 0.6;
                case annualizedTaxableIncome > 16500 && annualizedTaxableIncome <= 17000:
                    return 0.55;
                case annualizedTaxableIncome > 17000 && annualizedTaxableIncome <= 17500:
                    return 0.50;
                case annualizedTaxableIncome > 17500 && annualizedTaxableIncome <= 18000:
                    return 0.45;
                case annualizedTaxableIncome > 18000 && annualizedTaxableIncome <= 18500:
                    return 0.40;
                case annualizedTaxableIncome > 18500 && annualizedTaxableIncome <= 20000:
                    return 0.35;
                case annualizedTaxableIncome > 20000 && annualizedTaxableIncome <= 20500:
                    return 0.30;
                case annualizedTaxableIncome > 20500 && annualizedTaxableIncome <= 21000:
                    return 0.25;
                case annualizedTaxableIncome > 21000 && annualizedTaxableIncome <= 21500:
                    return 0.2;
                case annualizedTaxableIncome > 21500 && annualizedTaxableIncome <= 25000:
                    return 0.15;
                case annualizedTaxableIncome > 25000 && annualizedTaxableIncome <= 25500:
                    return 0.14;
                case annualizedTaxableIncome > 25500 && annualizedTaxableIncome <= 26000:
                    return 0.13;
                case annualizedTaxableIncome > 26000 && annualizedTaxableIncome <= 26500:
                    return 0.12;
                case annualizedTaxableIncome > 26500 && annualizedTaxableIncome <= 27000:
                    return 0.11;
                case annualizedTaxableIncome > 27000 && annualizedTaxableIncome <= 48000:
                    return 0.10;
                case annualizedTaxableIncome > 48000 && annualizedTaxableIncome <= 48500:
                    return 0.09;
                case annualizedTaxableIncome > 48500 && annualizedTaxableIncome <= 49000:
                    return 0.08;
                case annualizedTaxableIncome > 49000 && annualizedTaxableIncome <= 49500:
                    return 0.07;
                case annualizedTaxableIncome > 49500 && annualizedTaxableIncome <= 50000:
                    return 0.06;
                case annualizedTaxableIncome > 50000 && annualizedTaxableIncome <= 50500:
                    return 0.05;
                case annualizedTaxableIncome > 50500 && annualizedTaxableIncome <= 51000:
                    return 0.04;
                case annualizedTaxableIncome > 51000 && annualizedTaxableIncome <= 51500:
                    return 0.03;
                case annualizedTaxableIncome > 51500 && annualizedTaxableIncome <= 52000:
                    return 0.02;
                case annualizedTaxableIncome > 52000 && annualizedTaxableIncome <= 52500:
                    return 0.01;
                case annualizedTaxableIncome > 52500:
                    return 0.00;
                default:
                    throw new Error(`Unsupported annualizedTaxableIncome: ${annualizedTaxableIncome}`);
            }
        }else if(stateFilingType == "withholding code B"){ //Need to add
            switch(true){
                case annualizedTaxableIncome < 19000:
                    return 1;
                case annualizedTaxableIncome > 19000 && annualizedTaxableIncome <= 24000:
                    return 0.75;
                case annualizedTaxableIncome > 24000 && annualizedTaxableIncome <= 24500:
                    return 0.70;
                case annualizedTaxableIncome > 24500 && annualizedTaxableIncome <= 25000:
                    return 0.65;
                case annualizedTaxableIncome > 25000 && annualizedTaxableIncome <= 25500:
                    return 0.6;
                case annualizedTaxableIncome > 25500 && annualizedTaxableIncome <= 26000:
                    return 0.55;
                case annualizedTaxableIncome > 26000 && annualizedTaxableIncome <= 26500:
                    return 0.50;
                case annualizedTaxableIncome > 26500 && annualizedTaxableIncome <= 27000:
                    return 0.45;
                case annualizedTaxableIncome > 27000 && annualizedTaxableIncome <= 27500:
                    return 0.40;
                case annualizedTaxableIncome > 27500 && annualizedTaxableIncome <= 34000:
                    return 0.35;
                case annualizedTaxableIncome > 34000 && annualizedTaxableIncome <= 34500:
                    return 0.30;
                case annualizedTaxableIncome > 34500 && annualizedTaxableIncome <= 35000:
                    return 0.25;
                case annualizedTaxableIncome > 35000 && annualizedTaxableIncome <= 35500:
                    return 0.2;
                case annualizedTaxableIncome > 35500 && annualizedTaxableIncome <= 44000:
                    return 0.15;
                case annualizedTaxableIncome > 44000 && annualizedTaxableIncome <= 44500:
                    return 0.14;
                case annualizedTaxableIncome > 44500 && annualizedTaxableIncome <= 45000:
                    return 0.13;
                case annualizedTaxableIncome > 45000 && annualizedTaxableIncome <= 45500:
                    return 0.12;
                case annualizedTaxableIncome > 45500 && annualizedTaxableIncome <= 46000:
                    return 0.11;
                case annualizedTaxableIncome > 46000 && annualizedTaxableIncome <= 74000:
                    return 0.10;
                case annualizedTaxableIncome > 74000 && annualizedTaxableIncome <= 74500:
                    return 0.09;
                case annualizedTaxableIncome > 74500 && annualizedTaxableIncome <= 75000:
                    return 0.08;
                case annualizedTaxableIncome > 75000 && annualizedTaxableIncome <= 75500:
                    return 0.07;
                case annualizedTaxableIncome > 75500 && annualizedTaxableIncome <= 76000:
                    return 0.06;
                case annualizedTaxableIncome > 76000 && annualizedTaxableIncome <= 76500:
                    return 0.05;
                case annualizedTaxableIncome > 76500 && annualizedTaxableIncome <= 77000:
                    return 0.04;
                case annualizedTaxableIncome > 77000 && annualizedTaxableIncome <= 77500:
                    return 0.03;
                case annualizedTaxableIncome > 77500 && annualizedTaxableIncome <= 78000:
                    return 0.02;
                case annualizedTaxableIncome > 78000 && annualizedTaxableIncome <= 78500:
                    return 0.01;
                case annualizedTaxableIncome > 78500:
                    return 0.00;
                default:
                    throw new Error(`Unsupported annualizedTaxableIncome: ${annualizedTaxableIncome}`);
            }
        }else if(stateFilingType =="withholding code C"){ //Need to add
            switch(true){
                case annualizedTaxableIncome <= 24000:
                    return 1;
                case annualizedTaxableIncome > 24000 && annualizedTaxableIncome <= 30000:
                    return 0.75;
                case annualizedTaxableIncome > 30000 && annualizedTaxableIncome <= 30500:
                    return 0.70;
                case annualizedTaxableIncome > 30500 && annualizedTaxableIncome <= 31000:
                    return 0.65;
                case annualizedTaxableIncome > 31000 && annualizedTaxableIncome <= 31500:
                    return 0.6;
                case annualizedTaxableIncome > 31500 && annualizedTaxableIncome <= 32000:
                    return 0.55;
                case annualizedTaxableIncome > 32000 && annualizedTaxableIncome <= 32500:
                    return 0.50;
                case annualizedTaxableIncome > 32500 && annualizedTaxableIncome <= 33000:
                    return 0.45;
                case annualizedTaxableIncome > 33000 && annualizedTaxableIncome <= 33500:
                    return 0.40;
                case annualizedTaxableIncome > 33500 && annualizedTaxableIncome <= 40000:
                    return 0.35;
                case annualizedTaxableIncome > 40000 && annualizedTaxableIncome <= 40500:
                    return 0.30;
                case annualizedTaxableIncome > 40500 && annualizedTaxableIncome <= 41000:
                    return 0.25;
                case annualizedTaxableIncome > 41000 && annualizedTaxableIncome <= 41500:
                    return 0.2;
                case annualizedTaxableIncome > 41500 && annualizedTaxableIncome <= 50000:
                    return 0.15;
                case annualizedTaxableIncome > 50000 && annualizedTaxableIncome <= 50500:
                    return 0.14;
                case annualizedTaxableIncome > 50500 && annualizedTaxableIncome <= 51000:
                    return 0.13;
                case annualizedTaxableIncome > 51000 && annualizedTaxableIncome <= 51500:
                    return 0.12;
                case annualizedTaxableIncome > 51500 && annualizedTaxableIncome <= 52000:
                    return 0.11;
                case annualizedTaxableIncome > 52000 && annualizedTaxableIncome <= 96000:
                    return 0.10;
                case annualizedTaxableIncome > 96000 && annualizedTaxableIncome <= 96500:
                    return 0.09;
                case annualizedTaxableIncome > 96500 && annualizedTaxableIncome <= 97000:
                    return 0.08;
                case annualizedTaxableIncome > 97000 && annualizedTaxableIncome <= 97500:
                    return 0.07;
                case annualizedTaxableIncome > 97500 && annualizedTaxableIncome <= 98000:
                    return 0.06;
                case annualizedTaxableIncome > 98000 && annualizedTaxableIncome <= 98500:
                    return 0.05;
                case annualizedTaxableIncome > 98500 && annualizedTaxableIncome <= 99000:
                    return 0.04;
                case annualizedTaxableIncome > 99000 && annualizedTaxableIncome <= 99500:
                    return 0.03;
                case annualizedTaxableIncome > 99500 && annualizedTaxableIncome <= 100000:
                    return 0.02;
                case annualizedTaxableIncome > 100000 && annualizedTaxableIncome <= 100500:
                    return 0.01;
                case annualizedTaxableIncome > 100500:
                    return 0.00;
                default:
                    throw new Error(`Unsupported annualizedTaxableIncome: ${annualizedTaxableIncome}`);
            }
        } else if(stateFilingType == "withholding code D"){
            return 0;
        }else if(stateFilingType =="withholding code F"){ //Need to add
            switch(true){
                case annualizedTaxableIncome <= 15000:
                    return 1;
                case annualizedTaxableIncome > 15000 && annualizedTaxableIncome <= 18800:
                    return 0.75;
                case annualizedTaxableIncome > 18800 && annualizedTaxableIncome <= 19300:
                    return 0.70;
                case annualizedTaxableIncome > 19300 && annualizedTaxableIncome <= 19800:
                    return 0.65;
                case annualizedTaxableIncome > 19800 && annualizedTaxableIncome <= 20300:
                    return 0.6;
                case annualizedTaxableIncome > 20300 && annualizedTaxableIncome <= 20800:
                    return 0.55;
                case annualizedTaxableIncome > 20800 && annualizedTaxableIncome <= 21300:
                    return 0.50;
                case annualizedTaxableIncome > 21300 && annualizedTaxableIncome <= 21800:
                    return 0.45;
                case annualizedTaxableIncome > 21800 && annualizedTaxableIncome <= 22300:
                    return 0.40;
                case annualizedTaxableIncome > 22300 && annualizedTaxableIncome <= 25000:
                    return 0.35;
                case annualizedTaxableIncome > 25000 && annualizedTaxableIncome <= 25500:
                    return 0.30;
                case annualizedTaxableIncome > 25500 && annualizedTaxableIncome <= 26000:
                    return 0.25;
                case annualizedTaxableIncome > 26000 && annualizedTaxableIncome <= 26500:
                    return 0.2;
                case annualizedTaxableIncome > 26500 && annualizedTaxableIncome <= 31300:
                    return 0.15;
                case annualizedTaxableIncome > 31300 && annualizedTaxableIncome <= 31800:
                    return 0.14;
                case annualizedTaxableIncome > 31800 && annualizedTaxableIncome <= 32300:
                    return 0.13;
                case annualizedTaxableIncome > 32300 && annualizedTaxableIncome <= 32800:
                    return 0.12;
                case annualizedTaxableIncome > 32800 && annualizedTaxableIncome <= 33300:
                    return 0.11;
                case annualizedTaxableIncome > 33300 && annualizedTaxableIncome <= 60000:
                    return 0.10;
                case annualizedTaxableIncome > 60000 && annualizedTaxableIncome <= 60500:
                    return 0.09;
                case annualizedTaxableIncome > 60500 && annualizedTaxableIncome <= 61000:
                    return 0.08;
                case annualizedTaxableIncome > 61000 && annualizedTaxableIncome <= 61500:
                    return 0.07;
                case annualizedTaxableIncome > 61500 && annualizedTaxableIncome <= 62000:
                    return 0.06;
                case annualizedTaxableIncome > 62000 && annualizedTaxableIncome <= 62500:
                    return 0.05;
                case annualizedTaxableIncome > 62500 && annualizedTaxableIncome <= 63000:
                    return 0.04;
                case annualizedTaxableIncome > 63000 && annualizedTaxableIncome <= 63500:
                    return 0.03;
                case annualizedTaxableIncome > 63500 && annualizedTaxableIncome <= 64000:
                    return 0.02;
                case annualizedTaxableIncome > 64000 && annualizedTaxableIncome <= 64500:
                    return 0.01;
                case annualizedTaxableIncome > 64500:
                    return 0.00;
                default:
                    throw new Error(`Unsupported annualizedTaxableIncome: ${annualizedTaxableIncome}`);
            }
        }else{
            throw new Error(`incorrect filing type ${stateFilingType}` );
        }
    }

    async getStandardDeductionForGA(filingStatus){
        switch (filingStatus) {
            case 'Single':
            case 'Head of Household':
                return 12000;
            case 'Married Filing Joint, both spouses working':
            case 'Married Filing Separate':
                return 12000;
            case 'Married Filing Joint, one spouse working':
                return 24000;
            default:
                throw new Error(`Unsupported filing status: ${filingStatus}`);
        }
    }

    async getPersonalAllowanceForGA(filingStatus){
        switch (filingStatus) {
            case 'Single':
            case 'Head of Household':
                return 2700;
            case 'Married Filing Joint, both spouses working':
            case 'Married Filing Separate':
                return 3700;
            case 'Married Filing Joint, one spouse working':
                return 7400;
            default:
                throw new Error(`Unsupported filing status: ${filingStatus}`);
        }
    }

    async getStandardDeductionForIOWA(total_Allowances) {
        const totalAllowances = parseInt(total_Allowances);
        if (totalAllowances <80) {
            return 14600;
        } else if (totalAllowances >= 80) {
            return 29200;
        } else {
            throw new Error(`Unsupported filing status: ${totalAllowances}`);
        }
    }
    
    async getStandardDeductionValueForMissouri(filingStatus) {
        switch (filingStatus) {
            case 'Single':
                return 14600;
            case 'Married and Spouse Works':
                return 14600;
            case 'Married Filing Separate':
                return 14600;
            case 'Married and Spouse Does Not Work':
                return 29200;
            case 'Head of Household':
                return 21900;
            default:
                throw new Error(`Unsupported filing status: ${filingStatus}`);
        }
    }

    async getStandardDeductionValueForNewYork(filingStatus,allowances){
        switch (filingStatus) {
            case 'Single':
                return 7400.00 + (allowances * 1000);
            case 'Married':
                return 7950.00 + (allowances * 1000);
            default:
                await log.info("In New York Deductable");
                throw new Error(`Unsupported filing status: ${filingStatus}`);
        }
    }

    async getStandardDeductionValueForMassachusetts(allowances){
        return 3400.00 + (allowances * 1000);
    }

    async getStandardDeductionValueForNorthDakota(allowances, version){
        if(version == "2019 and earlier"){
            return 4300.00 * allowances;
        } else{
            return 0;
        }
    }
    async getStandardDeductionValueForWisconsin(allowances){
        return 400 * allowances;
    }

    async getEstimatedDeductionValueForCalifornia(allowances){
        return 1000 * allowances;
    }

    async getStandardDeductionValueForCalifornia(filingType, twoJobStatus, allowances){
        switch (filingType) {
            case "Single":
                return 5363;
            case "Married": 
                if(twoJobStatus){
                    return 5363;
                }else if(allowances <= 1){
                    return 5363;
                }else if(allowances >= 2){
                    return 10726;
                }
            case "Head of Household":
                return 10726;
            default:
                throw new Error(`Unsupported state filing type: ${filingType}`);
        }
    }

    async getStandardDeductionValueForOregon(allowances, stateFillingType){
        if(stateFillingType == "Single" && allowances < 3){
            return 2745;
        }else if(stateFillingType == "Married"){
            return 5495;
        }else if(stateFillingType == "Single" && allowances >= 3){
            return 5495;
        }else if(stateFillingType == "Head of Household"){
            return 2745;
        } else{
            throw new Error(`Unsupported filing Type: ${stateFillingType}`);
        }
    }

    async getOregonFederalTaxForBaseCalculation(federalTax, annualWage){
        if(annualWage < 50000){
            if(federalTax <= 8250){
                return federalTax
            }else{
                return 8250;
            }
        }else if(annualWage >= 50000 && annualWage < 125000){
            if(federalTax <= 8250){
                return federalTax
            }else{
                return 8250;
            }
        }else if(annualWage >= 125000 && annualWage < 130000){
            if(federalTax <= 6600){
                return federalTax
            }else{
                return 6600;
            }
        }else if(annualWage >= 130000 && annualWage < 135000){
            if(federalTax <= 4950){
                return federalTax
            }else{
                return 4950;
            }
        }else if(annualWage >= 135000 && annualWage < 140000){
            if(federalTax <= 3300){
                return federalTax
            }else{
                return 3300;
            }
        }else if(annualWage >= 140000 && annualWage < 145000){
            if(federalTax <= 1650){
                return federalTax
            }else{
                return 1650;
            }
        }else if(annualWage >= 145000 ){
            return 0;
        }else{
            throw new Error(`Unsupported wage: ${annualWage}`);
        }
    }
    async getStandardDeductionValueForPennsylvania(allowances, version){
        if(version == "2019 and earlier"){
            return 4300.00 * allowances;
        } else{
            return 0;
        }
    }

    async getPersonalExemptionsForConnecticut(annualWage, stateFilingType){
        switch (stateFilingType) {
            case 'withholding code A':
                switch(true){
                    case annualWage > 0 && annualWage <= 24000:
                        return 12000;
                    case annualWage > 24000 && annualWage <= 25000:
                        return 11000;
                    case annualWage > 25000 && annualWage <= 26000:
                        return 10000;
                    case annualWage > 26000 && annualWage <= 27000:
                        return 9000;
                    case annualWage > 27000 && annualWage <= 28000:
                        return 8000;
                    case annualWage > 28000 && annualWage <= 29000:
                        return 7000;
                    case annualWage > 29000 && annualWage <= 30000:
                        return 6000;
                    case annualWage > 30000 && annualWage <= 31000:
                        return 5000;
                    case annualWage > 31000 && annualWage <= 32000:
                        return 4000;
                    case annualWage > 32000 && annualWage <= 33000:
                        return 3000;
                    case annualWage > 33000 && annualWage <= 34000:
                        return 2000;
                    case annualWage > 34000 && annualWage <= 35000:
                        return 1000;
                    case annualWage > 35000:
                        return 0;
                    default:
                        throw new Error(`Unsupported annualWage: ${annualWage}`);
                }
            case 'withholding code B':
                switch(true){
                    case annualWage > 0 && annualWage <= 38000:
                        return 19000;
                    case annualWage > 38000 && annualWage <= 39000:
                        return 18000;
                    case annualWage > 39000 && annualWage <= 40000:
                        return 17000;
                    case annualWage > 40000 && annualWage <= 41000:
                        return 16000;
                    case annualWage > 41000 && annualWage <= 42000:
                        return 15000;
                    case annualWage > 42000 && annualWage <= 43000:
                        return 14000;
                    case annualWage > 43000 && annualWage <= 44000:
                        return 13000;
                    case annualWage > 44000 && annualWage <= 45000:
                        return 12000;
                    case annualWage > 45000 && annualWage <= 46000:
                        return 11000;
                    case annualWage > 46000 && annualWage <= 47000:
                        return 10000;
                    case annualWage > 47000 && annualWage <= 48000:
                        return 9000;
                    case annualWage > 48000 && annualWage <= 49000:
                        return 8000;
                    case annualWage > 49000 && annualWage <= 50000:
                        return 7000;
                    case annualWage > 50000 && annualWage <= 51000:
                        return 6000;
                    case annualWage > 51000 && annualWage <= 52000:
                        return 5000;
                    case annualWage > 52000 && annualWage <= 53000:
                        return 4000;
                    case annualWage > 53000 && annualWage <= 54000:
                        return 3000;
                    case annualWage > 54000 && annualWage <= 55000:
                        return 2000;
                    case annualWage > 55000 && annualWage <= 56000:
                        return 1000;
                    case annualWage > 56000:
                        return 0;
                    default:
                        throw new Error(`Unsupported annualWage: ${annualWage}`);
                }
            case 'withholding code C':
                switch (true){
                    case annualWage > 0 && annualWage <= 48000:
                        return 24000;
                    case annualWage > 48000 && annualWage <= 49000:
                        return 23000;
                    case annualWage > 49000 && annualWage <= 50000:
                        return 22000;
                    case annualWage > 50000 && annualWage <= 51000:
                        return 21000;
                    case annualWage > 51000 && annualWage <= 52000:
                        return 20000;
                    case annualWage > 52000 && annualWage <= 53000:
                        return 19000;
                    case annualWage > 53000 && annualWage <= 54000:
                        return 18000;
                    case annualWage > 54000 && annualWage <= 55000:
                        return 17000;
                    case annualWage > 55000 && annualWage <= 56000:
                        return 16000;
                    case annualWage > 56000 && annualWage <= 57000:
                        return 15000;
                    case annualWage > 57000 && annualWage <= 58000:
                        return 14000;
                    case annualWage > 58000 && annualWage <= 59000:
                        return 13000;
                    case annualWage > 59000 && annualWage <= 60000:
                        return 12000;
                    case annualWage > 60000 && annualWage <= 61000:
                        return 11000;
                    case annualWage > 61000 && annualWage <= 62000:
                        return 10000;
                    case annualWage > 62000 && annualWage <= 63000:
                        return 9000;
                    case annualWage > 63000 && annualWage <= 64000:
                        return 8000;
                    case annualWage > 64000 && annualWage <= 65000:
                        return 7000;
                    case annualWage > 65000 && annualWage <= 66000:
                        return 6000;
                    case annualWage > 66000 && annualWage <= 67000:
                        return 5000;
                    case annualWage > 67000 && annualWage <= 68000:
                        return 4000;
                    case annualWage > 68000 && annualWage <= 69000:
                        return 3000;
                    case annualWage > 69000 && annualWage <= 70000:
                        return 2000;
                    case annualWage > 70000 && annualWage <= 71000:
                        return 1000;
                    case annualWage > 71000:
                        return 0;
                    default:
                        throw new Error(`Unsupported annualWage: ${annualWage}`);
                }
            case 'withholding code D':
                return 0;
            case 'withholding code F':
                switch(true){
                    case annualWage > 0 && annualWage <= 30000:
                        return 15000;
                    case annualWage > 30000 && annualWage <= 31000:
                        return 14000;
                    case annualWage > 31000 && annualWage <= 32000:
                        return 13000;
                    case annualWage > 32000 && annualWage <= 33000:
                        return 12000;
                    case annualWage > 33000 && annualWage <= 34000:
                        return 11000;
                    case annualWage > 34000 && annualWage <= 35000:
                        return 10000;
                    case annualWage > 35000 && annualWage <= 36000:
                        return 9000;
                    case annualWage > 36000 && annualWage <= 37000:
                        return 8000;
                    case annualWage > 37000 && annualWage <= 38000:
                        return 7000;
                    case annualWage > 38000 && annualWage <= 39000:
                        return 6000;
                    case annualWage > 39000 && annualWage <= 40000:
                        return 5000;
                    case annualWage > 40000 && annualWage <= 41000:
                        return 4000;
                    case annualWage > 41000 && annualWage <= 42000:
                        return 3000;
                    case annualWage > 42000 && annualWage <= 43000:
                        return 2000;
                    case annualWage > 43000 && annualWage <= 44000:
                        return 1000;
                    case annualWage > 44000:
                        return 0;
                    default:
                        throw new Error(`Unsupported annualWage: ${annualWage}`);
                }
            default:
                throw new Error(`Unsupported filing status: ${stateFilingType}`);
        }
    }

    //Federal Tax Utility Methods
    async getFederal_2b2c2d_Value(version,filingStatus,Federal2a){
        switch (version) {
            case "2019 and earlier":
                return await this.getFederal_2b2c2d_Value_2019(filingStatus, Federal2a);
    
            case "2020 and later":
                return await this.getFederal_2b2c2d_Value_2020(filingStatus, Federal2a);
    
            default:
                throw new Error(`Unsupported version: ${version}`);
        }
    }



    async getFederal_2b2c2d_Value_2019(filingStatus, Federal2a) {
        switch (filingStatus) {
            case "Married Filing Jointly":
            case "Married":
                switch (true) {
                    case Federal2a >= 0 && Federal2a < 16300:
                        {
                            const FederalTax_2b = 0;
                            const FederalTax_2c = 0;
                            const FederalTax_2d = 0;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 16300 && Federal2a < 39500:
                        {
                            const FederalTax_2b = 16300;
                            const FederalTax_2c = 0;
                            const FederalTax_2d = 10/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 39500 && Federal2a < 110600:
                        {
                            const FederalTax_2b = 39500;
                            const FederalTax_2c = 2320;
                            const FederalTax_2d = 12/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 110600 && Federal2a < 217350:
                        {
                            const FederalTax_2b = 110600;
                            const FederalTax_2c = 10852;
                            const FederalTax_2d = 22/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 217350 && Federal2a < 400200:
                        {
                            const FederalTax_2b = 217350;
                            const FederalTax_2c = 34337;
                            const FederalTax_2d = 24/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 400200 && Federal2a < 503750:
                        {
                            const FederalTax_2b = 400200;
                            const FederalTax_2c = 78221;
                            const FederalTax_2d = 32/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 503750 && Federal2a < 747500:
                        {
                            const FederalTax_2b = 503750;
                            const FederalTax_2c = 111357;
                            const FederalTax_2d = 35/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 747500:
                        {
                            const FederalTax_2b = 747500;
                            const FederalTax_2c = 196669.50;
                            const FederalTax_2d = 37/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    default:
                        throw new Error(`Unsupported Federal 2a Value: ${Federal2a}`);
                }

            case "Married Filing Separately":
            case "Single":
            case "Head of Household":
                switch (true) {
                    case Federal2a >= 0 && Federal2a < 6000:
                        {
                            const FederalTax_2b = 0;
                            const FederalTax_2c = 0;
                            const FederalTax_2d = 0;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 6000 && Federal2a < 17600:
                        {
                            const FederalTax_2b = 6000;
                            const FederalTax_2c = 0;
                            const FederalTax_2d = 10/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 17600 && Federal2a < 53150:
                        {
                            const FederalTax_2b = 17600;
                            const FederalTax_2c = 1160;
                            const FederalTax_2d = 12/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 53150 && Federal2a < 106525:
                        {
                            const FederalTax_2b = 53150;
                            const FederalTax_2c = 5426;
                            const FederalTax_2d = 22/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 106525 && Federal2a < 197950:
                        {
                            const FederalTax_2b = 106525;
                            const FederalTax_2c = 17168.50;
                            const FederalTax_2d = 24/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 197950 && Federal2a < 249725:
                        {
                            const FederalTax_2b = 197950;
                            const FederalTax_2c = 39110.50;
                            const FederalTax_2d = 32/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 249725 && Federal2a < 615350:
                        {
                            const FederalTax_2b = 249725;
                            const FederalTax_2c = 55678.50;
                            const FederalTax_2d = 35/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    case Federal2a >= 615350:
                        {
                            const FederalTax_2b = 615350;
                            const FederalTax_2c = 183647.25;
                            const FederalTax_2d = 37/100;
                            const federalTax2a2b2cData = {
                                FederalTax_2b: FederalTax_2b,
                                FederalTax_2c: FederalTax_2c,
                                FederalTax_2d: FederalTax_2d,
                            };
                            return federalTax2a2b2cData;
                        }

                    default:
                        throw new Error(`Unsupported Federal 2a Value: ${Federal2a}`);
                }
            // case "Head of Household":
            //     switch (true) {
            //         case Federal2a >= 0 && Federal2a < 13300:
            //             {
            //                 const FederalTax_2b = 0;
            //                 const FederalTax_2c = 0;
            //                 const FederalTax_2d = 0;
            //                 const federalTax2a2b2cData = {
            //                     FederalTax_2b: FederalTax_2b,
            //                     FederalTax_2c: FederalTax_2c,
            //                     FederalTax_2d: FederalTax_2d,
            //                 };
            //                 return federalTax2a2b2cData;
            //             }

            //         case Federal2a >= 13300 && Federal2a < 29850:
            //             {
            //                 const FederalTax_2b = 13300;
            //                 const FederalTax_2c = 0;
            //                 const FederalTax_2d = 10/100;
            //                 const federalTax2a2b2cData = {
            //                     FederalTax_2b: FederalTax_2b,
            //                     FederalTax_2c: FederalTax_2c,
            //                     FederalTax_2d: FederalTax_2d,
            //                 };
            //                 return federalTax2a2b2cData;
            //             }

            //         case Federal2a >= 29850 && Federal2a < 76400:
            //             {
            //                 const FederalTax_2b = 29850;
            //                 const FederalTax_2c = 1655;
            //                 const FederalTax_2d = 12/100;
            //                 const federalTax2a2b2cData = {
            //                     FederalTax_2b: FederalTax_2b,
            //                     FederalTax_2c: FederalTax_2c,
            //                     FederalTax_2d: FederalTax_2d,
            //                 };
            //                 return federalTax2a2b2cData;
            //             }

            //         case Federal2a >= 76400 && Federal2a < 113800:
            //             {
            //                 const FederalTax_2b = 76400;
            //                 const FederalTax_2c = 7241;
            //                 const FederalTax_2d = 22/100;
            //                 const federalTax2a2b2cData = {
            //                     FederalTax_2b: FederalTax_2b,
            //                     FederalTax_2c: FederalTax_2c,
            //                     FederalTax_2d: FederalTax_2d,
            //                 };
            //                 return federalTax2a2b2cData;
            //             }

            //         case Federal2a >= 113800 && Federal2a < 205250:
            //             {
            //                 const FederalTax_2b = 113800;
            //                 const FederalTax_2c = 15469;
            //                 const FederalTax_2d = 24/100;
            //                 const federalTax2a2b2cData = {
            //                     FederalTax_2b: FederalTax_2b,
            //                     FederalTax_2c: FederalTax_2c,
            //                     FederalTax_2d: FederalTax_2d,
            //                 };
            //                 return federalTax2a2b2cData;
            //             }

            //         case Federal2a >= 205250 && Federal2a < 257000:
            //             {
            //                 const FederalTax_2b = 205250;
            //                 const FederalTax_2c = 37417;
            //                 const FederalTax_2d = 32/100;
            //                 const federalTax2a2b2cData = {
            //                     FederalTax_2b: FederalTax_2b,
            //                     FederalTax_2c: FederalTax_2c,
            //                     FederalTax_2d: FederalTax_2d,
            //                 };
            //                 return federalTax2a2b2cData;
            //             }

            //         case Federal2a >= 257000 && Federal2a < 622650:
            //             {
            //                 const FederalTax_2b = 257000;
            //                 const FederalTax_2c = 53977;
            //                 const FederalTax_2d = 35/100;
            //                 const federalTax2a2b2cData = {
            //                     FederalTax_2b: FederalTax_2b,
            //                     FederalTax_2c: FederalTax_2c,
            //                     FederalTax_2d: FederalTax_2d,
            //                 };
            //                 return federalTax2a2b2cData;
            //             }

            //         case Federal2a >= 622650:
            //             {
            //                 const FederalTax_2b = 622650;
            //                 const FederalTax_2c = 181954.50;
            //                 const FederalTax_2d = 37/100;
            //                 const federalTax2a2b2cData = {
            //                     FederalTax_2b: FederalTax_2b,
            //                     FederalTax_2c: FederalTax_2c,
            //                     FederalTax_2d: FederalTax_2d,
            //                 };
            //                 return federalTax2a2b2cData;
            //             }

                //     default:
                //         throw new Error(`Unsupported Federal 2a Value: ${Federal2a}`);
                // }


            default:
                throw new Error(`Unsupported Filing Status: ${filingStatus}`);
        }
    }

    async getFederal_2b2c2d_Value_2020(filingStatus, Federal2a){
        switch (filingStatus) {
            case "Married Filing Jointly":
            case "Married":
                return await this.getFederal_2b2c2d_Value_MarriedFilingJointly_2020(Federal2a);
            
            case "Single":
            case "Married Filing Separately":
                return await this.getFederal_2b2c2d_Value_MarriedFilingSeparately_2020(Federal2a);
            
            case "Head of Household":
                return await this.getFederal_2b2c2d_Value_HeadOfHousehold_2020(Federal2a);
            
            default:
                throw new Error(`Unsupported filing status: ${filingStatus}`);
        }

    }

    async getFederal_2b2c2d_Value_MarriedFilingJointly_2020(Federal2a) {
        switch (true) {
            case Federal2a >= 0 && Federal2a < 14600:
                {
                    const FederalTax_2b = 0;
                    const FederalTax_2c = 0;
                    const FederalTax_2d = 0;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 14600 && Federal2a < 26200:
                {
                    const FederalTax_2b = 14600;
                    const FederalTax_2c = 0;
                    const FederalTax_2d = 10/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 26200 && Federal2a < 61750:
                {
                    const FederalTax_2b = 26200;
                    const FederalTax_2c = 1160;
                    const FederalTax_2d = 12/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 61750 && Federal2a < 115125:
                {
                    const FederalTax_2b = 61750;
                    const FederalTax_2c = 5426;
                    const FederalTax_2d = 22/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 115125 && Federal2a < 206550:
                {
                    const FederalTax_2b = 115125;
                    const FederalTax_2c = 17168.50;
                    const FederalTax_2d = 24/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 206550 && Federal2a < 258325:
                {
                    const FederalTax_2b = 206550;
                    const FederalTax_2c = 39110.50;
                    const FederalTax_2d = 32/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 258325 && Federal2a < 380200:
                {
                    const FederalTax_2b = 258325;
                    const FederalTax_2c = 55678.50;
                    const FederalTax_2d = 35/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 380200:
                {
                    const FederalTax_2b = 380200;
                    const FederalTax_2c = 98334.75;
                    const FederalTax_2d = 37/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            default:
                throw new Error(`Unsupported Federal 2a Value: ${Federal2a}`);
        }
    }
    
    async getFederal_2b2c2d_Value_MarriedFilingSeparately_2020(Federal2a) {
        switch (true) {
            case Federal2a >= 0 && Federal2a < 7300:
                {
                    const FederalTax_2b = 0;
                    const FederalTax_2c = 0;
                    const FederalTax_2d = 0;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 7300 && Federal2a < 13100:
                {
                    const FederalTax_2b = 7300;
                    const FederalTax_2c = 0;
                    const FederalTax_2d = 10/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 13100 && Federal2a < 30875:
                {
                    const FederalTax_2b = 13100;
                    const FederalTax_2c = 580;
                    const FederalTax_2d = 12/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 30875 && Federal2a < 57563:
                {
                    const FederalTax_2b = 30875;
                    const FederalTax_2c = 2713;
                    const FederalTax_2d = 22/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 57563 && Federal2a < 103275:
                {
                    const FederalTax_2b = 57563;
                    const FederalTax_2c = 8584.25;
                    const FederalTax_2d = 24/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 103275 && Federal2a < 129163:
                {
                    const FederalTax_2b = 103275;
                    const FederalTax_2c = 19555.25;
                    const FederalTax_2d = 32/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 129163 && Federal2a < 311975:
                {
                    const FederalTax_2b = 129163;
                    const FederalTax_2c = 27839.25;
                    const FederalTax_2d = 35/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 311975:
                {
                    const FederalTax_2b = 311975;
                    const FederalTax_2c = 91823.63;
                    const FederalTax_2d = 37/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            default:
                throw new Error(`Unsupported Federal 2a Value: ${Federal2a}`);
        }
    }
    
    async getFederal_2b2c2d_Value_HeadOfHousehold_2020(Federal2a) {
        switch (true) {
            case Federal2a >= 0 && Federal2a < 10950:
                {
                    const FederalTax_2b = 0;
                    const FederalTax_2c = 0;
                    const FederalTax_2d = 0;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 10950 && Federal2a < 19225:
                {
                    const FederalTax_2b = 10950;
                    const FederalTax_2c = 0;
                    const FederalTax_2d = 10/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 19225 && Federal2a < 42500:
                {
                    const FederalTax_2b = 19225;
                    const FederalTax_2c = 827.50;
                    const FederalTax_2d = 12/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 42500 && Federal2a < 61200:
                {
                    const FederalTax_2b = 42500;
                    const FederalTax_2c = 3620.50;
                    const FederalTax_2d = 22/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 61200 && Federal2a < 106925:
                {
                    const FederalTax_2b = 61200;
                    const FederalTax_2c = 7734.50;
                    const FederalTax_2d = 24/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 106925 && Federal2a < 132800:
                {
                    const FederalTax_2b = 106925;
                    const FederalTax_2c = 18708.50;
                    const FederalTax_2d = 32/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 132800 && Federal2a < 315625:
                {
                    const FederalTax_2b = 132800;
                    const FederalTax_2c = 26988.50;
                    const FederalTax_2d = 35/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            case Federal2a >= 315625:
                {
                    const FederalTax_2b = 315625;
                    const FederalTax_2c = 90977.25;
                    const FederalTax_2d = 37/100;
                    const federalTax2a2b2cData = {
                        FederalTax_2b: FederalTax_2b,
                        FederalTax_2c: FederalTax_2c,
                        FederalTax_2d: FederalTax_2d,
                    };
                    return federalTax2a2b2cData;
                }
    
            default:
                throw new Error(`Unsupported Federal 2a Value: ${Federal2a}`);
        }
    }
    

    // async getFedral_2b2c2d_Value(fillingStatus,Federal2a){
    //     switch (fillingStatus) {
    //         case "Married Filling Jointly":
    //             switch (true) {
    //                 case  Federal2a >= 0 && Federal2a < 14800:
    //                     {
    //                     const FederalTax_2b = 0
    //                     const FederalTax_2c = 0
    //                     const FederalTax_2d = 0
    //                     const federalTax2a2b2cData = {
    //                         FederalTax_2b: FederalTax_2b,
    //                         FederalTax_2c: FederalTax_2c,
    //                         FederalTax_2d: FederalTax_2d,
    //                     }
    //                     return federalTax2a2b2cData
    //                 }

    //                     case  Federal2a >= 14800 && Federal2a < 36800:{
    //                         const FederalTax_2b = 14800
    //                         const FederalTax_2c = 0
    //                         const FederalTax_2d = 10
    //                         const federalTax2a2b2cData = {
    //                             FederalTax_2b: FederalTax_2b,
    //                             FederalTax_2c: FederalTax_2c,
    //                             FederalTax_2d: FederalTax_2d,
    //                         }
    //                         return federalTax2a2b2cData
    //                     }                    
    //                 default:
    //                     throw new Error(`Unsupported Federal 2a Value : ${Federal2a}`);
    //             }

    //         default:
    //             throw new Error(`Unsupported Filling Status : ${fillingStatus}`);
    //     }
    // }

}