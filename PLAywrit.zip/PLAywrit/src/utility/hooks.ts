import { BeforeAll, Before, AfterAll, After, AfterStep, setDefaultTimeout, ITestStepHookParameter, ITestCaseHookParameter, World } from "@cucumber/cucumber"
const { chromium, firefox, webkit } = require('playwright');
import { LoggerUtil } from "./logger";
import{getSecret} from './secureCredentials'
import * as dotenv from 'dotenv'
import { JsonOperations } from "./jsonOperations";
import { exec } from 'child_process';
import { CucumberRailClient } from "./testrail-integration";
import fs from 'fs';
import path from 'path'
import { CommonUtils } from "./commonUtils";
import { slackNotificationMsg } from "./slackNotificationMsg";
import * as yaml from 'js-yaml';
import { APIUtil } from "./apiUtil";
import { UbServices } from '../API/classes/ub_hub/ubServices';

dotenv.config()

const apiService = new UbServices();
let log = new LoggerUtil()
const testrail = ""
let today = new Date()
let jsonUtil = new JsonOperations()
let CommonUtil = new CommonUtils()
let slackMsg = new slackNotificationMsg()
let passedScenarios = 0
let failedScenarios = 0
let skippedScenarios = 0
let ambiguousScenarios = 0

let apiUtil = new APIUtil()
let testRailUsername;
let testRailPassword;
let testRailUrl;
setDefaultTimeout(300000);
// Launch options.
const options = {
    headless: false,
    channel: "chrome",
    args: ["--window-position=-5,-5"]
};

const optionsBrowser = {
    headless: false,
    args: ["--window-position=-5,-5"]

};


const optionsTestRail = {
    username: `${process.env.user_name}`,
    password: `${process.env.password}`,
    url: `${process.env.url}`

};

BeforeAll(async function (this: World) {
    
    let node_browser: any = process.env.Browser
    switch (node_browser) {
        case "chromium":
            global.browser = await chromium.launch(options);
            break;
        case "firefox":
            global.browser = await firefox.launch(optionsBrowser);
            break;
        case "safari":
            global.browser = await webkit.launch(optionsBrowser);
            break;

        default:
            break;
    }


    global.testrails = new CucumberRailClient(optionsTestRail);
})



Before({timeout: 300*7000},async (scenario: ITestCaseHookParameter) => {
    const secretvalue = await getSecret('BASE_URL1',"BASE_URL");
    testRailUsername = await  getSecret('TestRail.Credentials','Testrail.Username');
    testRailPassword = await getSecret('TestRail.Credentials','Testrail.Password');
    testRailUrl = await getSecret('TESTRAIL_URL','TESTRAIL_URL');
    global.cityCodeValue = await CommonUtil.getCityCodeValueforExecution();
    global.context = await global.browser.newContext({
     downloadsPath: './src/resources/results',
     recordVideo: {
       dir: './src/resources/reports/videos/' + scenario.pickle.name,
     },
     reporter:[
 
         [
       'allure-playwright',
       {
         detail: true,
         outputFolder: 'src/resources/reports/allure-results',
         suiteTitle: true,
       },
     ],
     ]
 
     
   });
   global.page = await global.context.newPage();
   const TestCase_Name = scenario.pickle.name;
   const scenarioTags = scenario.pickle.tags.map((tag) => tag.name);
   console.log('Current scenario tags:', scenarioTags);
    await log.startFeature(TestCase_Name)
    await global.page.goto(secretvalue, { timeout: 100000 })
    await global.page.waitForLoadState();
    let str = secretvalue
    //if(str?.includes("stg")){
    // await CommonUtil.loginPage(process.env.BASE_URL, process.env.cityCode)
    try {
        await CommonUtil.loginPage(secretvalue, global.cityCodeValue, scenarioTags);
        let pages = await global.context.pages();
        await pages[1].bringToFront();
        global.page = pages[1];
        if (scenarioTags.includes('@api')) {
            global.BearerToken = await apiUtil.getBearerToken();
            console.log("BearerToken: " + global.BearerToken);
            if (scenarioTags.includes('@ubhub')) {
                await apiService.getServiceCode();
            }
        } 
        if (scenarioTags.includes('@financeHub')) {
              await global.page.waitForTimeout(10000);
              await global.page.locator("//span[text()='Finance']").click();
              await log.info('Clicked on Front Desk Finance Hub menu');
              //Work around steps for Closing finance tab
              await global.page.waitForTimeout(9000);
              await global.page.waitForLoadState();
              await global.page.waitForLoadState();
              //await global.page.locator("//p[text()='Finance']").click()
              //await global.page.waitForTimeout(2000)
              global.TestEnvironment = await CommonUtil.getTestEnvironmentURL();
              global.ExecutionCityName = await CommonUtil.getExecutionCityName();
        
      } 
      else if (scenarioTags.includes('@hrhub')) {
         
          if(!await global.page.isVisible("//*[text()='Employees']")){
                  await global.page.locator("//*[text()='HR']").click()
                  await global.page.locator("//*[text()='Employees']").click()
             }
              await global.page.waitForLoadState('load', { timeout: 150000 });
              //Work around steps for Closing HR tab
              await global.page.waitForTimeout(2000)
              await global.page.locator("//h2[@id='gw-side-nav-heading1']").click()
              await await global.page.waitForTimeout(2000)
              global.TestEnvironment = await CommonUtil.getTestEnvironmentURL()
              global.ExecutionCityName = await CommonUtil.getExecutionCityName()
  
  
      } 
      else if (scenarioTags.includes('@ubhub')) {
        await global.page.locator("//span[text()='Utility Billing']").click();
        await log.info('Clicked on Front Desk UB side menu');
  
        // Work around steps for Closing UB tab
        await global.page.waitForTimeout(15000);
        await global.page.waitForLoadState('load', { timeout: 200000 });
        await global.page.locator("//p[text()='Utility Billing']").click();
        await global.page.waitForLoadState('load', { timeout: 150000 });
        await global.page.waitForTimeout(15000);
        global.TestEnvironment = await CommonUtil.getTestEnvironmentURL();
        global.ExecutionCityName = await CommonUtil.getExecutionCityName();
        global.BearerToken = await apiUtil.getBearerToken();
        
      } else if (scenarioTags.includes('@opsSmoke')) {
          if(scenarioTags.includes('@opshub'))
          {
              // await global.page.locator("//span[text()='Operations']").click();
              // await log.info('Clicked on Front Desk Operation Hub menu');
               await global.page.locator("//span[text()='Utility Billing']").click();
               await log.info('Clicked on Front Desk UB side menu');
               await global.page.waitForTimeout(9000);
               await global.page.waitForLoadState();
          }
          else
          {
               await global.page.locator("//span[text()='Utility Billing']").click();
               await log.info('Clicked on Front Desk UB side menu');
  
        // Work around steps for Closing UB tab
              await global.page.waitForTimeout(15000);
              await global.page.waitForLoadState('load', { timeout: 200000 });
          }
       
      }
  
      else{
       await global.page.locator("//span[text()='Utility Billing']").click();
        await log.info('Clicked on Front Desk UB side menu');
  
        // Work around steps for Closing UB tab
        await global.page.waitForTimeout(15000);
        await global.page.waitForLoadState('load', { timeout: 200000 });
        await global.page.locator("//p[text()='Utility Billing']").click();
        await global.page.waitForLoadState('load', { timeout: 150000 });
        await global.page.waitForTimeout(15000);
         
      }
    } 
    catch (error) {
      console.error('The page failed to load. An attempt will be made to refresh the page....');
      await global.page.reload();
    }
  });

//For Login with Portal for HR hub Payroll Calculation
// Before(async (scenario: ITestCaseHookParameter) => {
//     const cityCodeValue = await CommonUtil.getCityCodeValueforExecution()
//     global.context = await global.browser.newContext({
//         downloadsPath: './src/resources/results',
//         recordVideo: {
//             dir: './src/resources/reports/videos/' + scenario.pickle.name,
//         }
//     })
//     global.page = await global.context.newPage()
//     let TestCase_Name = scenario.pickle.name
//     await log.startFeature(TestCase_Name)
//     await global.page.goto(process.env.BASE_URL, { timeout: 100000 })
//     await global.page.waitForLoadState();
//     let str = process.env.BASE_URL
//     //if(str?.includes("stg")){
//     // await CommonUtil.loginPage(process.env.BASE_URL, process.env.cityCode)
//     await CommonUtil.loginPage(process.env.BASE_URL, cityCodeValue)
//     let pages = await global.context.pages();
//     await pages[1].bringToFront();
//     global.page = pages[1]
//     await global.page.locator("//span[text()='HR']").click()
//     await global.page.locator("//a[text()='Employees']").click()
//     //Work around steps for Closing HR tab
//     await global.page.waitForTimeout(2000)
//     await global.page.waitForLoadState();
//     await global.page.locator("//h2[@id='gw-side-nav-heading1']").click()
//     await await global.page.waitForTimeout(2000)
// })

//For Login with Portal for Finance Hub
// Before(async (scenario: ITestCaseHookParameter) => {
//     const cityCodeValue = await CommonUtil.getCityCodeValueforExecution()
//     global.context = await global.browser.newContext({
//         downloadsPath: './src/resources/results',
//         recordVideo: {
//             dir: './src/resources/reports/videos/' + scenario.pickle.name,
//         }
//     })
//     global.page = await global.context.newPage()
//     let TestCase_Name = scenario.pickle.name
//     await log.startFeature(TestCase_Name)
//     await global.page.goto(process.env.BASE_URL, { timeout: 100000 })
//     await global.page.waitForLoadState();
//     let str = process.env.BASE_URL
//     //if(str?.includes("stg")){
//     // await CommonUtil.loginPage(process.env.BASE_URL, process.env.cityCode)
//     await CommonUtil.loginPage(process.env.BASE_URL, cityCodeValue)
//     let pages = await global.context.pages();
//     await pages[1].bringToFront();
//     global.page = pages[1]
//     await global.page.locator("//span[text()='Finance']").click()
//     await log.info("Clicked on Front Desk Finance Hub menu")
//     //Work around steps for Closing finance tab
//     await global.page.waitForTimeout(2000)
//     await global.page.waitForLoadState();
//     //await global.page.locator("//p[text()='Finance']").click()
//     //await global.page.waitForTimeout(2000)
// })


After({ tags: '@attachFile' }, async function (this: World, scenario: ITestCaseHookParameter) {
    let TestCase_Name = scenario.pickle.name
    console.log("Name:", TestCase_Name)
    const scenario_number = TestCase_Name.split("Scenario", 2)
    console.log("TestCase Number : ", scenario_number[1])
    const scenarioNumber = scenario_number[1].trim()
    const folderPath = './src/resources/data/tempFiles/';
    const file = `Scenario${scenarioNumber}.txt`
    const filePath = path.join(folderPath, file);
    try {
        const fileContent = await fs.readFileSync(filePath);
        await this.attach(fileContent, 'text/plain');
    } catch (error) {
        console.log(`Error attaching file ${filePath}: ${error}`);
    }
})

After({ tags: '@attachFileScenarioCombo' }, async function (this: World, scenario: ITestCaseHookParameter) {
    let TestCase_Name = scenario.pickle.name
    console.log("Name:", TestCase_Name)
    const scenario_number = TestCase_Name.split("Scenario", 2)
    console.log("TestCase Number : ", scenario_number[1])
    const scenarioNumber = scenario_number[1].trim()
    const folderPath = './src/resources/data/tempFiles/';
    const file = `SalaryComboScenario${scenarioNumber}.txt`
    const filePath = path.join(folderPath, file);
    try {
        const fileContent = await fs.readFileSync(filePath);
        await this.attach(fileContent, 'text/plain');
    } catch (error) {
        console.log(`Error attaching file ${filePath}: ${error}`);
    }
})

After({ tags: '@attachMDMDownloadedFiles' }, async function (this: World, scenario: ITestCaseHookParameter) {
    const jsonData1 = await jsonUtil.readData(`tempFiles/DownloadedFile.json`)
    const filename = await jsonData1.DownloadedFileName
    const folderPath = `./src/resources/results/`;
    const file = `${filename}`
    const filePath = path.join(folderPath, file);
    try {
        const fileContent = await fs.readFileSync(filePath)
        const fileExtention = file.split(".", 2)
        // const contentType = file.endsWith('.csv') ? 'text/csv' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        const contentType = await CommonUtil.getContentTypeToAttachFile(fileExtention[1])
        await this.attach(fileContent, contentType)

    } catch (error) {
        console.log(`Error attaching file ${filePath}: ${error}`)
    }
})

After({ tags: '@attachMDMDownloadedFilesVerification' }, async function (this: World, scenario: ITestCaseHookParameter) {
    const jsonData1 = await jsonUtil.readData(`tempFiles/DownloadedFile.json`)
    const filename = await jsonData1.DownloadedFileName
    const folderPath = `./src/resources/data/tempFiles/`;
    const file = `${filename}.txt`
    const filePath = path.join(folderPath, file);
    try {
        const fileContent = await fs.readFileSync(filePath);
        await this.attach(fileContent, 'text/plain');
    } catch (error) {
        console.log(`Error attaching file ${filePath}: ${error}`);
    }
})

After({ tags: '@attachFileMDMUploadVerification' }, async function (this: World, scenario: ITestCaseHookParameter) {
    let TestCase_Name = scenario.pickle.name
    console.log("Name:", TestCase_Name)
    const venodrName = TestCase_Name.split("for", 2)
    console.log("TestCase Number : ", venodrName[1])
    const venodr_Name = venodrName[1].trim()
    const folderPath = './src/resources/data/tempFiles/';
    const file = `${venodr_Name}.txt`
    const filePath = path.join(folderPath, file);
    try {
        const fileContent = await fs.readFileSync(filePath);
        await this.attach(fileContent, 'text/plain');
    } catch (error) {
        console.log(`Error attaching file ${filePath}: ${error}`);
    }
})

After(async function (this: World, scenario: ITestCaseHookParameter) {
    const scenarioStatus = scenario.result?.status
    await log.info("Test Case Execution Status :" + scenarioStatus)
    await log.endFeature();
    let sspath = process.env.LogPath + `/screenshot/${scenario.pickle.name}.png`;
    let ss = ""
    if (scenarioStatus === 'FAILED') {
        await log.info(scenario.result?.message)
        ss = await global.page.screenshot({
            path: sspath
        })
        await this.attach(ss, "image/png");
    }

    if (scenarioStatus === 'PASSED') {
        passedScenarios++;
    } else if (scenarioStatus === 'FAILED') {
        failedScenarios++;
    } else if (scenarioStatus === 'SKIPPED') {
        skippedScenarios++;
    } else if (scenarioStatus === 'AMBIGUOUS') {
        ambiguousScenarios++;
    }
    await global.page.waitForTimeout(5000)
    await global.page.close();
    await global.context.close();

})

After({ timeout: 100 * 3000 }, async (scenario) => {

    console.log(`Scenario  ${scenario.result?.status.toString()}`);
    const runid = process.env.runid;
    const version = process.env.version


    try {
        await global.testrails.updateTestRailResults(scenario, runid, version)
    } catch (err) {

        console.log("Error " + err);
    }
})



AfterAll(async () => {
    await global.browser.close();
    const totalTest = passedScenarios + failedScenarios
    const slackMessage = await slackMsg.slackNotificationMessage("OPS Smoke",global.ExecutionCityName,global.TestEnvironment,totalTest,passedScenarios,failedScenarios,skippedScenarios,ambiguousScenarios)
    //await CommonUtil.sendMessageToSlack(slackMessage) // To send result in slack message
    
    
    await jsonUtil.deleteTempFiles()
    // const cwd = process.cwd();
    // const scriptPermission = `chmod +x ${cwd}/src/reporter/report.sh`;
    // const scriptPath = `${cwd}/src/reporter/report.sh`;
    // exec(scriptPermission, async (error, stdout, stderr) => {
    //     if (error) {
    //       await log.error(`exec error: ${error}`);
    //       return;
    //     }
    //   });
    // exec(scriptPath, async (error, stdout, stderr) => {
    //     if (error) {
    //       await log.error(`exec error: ${error}`);
    //       return;
    //     }
    //   });
})