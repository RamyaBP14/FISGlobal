import { expect, test } from "@playwright/test";
import user from "os";
import fs from "fs";
import moment from "moment";
import { LoggerUtil } from "./logger";
import Chance from "chance";
import DomParser from 'dom-parser';
import { randomBytes } from 'crypto';

let log = new LoggerUtil();
let chance = new Chance();

export class PageBase {
  async click(locators: any) {
    await global.page.click(locators);
    await log.info("Clicked on element " + locators);
  }
  // This method is for intercepts pointer events where we are not able to click like calenders button
  async forceclick(locators: any) {
    await global.page.click(locators,{ force: true });
    await log.info("Forced clicked on element " + locators);
  }

    async clickKeyByName(keyName: any) {
        await global.page.keyboard.press(keyName);
        await log.info("Clicked key " + keyName);
    }

    async navigate(url: any) {
        await global.page.goto(url);
        await log.info("Navigated to " + url);
    }

    async waitForLoad() {
        await global.page.waitForLoadState();
        await log.info("Waiting for page load");
    }

    async close() {
        await global.page.close();
        await log.info("Page closed");
    }

    async clickYesModal() {
        let locators = "text = Yes";

        await global.page.click(locators);
        await log.info("Clicked on yes modal" + locators);
    }

    async clickSaveModal() {
        let locators = "//button[@id='map_save']";

        await global.page.click(locators);
        await log.info("Clicked on save modal" + locators);
    }

    async enter(locators: any, value: any) {
        await global.page.fill(locators, value);
        await log.info('Entered value: "' + value + '" in element: "' + locators + '"');
    }

    async type(locators: any, value: any) {
        await global.page.type(locators, value);
        await log.info('Entered value: "' + value + '" in element: "' + locators + '"');
    }

    async clear(locators: any) {
        await global.page.fill(locators, "");
        await log.info("Cleared element" + locators);
    }

    async selectByValue(locators: any, value: any) {
        await global.page.selectOption(locators, value);

        await log.info("Selected value is " + value + " in " + locators);
    }

    async selectValue(loc: any, value: any) {
        var locator = loc + "//*[contains(text(), 'value')]";
        await global.page.click(locator.replace("value", value));
        await log.info("Selected value is " + value);
    }

    async selectByIndex(locators: any, index: number) {
        await global.page.selectOption(locators, { index: index });
        await log.info("Selected value on " + index + " position in " + locators);
    }

    async selectMultipleValue(locators: any, value: string[]) {
        await global.page.selectOption(locators, value);
        await log.info("Selected value is " + value + " in " + locators);
    }

    async isChecked(locators: any) {
        let isCheck = await global.page.isChecked(locators)
        if (isCheck) {
            await log.info(locators, "is selected");
        } else {
            await log.info(locators, "is not selected");
        }
        return isCheck;
    }

    async isEnabled(locators: any) {
        var isEnable = false;
        try {
            await global.page.isEnabled(locators);
            await log.info(locators + " is enabled");
            isEnable = true;
        } catch (error) {
            await log.info(locators + " is not enabled");
        }
        return isEnable;
    }
    async isEnabledCheck(locator) {
        return await global.page.isEnabled(locator)
    }

    async isElementEnabled(locators: any) {
        var isEnable = false;
        if (await global.page.isEnabled(locators)) {
            return isEnable = true;
        }
        else {
            return isEnable
        }
    }


    async isDisabled(locators: any) {
        var isDisabled = false;

        await global.page.isDisabled(locators);
        await log.info(locators, "is disabled");
        isDisabled = true;

        return isDisabled;
    }

    async isVisible(locators: any) {
        var isCheck = false;
        try {
            isCheck = await global.page.isVisible(locators);
            if (isCheck) {
                await log.info(locators + " is visible");
                return isCheck;
            } else {
                await log.info(locators + " is not visible");
            }
        } catch (error) {
            await log.info(locators + " is not visible");
        }
        return isCheck;
    }

    async jsEval(val) {
        return await global.page.evaluate(val);
    }
    async getTextsInListForPDFValidation(locators: any) {

        var content: string[] = new Array();
        var elements = await global.page.$$(locators);
        let tableColumnString = ""
        for (let index = 0; index < elements.length; index++) {
    
          tableColumnString =  tableColumnString + await elements[index].innerText()
        }
        // elements.forEach(async ele => content.push(await ele.innerText()))
        await log.info("Text is" + tableColumnString);
      return tableColumnString;
      }

      async formatValue(value: number) {
        const roundedValue = Math.round(value * 100) / 100; // Round to two decimal places
        return roundedValue.toFixed(2); // Convert to string with two decimal places
    }

    async getText(locators: any) {
        var content = await global.page.textContent(locators);
        await log.info("Text is " + content);
        return content;
    }

  async getTrimmedText(locators: any){
    var content = (await global.page.textContent(locators)).trim();
    await log.info("Text is " + content);
    return content;
  }

    async getElement(locators: any) {
        var content = await global.page.textContent(locators);
        await log.info("Text is " + content);
        return content;
    }

    async getElements(locators: any) {
        const content = await global.page.$$(locators);
        return content;
    }

    async getWebElement(locators: any) {
        const webElement = await global.page.$(locators);
        return webElement;
    }

    async refresh() {
        await global.page.reload();
        await log.info("Reloading page");
        await this.waitForLoad();
    }

    async getTextsInList(locators: any) {
        var content: string[] = new Array();
        var count = 0;
        var elements = await global.page.$$(locators);
        for (let index = 0; index < elements.length; index++) {
            content.push(await elements[index].innerText());
        }
        // elements.forEach(async ele => content.push(await ele.innerText()))
        await log.info("Text is" + content);
        return content;
    }

    async getInnerText(locators: any) {
        var content = await global.page.innerText(locators);
        await log.info("Text is " + content);
        return content;
    }

    async getAttribute(locators: any, attrName) {
        let attr = "";

        attr = await global.page.getAttribute(locators, attrName);
        await log.info("Attribute of " + locators + "is " + attr);

        return attr;
    }

    async sleep(timeOut: number) {
        await log.info("sleep(" + timeOut + ")");
        await global.page.waitForTimeout(timeOut);
    }

    async takeScreenshot(location) {
        await global.page.screenshot({ path: location, fullPage: true });
        await log.info("Screenshot is located at " + location);
    }

    async dblClick(locators: any) {
        await global.page.dblclick(locators);
    }
    async waitForSelector(locators: any, time: number) {
        await log.info("Waiting for selector " + locators);
        if (await global.page.waitForSelector(locators, { timeout: time })) {
            await log.info("Element is visible " + locators);
            return true;
        } else {
            await log.info("Following element not visible" + locators);
            return false;
        }
    }

    async scrollOnElement(selector, x, y) {
        await global.page.evaluate(
            ([selector, x, y]) => {
                const element = document.querySelector(selector);
                console.log(element);
                element.scroll(x, y);
            },
            [selector, x, y]
        );
        await log.info("Scrolling 500 px");
    }

    async scrollDown(element) {
        // await global.page.scrollBy(0,1000)

        try {
            const locator = global.page.locator(element)
            await locator.scrollIntoViewIfNeeded()
            await log.info("Scrolling 500 px");
        } catch (error) {
            // await locator.scrollIntoViewIfNeeded()
            await log.info(error);
        }

    }

    async verifyText(locators: any, text: string) {
        var text_msg = "";

        await global.page.waitForSelector(locators, { timeout: 40000 });
        text_msg = await global.page.innerText(locators);
        expect(text_msg).toBe(text);
        await log.info(
            "Actual value is matching with expected value \n" +
            " Actual value   : " +
            text_msg +
            "\n Expected value : " +
            text
        );
        return true;
    }

    // async verifyTextMessage(actual: any, expected: any) {

    //         global.expect(actual).toBe(expected);
    //         await log.info("Actual value is matching with expected value \n" + " Actual value   : " + actual + "\n Expected value : " + expected);
    //         return true;

    //         //;
    //         ("Actual is not matching with expected value \n" + " Actual value   : " + actual + "\n Expected value : " + expected);
    //         return false;
    //     }
    // }

    async dateFormat(dateNew, form) {
        let isoDate = dateNew;

        let newDate = moment.utc(dateNew).format(form);
        await log.info("converted date", newDate);
        return newDate;
    }

    async downloadFile(locator: any, file) {
        const [download] = await Promise.all([
            global.page.waitForEvent("download"),
            global.page.locator(locator).click(),
        ]);

        const path = download.suggestedFilename();
        await download.saveAs(file + path);

        await log.info("File downloaded successfully");
        return file + path;
    }

    async randomString(len) {
        var charSet =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        var randomString = "";
        for (var i = 0; i < len; i++) {
            var randomPoz = Math.floor(Math.random() * charSet.length);
            randomString += charSet.substring(randomPoz, randomPoz + 1);
        }
        return randomString;
    }

    async randomNum(len) {
        var charSet = "0123456789";
        var randomString = "";
        for (var i = 0; i < len; i++) {
            var randomPoz = Math.floor(Math.random() * charSet.length);
            randomString += charSet.substring(randomPoz, randomPoz + 1);
        }
        return randomString;
    }

    async check(locators: any) {
        await global.page.check(locators);
        await log.info("Checked the element " + locators);
    }

    async uncheck(locators: any) {
        await global.page.uncheck(locators);
        await log.info("Unchecked the element " + locators);
    }
    async getTitle() {
        var content = await global.page.title();
        await log.info("Title is " + content);
        return content;
    }
    async getUrl() {
        var content = await global.page.url();
        await log.info("url is " + content);
        return content;
    }

    async getFocus(locators: any) {
        await global.page.focus(locators);
    }

    async pressEnd() {
        await global.page.keyboard.press("End");
    }

    async pressEnter() {
        await global.page.keyboard.press("Enter");
        await global.page.waitForTimeout(4000);
    }

    // async type(locators: any, value: any) {
    //
    //         await global.page.type(locators, value);
    //         await log.info("types value"+ value, "in element"+ locators);
    //
    //         ;
    //     }
    // }

    async pass(Expected: any, Actual: any) {
        await log.info(
            "Actual value is matching with expected value \n" +
            " Actual value   : " +
            Actual +
            "\n Expected value : " +
            Expected
        );
    }

    async fail(Expected: any, Actual: any) {
        "Actual value is matching with expected value \n" +
            " Actual value   : " +
            Actual +
            "\n Expected value : " +
            Expected;
    }

    async windowHandling(locator: any) {
        const [window] = await Promise.all([
            global.context.waitForEvent("page"),
            await this.click(locator),
        ]);
        await window.waitForLoadState();

        await log.info("window handling success");

        return window;
    }

    async windowsHandling(locator: any) {
        const [window] = await Promise.all([
            global.context.waitForEvent("page"),
            await this.click(locator),
        ]);
        await window.waitForLoadState();

        await log.info("window handling success");

        const allWindows = window.context().pages();

        return allWindows;
    }

    async frame(value: any) {
        const frame = global.page.frame({ name: '"' + value + '"' });

        return frame;
    }

    // TODO: No reason to be asynchronous
    async getRandomString(length) {
        var randomChars =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        var result = "";
        for (var i = 0; i < length; i++) {
            result += randomChars.charAt(
                Math.floor(Math.random() * randomChars.length)
            );
        }
        return result;
    }

    // TODO: No reason to be asynchronous
    async getRandomInt(length) {
        let randomChars = "0123456789";
        let result = "";
        for (var i = 0; i < length; i++) {
            result += randomChars.charAt(
                Math.floor(Math.random() * randomChars.length)
            );
        }
        return result;
    }

    async getRandomIntForNumber(maxNumber: number ) {
      const result = Math.floor(Math.random() * maxNumber) ;
      return result;
    }

    async upload(file: any, locator: any) {
        await global.page.once("filechooser", async (filechooser) => {
            await filechooser.setFiles([file]);
        });
        await this.click(locator);
        await log.info("File uploaded");
    }

    async handleAlert() {
        global.page.on("dialog", async (alert) => {
            await log.info("Alert Message: " + alert.message());
            await alert.accept();
            await log.info("Alert acceppted");
        });
    }

    async download(locator: any) {
        const [download] = await Promise.all([
            global.page.waitForEvent("download"),
            global.page.locator(locator).click(),
        ]);
        const path = "./Common/Framework/resources/data/Download/";
        const fileName = download.suggestedFilename();
        await download.saveAs(path + fileName);
        return path + fileName;
    }

    async checkFilePresent(path: any) {
        if (fs.existsSync(path)) {
            await log.info("file exists:" + path);
        } else {
            "file DOES NOT exist:" + path;
        }
    }

    async dateFormatmmddyyyy() {
        let dd: Date = new Date();
        var dd1 = String(dd.getDate()).padStart(2, "0");
        var mm = String(dd.getMonth() + 1).padStart(2, "0");
        var yyyy = dd.getFullYear();
        let todayDate = mm + "/" + dd1 + "/" + yyyy;
        return todayDate;
    }
    async todaysDate() {
        let dd: Date = new Date();
        var dd1 = String(dd.getDate()).padStart(2, "0");
        let dd1Number= parseInt(dd1)
        return dd1Number;
    }

    async selectDateInCalendar(locator:any ,post: any , field:any) {
        let loc = await this.textLocator(locator, field, post)
        await this.click(loc)
    }

    async currentDatePlusOne() {
        const currentDate = new Date();
        const nextday = new Date(currentDate);
        nextday.setDate(currentDate.getDate() + 1);
        const dd1 = String(nextday.getDate()).padStart(2, "0");
        const mm = String(nextday.getMonth() + 1).padStart(2, "0");
        const yyyy = nextday.getFullYear();
        const nextDate = mm + "/" + dd1 + "/" + yyyy;
        return nextDate;
    }
    async currentDatePlusOneNumber() {
        const currentDate = new Date();
        const nextday = new Date(currentDate);
        nextday.setDate(currentDate.getDate() + 1);
        const dd1 = String(nextday.getDate()).padStart(2, "0");
       let dd1Number= parseInt(dd1)
        return dd1Number;
    }
    async currentDateMinusFour() {
        const currentDate = new Date();
        const fiveDaysAgo = new Date(currentDate);
        fiveDaysAgo.setDate(currentDate.getDate() - 4);
        const dd = String(fiveDaysAgo.getDate()).padStart(2, "0");
        const mm = String(fiveDaysAgo.getMonth() + 1).padStart(2, "0");
        const yyyy = fiveDaysAgo.getFullYear();
        const fiveDaysAgoDate = mm + "/" + dd + "/" + yyyy;
        return fiveDaysAgoDate;
    }
    async previousMonthDatePlusFour() {
        const today = await new Date(); // Get the current date
        const lastMonth = await new Date(today);
        await lastMonth.setMonth(today.getMonth() - 1);

        const resultDate = await new Date(lastMonth);
        await resultDate.setDate(resultDate.getDate() + 4);

        const formattedDate = await this.formatDate(resultDate);
        await log.info(formattedDate)
        return formattedDate;
    }
    async previousMonthDatePlusFive() {
        const today = await new Date(); // Get the current date
        const lastMonth = await new Date(today);
        await lastMonth.setMonth(today.getMonth() - 1);

        const resultDate = await new Date(lastMonth);
        await resultDate.setDate(resultDate.getDate() + 5);

        const formattedDate = await this.formatDate(resultDate);
        await log.info(formattedDate)
        return formattedDate;
    }

    async formatDate(date: Date) {
        const month = await (date.getMonth() + 1).toString().padStart(2, '0');
        const day = await  date.getDate().toString().padStart(2, '0');
        const year = await date.getFullYear();
        let returnDate =await  month + "/" + day + "/" + year;
        return returnDate;
        // return `${month}/${day}/${year}`;
    }

    async currentDatePlusFifteen() {
        let dd: Date = new Date();
        var dd1 = String(dd.getDate() + 15).padStart(2, "0");
        var mm = String(dd.getMonth() + 1).padStart(2, "0");
        var yyyy = dd.getFullYear();
        let futureDate = mm + "/" + dd1 + "/" + yyyy;
        return futureDate;
    }
    async currentDateMinusOne() {
        let dd: Date = new Date();
        var dd1 = String(dd.getDate() - 1).padStart(2, "0");
        var mm = String(dd.getMonth() + 1).padStart(2, "0");
        var yyyy = dd.getFullYear();
        let previousDate = mm + "/" + dd1 + "/" + yyyy;
        return previousDate;
    }
    
    async currentDateMinusFifteen() {
        let dd: Date = new Date();
        var dd1 = String(dd.getDate() - 15).padStart(2, "0");
        var mm = String(dd.getMonth() + 1).padStart(2, "0");
        var yyyy = dd.getFullYear();
        let previousDate = mm + "/" + dd1 + "/" + yyyy;
        return previousDate;
    }
    
    async currentDateMinusThirty() {
        let dd: Date = new Date();
        var dd1 = String(dd.getDate() - 30).padStart(2, "0");
        var mm = String(dd.getMonth() + 1).padStart(2, "0");
        var yyyy = dd.getFullYear();
        let previousDate = mm + "/" + dd1 + "/" + yyyy;
        return previousDate;
    }

    /**
     * Returns today's date from one year ago in the format MM/DD/YYYY
     * @returns String from one year ago today in the format MM/DD/YYYY
     */
    currentDateLastYear(): string {
      const date: Date = new Date();
      const day: string = String(date.getDate()).padStart(2, "0");
      const month: string = String(date.getMonth() + 1).padStart(2, "0");
      const year: number = date.getFullYear() - 1;
      return month + "/" + day + "/" + year;
    }

    async getCurrentTime() {
        const now = await new Date();
        const formattedTime = await now.toLocaleString('en-US', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false,
            timeZone: 'America/New_York'
        });
        return formattedTime
    }

    async getCurrentTimeHHMM() {
        const now = await new Date();
        const formattedTime = await now.toLocaleString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: false,
            timeZone: 'America/North_Dakota/Center'
        });
        return formattedTime
    }

    async getCurrentDateMMDDYYYY() {
        const now = await new Date().toLocaleDateString('en-US', {timeZone: 'America/Chicago'});
        const formattedTime = await now.toLocaleString()
        const [month, day, year] = formattedTime.split('/');
        const formattedDate = `${month}-${day}-${year}`
        return formattedDate
    }

    async dropdownSelect(locator: any, passvalue) {
        const fruits = await global.page.$(locator);
        await fruits?.selectOption({ value: passvalue });
    }

    async dropdownNoSelect(ddlocator: any, ulLocator, passvalue, tag) {
        try {
            await global.page.click(ddlocator);
            await global.page
                .locator(ulLocator)
                .locator(tag, {
                    hasText: passvalue,
                })
                .click();
            await log.info("Dropdown value is selected: " + passvalue)
        } catch (error) {
            await log.error("Failed");
        }
    }
    async getInputValue(locators: any) {
        var content = await global.page.inputValue(locators);
        await log.info("Input value is " + content);
        return content;
    }

    async launch(url: any) {
        await global.page.goto(url);
        await log.info("Url is " + url);
    }

    async hover(locator) {
        // let dd = await global.page.locator(locator);
        // return dd.hover;
        await global.page.hover(locator);
    }

    async newPage(url: any) {
        const page1 = await global.context.newPage();
        await page1.goto(url);
        await page1.waitForLoadState();
        return page1;
    }

    async deleteFile(path) {
        await fs.unlinkSync(path);
        if (await fs.existsSync(path)) {
            "file still exists:" + path;
        } else {
            await log.info("file is deleted:" + path);
        }
    }

    async copyFile(pathA, pathB) {
        // destination will be created or overwritten by default. 'C:\folderA\myfile.txt', 'C:\folderB\myfile.txt'
        fs.copyFile(pathA, pathB, (err) => {
            if (err) throw err;
            console.log("File was copied to destination");
        });
    }

    async renameFile(pathA, pathB) {
        fs.rename(pathA, pathB, (err) => {
            if (err) throw err;
            console.log("File was copied to destination");
        });
    }

    async ascendingSort(list) {
        const sortedAsc = list.sort((objA: any, objB: any) => objA - objB);
        return sortedAsc;
    }

    async descendingSort(list) {
        const sortedAsc = list.sort((objA: any, objB: any) => objB - objA);
        return sortedAsc;
    }

    /**Additional methods */

    // async click(locator:any){
    //     await global.page.locator(locator).click()
    //     log.info("Clicked on element "+ locator)
    // }

    async wait(delay: number) {
        await global.page.waitForTimeout(delay);
        log.info(`waited for :${delay} ms`);
    }

    async waitForPageLoad(load='load', waitingTime = { timeout: 150000 }) {
        await global.page.waitForLoadState(load,waitingTime);
    }

    // async getText(locator){
    //     const content = await global.page.textContent(locator)
    //     await log.info("Text is "+ content)
    //     return content
    // }

    async selectDropdown(locator, dropdownOption, valueTobeSelected) {
        await this.click(locator);
        await global.page
            .locator(dropdownOption)
            .filter({ hasText: valueTobeSelected })
            .click();
        await log.info("Selected dropdown option as :" + valueTobeSelected);
        await this.wait(5000);
    }

    async selectFromthelist(dropdownOption, valueTobeSelected) {
        await global.page
            .locator(dropdownOption)
            .filter({ hasText: valueTobeSelected })
            .click();
        await log.info("Selected dropdown option as :" + valueTobeSelected);
        await this.wait(5000);
    }

    async selectDropdownwithStrictMatch(locator, dropdownOption, valueTobeSelected) {
        let count = 0;
        await this.click(locator);
        let list = await global.page.$$(dropdownOption);
        for (let item of list) {
            const itemtext = await item.textContent();
            await log.info("Actual Value : " + itemtext.trim());
            await log.info("expected Value: " + valueTobeSelected);
            if (itemtext.trim() == valueTobeSelected) {
                count++;
                await item.click();
                await log.info("Clicked on desired option ", valueTobeSelected);
                break;
            }
            if (count == 0) {
                await log.info(
                    "Desired option is not available in the list: " + valueTobeSelected
                );
            }
        }
    }

    /**
     * @deprecated Use `selectFirstElementOfDropdownList` instead
     */
    async selectFirstElementOfDropdownlist(locator, firstElement) {
        await this.click(locator);
        await this.wait(2000)
        await this.click(firstElement)
    }

    async selectFirstElementOfDropdownlist_Ops(locator, firstElement) {
        await this.click(locator);
        await this.wait(2000)
        await this.click(firstElement)
    }

    async selectFirstElementOfDropdownlist_HR(locator, firstElement) {
        await this.click(locator);
        await this.wait(2000)
        await this.click(firstElement)
    }

    /**
     * Clicks on the first element in a list of dropdown options. It is expected that the dropdown is already
     * opened and visible.
     * @param dropdownOptions locator for the list of dropdown options
     */
    async selectFirstElementOfDropdownList(dropdownOptions: string) {
      const options: string[] = await this.getAllElementLocators(dropdownOptions)
      await this.click(options[0])
    }

    async selectMatchingItemfromList(listItems, valueTobeSelected) {
        let count = 0;
        let list = await global.page.$$(listItems);
        for (let item of list) {
            const itemtext = await item.textContent();
            if (itemtext.trim() == valueTobeSelected) {
                count++;
                await item.click();
                log.info("Clicked on desired option ", valueTobeSelected);
                break;
            }
            if (count == 0) {
                log.info(
                    "Desired option is not available in the list: " + valueTobeSelected
                );
            }
        }
    }

    async verifyButtonState(element, state) {
        let buttonState = await global.page.locator(element).isEnabled();
        if (state == "Enabled") {
            expect(buttonState).toBe(true);
            await log.info("Button state is Enabled");
        } else {
            expect(buttonState).toBe(false);
            await log.info("Button state is Disabled");
        }
    }

    async verifyPaginationButtonEnabledState(state) {
        await this.verifyButtonState("//span[text()=' Previous ']", state);
    }

    async verifyCheckBoxState(element, state) {
        let buttonState = await global.page.locator(element);
        if (state == "Enabled") {
            await expect(buttonState).toBeChecked();
            await log.info("Checkbox is Enabled");
        } else {
            await expect(buttonState).not.toBeChecked();
            await log.info("Checkbox is Disabled");
        }
    }

    async verifyVisibility(element, state) {
        let buttonState = await global.page.locator(element).isVisible();
        if (state === "Visible") {
            expect(buttonState).toBe(true);
            await log.info(element + " Element is Visible");
        } else {
            expect(buttonState).toBe(false);
            await log.info(element + "Element is not Visible");
        }
        return buttonState;
    }

    async verifyElementText(locator, expectedText) {
        log.info(locator);
        const msg = await this.getText(locator);
        expect(msg).toBe(expectedText);
        log.info(
            "Expected text " + expectedText + " is matching with actual text " + msg
        );
    }

    async verifyElementTrimmedText(locator, expectedText) {
        log.info(locator);
        const msg = await this.getText(locator);
        const trimMsg = await msg.trim();
        expect(trimMsg).toBe(expectedText);
        log.info(
            "Expected text " +
            expectedText +
            " is matching with actual text " +
            trimMsg
        );
    }
    async verifyElementTrimmedTextForBoth(locator, expectedText) {
        log.info(locator);
        const msg = await this.getText(locator);
        const trimMsg = msg.trim();
        const trimExpectedText = expectedText.trim();
        expect(trimMsg).toBe(trimExpectedText);
        log.info(
            "Expected text " +
            trimExpectedText +
            " is matching with actual text " +
            trimMsg
        );
    }

    async verifyElementValueIgnoreCommas(locator, expectedText) {
        log.info(locator);
        const msg = await this.getText(locator);
        const trimMsg = await msg.trim();
        const IgnoreCommas = await trimMsg.replace(",", "");
        expect(IgnoreCommas).toBe(expectedText);
        log.info(
            "Expected text " +
            expectedText +
            " is matching with actual text " +
            IgnoreCommas
        );
    }

    async verifyInputText(locator, expectedText) {
        console.log(locator);
        const msg = await this.getInputValue(locator);
        expect(msg).toBe(expectedText);
        await log.info(
            "Expected text " + expectedText + " is matching with actual text " + msg
        );
    }

    async verifyElementContainsText(locator, expectedText) {
        console.log(locator);
        const msg = await this.getText(locator);
        expect(msg).toContain(expectedText);
        log.info("Actual text " + msg + " contains expected text " + expectedText);
    }

    async verifyActualContainsExpectedText(locator, expectedText) {
        console.log(locator);
        const msg = await this.getText(locator);
        expect(expectedText).toContain(msg);
        log.info("Expected text " + msg + " contains actual text " + expectedText);
    }

    async verifyActualContainsExpectedTrimmedText(locator, expectedText) {
        console.log(locator);
        const msg = (await this.getText(locator)).trim();
        expect(expectedText).toContain(msg);
        log.info("Expected text " + msg + " contains actual text " + expectedText);
    }


    async verifyElementNotContainsText(locator, expectedText) {
        console.log(locator);
        const msg = await this.getText(locator);
        expect(msg).not.toContain(expectedText);
        log.info(
            "Actual text " + msg + " does not contain expected text " + expectedText
        );
    }

    async verifyAttribute(locator, atrribute, expectedValue) {
        const atrributeValue = await this.getAttribute(locator, atrribute);
        expect(atrributeValue).toBe(expectedValue);
        log.info(
            "Expected text " +
            expectedValue +
            " is matching with actual text " +
            atrributeValue
        );
    }

    async createUniqueName() {
        let genName = "test_automation" + chance.name();
        return genName;
    }

    async createUniqueID() {
        let genNumber = await this.randomNum(6);
        console.log(genNumber);
        return genNumber;
    }

    async waitforElement(locator, state?: string) {
        if (state) {
          await global.page.waitForSelector(locator, { state: state, timeout: 5000 });
        } else {
          await global.page.waitForSelector(locator, { timeout: 5000 });
        }
    }

    async verifyElementInList(locator, expectedItem: string) {
        let count = 0;
        let list = await global.page.$$(locator);
        for (let item of list) {
            const itemtext = await item.textContent();
            await log.info("Actual Value : " + itemtext.trim());
            await log.info("expected Value: " + expectedItem);
            if (itemtext.trim() == expectedItem) {
                count++;
                expect(true).toBe(true);
                log.info("Value is matching with " + expectedItem);
                break;
            }
        }
        if (count == 0) {
            log.info("Actual Value not matched with Expected Value: " + expectedItem);
            expect(false).toBe(true);
        }
    }

    async verifyElementInListContains(locator, expectedItem: string) {
        let count = 0
        let list = await global.page.$$(locator);
        for (let item of list) {
            const itemtext = await item.textContent();
            log.info("Actual Value : ", itemtext.trim());
            log.info("expected Value: ", expectedItem);
            //expect(itemtext).toContain(expectedItem);
            if (itemtext.trim() == expectedItem) {
                count++
                expect(true).toBe(true);
                log.info("Value is matching with ", expectedItem);
                break
            }
        }
        if (count == 0) {
            log.info("Actual Value not matched with Expected Value: " + expectedItem)
            expect(false).toBe(true);
        }
    }

    async verifyElementInListContainsExpectedTextMasterRecords(locator, expectedItem: string) {
        let count = 0
        let list = await global.page.$$(locator);
        for (let item of list) {
            const itemtext = await item.textContent();
            log.info("Actual Value : "+ itemtext.trim());
            log.info("expected Value: "+ expectedItem);
            expect(itemtext).toContain(expectedItem);
            log.info("Actual Text contains expected value "+ expectedItem);
            break
        }
    }

    async verifyNoItemMatching(locator, expectedItem: string) {
        let count = 0;
        let list = await global.page.$$(locator);
        for (let item of list) {
            const itemtext = await item.textContent();
            log.info("Actual Value : ", itemtext.trim());
            log.info("expected Value: ", expectedItem);
            if (itemtext.trim() == expectedItem) {
                count++;
                expect(false).toBe(true);
                log.info("Value is matching with ", expectedItem);
                break;
            }
        }
        if (count == 0) {
            log.info("No record found for : " + expectedItem);
            expect(true).toBe(true);
        }
    }

    //Reference Method
    async sorElementInList(locator) {
        let count = 0;
        let arr: string[] = [];
        let list = await global.page.$$(locator);
        for (let item of list) {
            const itemtext = await item.textContent();
            const itemValue = await itemtext.trim();
            console.log(await itemValue);
            arr.push(await itemValue);
        }
        console.log(arr);
        console.log(arr.sort());
    }

    async sortElementInDescOrder(locator) {
        let arr: string[] = [];
        let list = await global.page.$$(locator);
        for (let item of list) {
            const itemtext = await item.textContent();
            const itemValue = await itemtext.trim();
            arr.push(await itemValue);
            // arr.push(await itemValue.toLowerCase());
        }
        const itemlist = arr.sort();
        log.info("ascending order List" + itemlist);
        const itemDesc = itemlist.reverse();
        log.info("descending order List" + itemDesc);
        return itemDesc;
    }

    /**
     * Sorts a list of text elements in ascending or descending order, only using alphanumeric
     * character. Removes all whitespace as well.
     * @param locator The locator for the list of element(s)
     * @param ascending If true, sort in ascending order, else descending order
     * @returns A sorted list of elements with only alphanumeric characters
     */
    async sortElementsOnlyAlphaNumeric(locator: string, ascending: boolean = true) {
      let arr: string[] = [];
      let list = await global.page.$$(locator);
      for (let item of list) {
        let itemText = await item.textContent();
        itemText = itemText.toLowerCase();
        const cleanedText = itemText.replace(/[^\w\s]/gi, '').replace(/\s+/g, '');
        arr.push(cleanedText);
      }

      const sortedArray = arr.sort()
      if (ascending) {
        log.info('List in Ascending order: ' + sortedArray)
        return sortedArray;
      } else {
        const reversedArray = sortedArray.reverse();
        log.info('List in Descending order: ' + reversedArray)
        return reversedArray;
      }
    }

    async customAlphanumericSort(arr: string[]){
        return arr.sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
      }

    async sortElementInDescOrderCaseSensitiveOff(locator) {
        let arr: string[] = [];
        let list = await global.page.$$(locator);
        for (let item of list) {
            const itemtext = await (await item.textContent()).toLowerCase();
            const itemValue = await itemtext.trim();
            arr.push(await itemValue);
        }
        const itemlist = arr.sort();
        log.info("ascending order List" + itemlist);
        const itemDesc = itemlist.reverse();
        log.info("descending order List" + itemDesc);
        return itemDesc;
    }

    async sortDatesInDescOrder(locator) {
        let arr: Date[] = [];
        let list = await global.page.$$(locator);
        for (let item of list) {
            const itemtext = await item.textContent();
            const itemValue = await itemtext.trim();
            let dateValue = await itemValue.split("System API", 2);
            let dates: Date = (await new Date(dateValue)) as Date;
            arr.push(dates);
        }
        const itemlist = arr.sort((a, b) => a.getTime() - b.getTime());
        let formattedDates = itemlist.map((date) =>
            date.toLocaleDateString("en-US", {
                year: "numeric",
                month: "2-digit",
                day: "2-digit",
            })
        );
        log.info("ascending order List" + formattedDates);
        const itemDesc = formattedDates.reverse();
        log.info("descending order List" + itemDesc);
        return itemDesc;
    }

    async sortDatesInAscOrder(locator) {
        let arr: Date[] = [];
        let list = await global.page.$$(locator);
        for (let item of list) {
            const itemtext = await item.textContent();
            const itemValue = await itemtext.trim();
            let dateValue = await itemValue.split("System API", 2);
            let dates: Date = (await new Date(dateValue)) as Date;
            arr.push(dates);
        }
        const itemlist = arr.sort((a, b) => a.getTime() - b.getTime());
        let formattedDates = itemlist.map((date) =>
            date.toLocaleDateString("en-US", {
                year: "numeric",
                month: "2-digit",
                day: "2-digit",
            })
        );
        log.info("ascending order List" + formattedDates);
        return formattedDates;
    }

    async iterateList(list, expectedValue) {
        for (let val of list) {
            const ptypetext = await val.textContent();
            if (ptypetext === expectedValue) {
                expect(true).toBe(true);
                console.log(ptypetext + "=" + expectedValue);
                break;
            }
        }
    }

    async sortElementInAscOrder(locator) {
        let arr: string[] = [];
        let list = await global.page.$$(locator);
        for (let item of list) {
            const itemtext = await item.textContent();
            const itemValue = await itemtext.trim();
            arr.push(await itemValue);
            // arr.push(await itemValue.toLowerCase());
        }
        const itemDesc = arr.sort();
        await log.info("ascending order List" + itemDesc);
        return itemDesc;
    }

    async sortElementInAscOrderCaseSensitiveOff(locator) {
        let arr: string[] = [];
        let list = await global.page.$$(locator);
        for (let item of list) {
            const itemtext = await item.textContent();
            const itemValue = await (await itemtext.trim()).toLowerCase();
            arr.push(await itemValue);
        }
        // const itemDesc = arr.sort();
        const itemDesc = await this.customAlphanumericSort(arr)
        await log.info("ascending order List" + itemDesc);
        return itemDesc;
    }

    async verifyMultipleItemsInList(locator: any, expectedItem: any) {
        let list = await global.page.$$(locator);
        let itemCount = 0;
        for (let item of list) {
            const itemtext = await item.textContent();
            await log.info("Actual Value : " + itemtext.trim());
            await log.info("expected Value: " + expectedItem[itemCount]);
            if (await itemtext.trim() == expectedItem[itemCount]) {
                itemCount++;
                expect(true).toBe(true);    
                await log.info("Actual Value is matching with " + itemtext.trim());
            } else {
                await log.info(
                    "Actual Value not matched with Expected Value: " +
                    expectedItem[itemCount]
                );
                expect(false).toBe(true);
            }
        }
    }

    /**
     * Verifies the text(s) of a list of elements, only using alphanumeric characters and no whitespace.
     * This method also only checks against all lowercase characters.
     * @param locator Locator for the list of elements
     * @param expected The expected value of the list of elements
     */
    async verifyItemsInListOnlyAlphaNumeric(locator: any, expected: any) {
      let elements = await global.page.$$(locator);
      let count = 0;
      for (let element of elements) {
        let actualText = await element.textContent();
        actualText = actualText.replace(/[^\w\s]/gi, '').replace(/\s+/g, '').toLowerCase();
        let expectedText = expected[count].replace(/[^\w\s]/gi, '').replace(/\s+/g, '');
        await log.info('Actual Value: ' + actualText);
        await log.info('Expected Value: ' + expectedText);
        if (await actualText == expectedText) {
          count++;
          expect(true).toBe(true);
          await log.info('Actual Value is matching with: ' + actualText);
        } else {
          await log.info(
            'Actual Value does not match Expected Value: ' +
            expected[count]
          );
          expect(false).toBe(true);
        }
      }
    }

    async verifyMultipleItemsInListCaseSensitiveOff(locator: any, expectedItem: any) {
        let list = await global.page.$$(locator);
        let itemCount = 0;
        for (let item of list) {
            const itemtext = await (await item.textContent()).toLowerCase();
            await log.info("Actual Value : " + itemtext.trim());
            await log.info("expected Value: " + expectedItem[itemCount]);
            if (await itemtext.trim() == await expectedItem[itemCount]) {
                itemCount++;
                expect(true).toBe(true);
                await log.info("Actual Value is matching with " + itemtext.trim());
            } else {
                await log.info(
                    "Actual Value not matched with Expected Value: " +
                    expectedItem[itemCount]
                );
                expect(false).toBe(true);
            }
        }
    }

    async verifyMultipleItemsInListServiceWithoutPrimaryTag(locator: any, expectedItem: any) {
        let list = await global.page.$$(locator);
        let itemCount = 0;
        for (let item of list) {
            const itemtext1 = (await item.textContent()).trim();
            const itemtext2 = itemtext1.split("Primary",2)
            console.log("Service :",itemtext2)
            const itemtext = itemtext2[0]
            console.log("Service :",itemtext)
            await log.info("Actual Value : " + itemtext.trim());
            await log.info("expected Value: " + expectedItem[itemCount]);
            if (await itemtext.trim() == expectedItem[itemCount]) {
                itemCount++;
                expect(true).toBe(true);
                await log.info("Actual Value is matching with " + itemtext.trim());
            } else {
                await log.info(
                    "Actual Value not matched with Expected Value: " +
                    expectedItem[itemCount]
                );
                expect(false).toBe(true);
            }
        }
    }

    async verifyMultipleItemsInListServiceWithoutPrimaryTagContains(locator: any, expectedItem: any) {
        let arr: string[] = [];
        let list = await global.page.$$(locator);
        let itemCount = 0;
        for (let item of list) {
            const itemtext1 = (await item.textContent()).trim();
            const itemtext2 = itemtext1.split("Primary",2)
            console.log("Service :",itemtext2)
            const itemtext = itemtext2[0]
            arr.push(await itemtext.trim());
        }
        expect(arr).toEqual(expect.arrayContaining(expectedItem))
        await log.info("All the list items are present")
    }

    async verifyMultipleItemsInListwithContains(locator: any, expectedItem: any) {
        let arr: string[] = [];
        let list = await global.page.$$(locator);
        let itemCount = 0;
        for (let item of list) {
            const itemtext = await item.textContent();
            arr.push(await itemtext.trim());

            // if (await itemtext.trim() == expectedItem[itemCount]) {
            //     itemCount++;
            //     expect(true).toBe(true);
            //     await log.info("Actual Value is matching with " + itemtext.trim());
            // } else {
            //     await log.info(
            //         "Actual Value not matched with Expected Value: " +
            //         expectedItem[itemCount]
            //     );
            //     expect(false).toBe(true);
            // }
        }
        expect(arr).toEqual(expect.arrayContaining(expectedItem))
        await log.info("All the list items are present")
    }

    async verifyMultipleItemsInMasterListRecords(locator: any, expectedItem: any) {
        let list = await global.page.$$(locator);
        let itemCount = 0;
        for (let item of list) {
            const itemtext = await item.textContent();
            log.info("Actual Value : ", itemtext.trim());
            log.info("expected Value: ", expectedItem.trim());
            expect(itemtext).toContain(expectedItem);
        }
    }

    async verifyMultipleItemsValueInMasterListRecords(locator: any, expectedItem: any, condition: any, splitString: any) {
        let list = await global.page.$$(locator);

        for (let item of list) {
            const itemtext = await item.textContent();
            const itemVal = await itemtext.split(splitString, 2)
            const itemValue = await parseFloat(itemVal[1])
            log.info("Actual Value : ", itemValue);
            log.info("expected Value: ", await expectedItem.trim());
            const expectedValue= await parseInt(expectedItem)
            if (condition == "Greaterthan") {
                expect(itemValue).toBeGreaterThan(expectedValue);
            }
            if (condition == "Lessthan") {
                expect(itemValue).toBeLessThan(expectedValue);
            }
        }

    }

    async verifyMultipleSyetemAPIDatesInList(locator: any, expectedItem: any) {
        let list = await global.page.$$(locator);
        let itemCount = 0;
        for (let item of list) {
            const itemtext = await item.textContent();
            if (await expectedItem[itemCount] == "Invalid Date") {
                expectedItem[itemCount] = "n/a"

            }
            await log.info("Actual Value : ", await itemtext.trim());
            await log.info("expected Value: ", await expectedItem[itemCount]);
            //   expect(itemtext.toLowerCase()).toContain(expectedItem[itemCount])
            if (await itemtext.trim().toLowerCase().includes(await expectedItem[itemCount])) {
                await itemCount++;
                expect(true).toBe(true);
                await log.info("Actual Value is matching with ", await itemtext.trim());
            } else {
                await log.info(
                    "Actual Value not matched with Expected Value: " +
                    await expectedItem[itemCount]
                );
                expect(false).toBe(true);
            }
        }
    }

    async verifyNumberofItems(locator: any, expectedNumberofItem: any) {
        const expectedValue = parseInt(expectedNumberofItem);
        let list = await global.page.$$(locator);
        log.info(list.length);
        expect(list.length).toBe(expectedValue);
        log.info(
            "Expected number of items:" +
            expectedValue +
            " are matching with actual number of items " +
            list.length
        );
    }

    async verifyNumberofItemsGreaterthan(
        locator: any,
        expectedNumberofItem: any
    ) {
        const expectedValue = parseInt(expectedNumberofItem);
        let list = await global.page.$$(locator);
        log.info(list.length);
        if (list.length >= expectedValue) {
            expect(true).toBe(true);
            log.info(
                "Actual Items " +
                list.length +
                " are greater than or equal to " +
                expectedValue
            );
        } else {
            expect(true).toBe(false);
            log.info(
                "Actual Items " +
                list.length +
                " are not greater than or equal to " +
                expectedValue
            );
        }
    }

    async getAlltheListItems(locator: any) {
        let arr: string[] = [];
        let list = await global.page.$$(locator);
        for (let item of list) {
            const itemtext = await item.textContent();
            const itemValue = await itemtext.trim();
            log.info(await itemValue);
            // arr.push(await itemValue.toLowerCase());
            arr.push(await itemValue);
        }
        log.info(arr);
        return arr;
    }

    async verifyListContainsItem(locator: any, expectedItem: any) {
        let list = await global.page.$$(locator);
        for (let item of list) {
            const itemtext = await item.textContent();
            expect(itemtext.toLowerCase()).toContain(expectedItem);
            await log.info(itemtext + " contains " + expectedItem);
        }
    }

    async verifyListContainsDropdownItem(locator: any, expectedItem: any) {
        let list = await global.page.$$(locator);
        let count = 0;
        for (let item of list) {
            if ((await item.textContent()) == expectedItem) {
                const itemtext = await item.textContent();
                expect(itemtext).toContain(expectedItem);
                count = count + 1;
                log.info("Actual text " + itemtext + " contains " + expectedItem);
                break;
            }
        }
        if (count == 0) {
            log.info("actual item does not contain " + expectedItem);
            expect(true).toBe(false);
        }
    }

    async VerifyTabState(locator: any, att: any, state: string) {
        const tabState = await this.getAttribute(locator, att);
        if (state == "Selected") {
            expect(tabState).toBe("true");
            await log.info("tab is Selected");
        } else {
            expect(tabState).toBe("false");
            await log.info("tab is not Selected");
        }
    }

    async VerifyFieldState(locator: any, att: any, state: string) {
        const tabState = await this.getAttribute(locator, att);
        if (state == "Disabled") {
            expect(tabState).toContain("disabled");
            await log.info("tab is Disabeld");
        } else {
            expect(tabState).toBe("false");
            await log.info("tab is not Disabled");
        }
    }

    async verifyExpectedActualText(expected, actual) {
        expect(expected).toBe(actual);
    }

    async verifyActualValueEqualsToExpectedValue(expected, actual) {
        log.info("Actual Value: " + actual + " expected Value: " + expected)
        expect(expected).toBe(actual);
    }

    async verifyExpectedNotEqualsActualText(expected, actual) {
        expect(expected).not.toBe(actual);
    }
    async mouseRightClick(locator) {
        const button = await global.page.locator(locator)
        await button.click({ button: 'right' });
    }

    async verifyExpectedContainsActualText(expected, actual) {
        expect(actual).toContain(expected);
        await log.info("Actual text " + "contains " + "expected text " + expected)
    }

    async verifyExpectedContainsActualTextSoftAssertion(expected, actual) {
        let fail = 0
        if (await actual.includes(expected)) {
            await log.info("Actual text " + "contains " + "expected text " + expected)
            return fail
        }
        else {
            await log.info("Value verification Failed :")
            await log.info("Actual text does not " + "contain " + "expected text " + expected)
            fail = 1
            return fail
        }
    }

    async verifyActualContainsExpectedOneOfTwoValues(variableString, variableString1, pdfData) {
        let fail = 0
        if (await pdfData.includes(variableString) || await pdfData.includes(variableString1)) {
            await log.info("Federal Tax " + variableString + "contains expected Text")
            return fail
        }

        else {
            await log.info("Federal Tax " + variableString + " or " + variableString1 + "does not match")
            fail = 1
            return fail
        }
    }


    async verifytextContainsWithRegex(regex, actual) {
        await expect(actual).toMatch(regex);
        log.info("Actual text " + "contains " + "expected text " + regex)
    }



    async getCheckBoxState(locator) {
        const isChecked = await global.page.$eval(
            locator,
            (e: Element) => (e as HTMLInputElement).checked
        );
        return isChecked;
    }

    async verifyCheckBox(locator, state) {
        const isChecked = await this.getCheckBoxState(locator);
        if (state == "Checked") {
            expect(isChecked).toBe(true);
            await log.info("Checkbox is Checked");
        } else {
            expect(isChecked).not.toBe(true);
            await log.info("Checkbox is not Checked");
        }
    }

    async selectValueEquals(loc: any, value: any) {
        var locator = loc + "//*[text()= 'value']";
        await global.page.click(locator.replace("value", value));
        await log.info("Selected value is ", value);
    }

    async waitForSelectorHidden(locators: any, time: number) {
        await log.info("Waiting for selector to be hidden ", locators);
        await global.page.waitForSelector(locators, {
            state: "hidden",
            timeout: time,
        });
        await log.info("Waited for selector to be hidden ", locators);
    }

    async downloadFileandSave(locator) {
        const downloadPath = "./src/resources/results";
        // await this.click(locator);
        const [download] = await Promise.all([
            global.page.waitForEvent("download"),
            global.page.locator(locator).click(),
        ]);

        // Get the download object
        // const download = await global.page.waitForEvent("download",{timeout:60000});
        // Get the path to the downloaded file
        let downloadedFilename = download.suggestedFilename();
        console.log(downloadedFilename);
        await download.saveAs(`${downloadPath}/${downloadedFilename}`);
        return downloadedFilename;
    }

    async downloadBiggerFileandSave(locator) {
        const downloadPath = "./src/resources/results";
        const [download] = await Promise.all([
            global.page.waitForEvent("download", { timeout: 300 * 1000 }),
            global.page.locator(locator).click(),
        ]);
        let downloadedFilename = download.suggestedFilename();
        console.log(downloadedFilename);
        await download.saveAs(`${downloadPath}/${downloadedFilename}`);
        return downloadedFilename;
    }

    async downloadFileandSavePayRollCombination(locator, scenarioName) {
        const downloadPath = "./src/resources/results";
        // await this.click(locator);
        const [download] = await Promise.all([
            global.page.waitForEvent("download"),
            global.page.locator(locator).click(),
        ]);

        // Get the download object
        // const download = await global.page.waitForEvent("download",{timeout:60000});
        // Get the path to the downloaded file
        let downloadedFilename = scenarioName + "_" + download.suggestedFilename();
        console.log(downloadedFilename);
        await download.saveAs(`${downloadPath}/${downloadedFilename}`);
        return downloadedFilename;
    }
    async downloadFileandSaveBillingRusReread(locator) {
        const downloadPath = "./src/resources/results";
        const [download] = await Promise.all([
            global.page.waitForEvent("download"),
            global.page.locator(locator).click(),
        ]);
        let downloadedFilename =download.suggestedFilename();
        console.log(downloadedFilename);
        await download.saveAs(`${downloadPath}/${downloadedFilename}`);
        return downloadedFilename;
    }

    async getPDFData(filename) {
        const downloadPath = "./src/resources/results";
        const path = `${downloadPath}/${filename}`;

        const pdf = require('pdf-parse');
        const databuffer = fs.readFileSync(path);

        try {
            const data = await pdf(databuffer);
            console.log("PDF data: " + data.text);
            return data.text;
        } catch (error) {
            console.error(error);
            return null;
        }
    }

    async toggleRadioButton(locator: any, enabled: boolean) {
        if (!enabled && (await this.getAttribute(locator, "checked"))) {
            await this.click(locator);
        } else if (enabled && !(await this.getAttribute(locator, "checked"))) {
            await this.click(locator);
        }
    }

    async makeString(str) {
        str = await str.trim();
        return str.replace(/\"/g, "");
    }
    async textLocator(beforeloc: any, value: any, afterLoc) {
        var locator = beforeloc + "//*[text()= 'value']" + afterLoc;
        return locator.replace("value", value);
    }

    async verifyDropDownOptionState(locator, dropdownOption, valueTobeSelected, state) {
        let count = 0;
        await this.click(locator);
        let list = await global.page.$$(dropdownOption);
        for (let item of list) {
            const itemtext = await item.textContent();
            log.info("Actual Value : ", itemtext.trim());
            log.info("expected Value: ", valueTobeSelected);
            if (itemtext.trim() == valueTobeSelected) {
                count++;

                const classAttributeValue = await item.getAttribute('class');

                const isDisabled = classAttributeValue.includes('disabled');
                // let dropdownOptionState = await item.isEnabled()
                if (state == "Enabled") {
                    expect(isDisabled).toBe(false)
                    log.info("Desired option is " + state);
                }

                if (state == "Disabled") {
                    expect(isDisabled).toBe(true)
                    log.info("Desired option is " + state);
                }

                break;
            }
            if (count == 0) {
                log.info(
                    "Desired option is not available in the list: " + valueTobeSelected
                );
            }
        }
    }

    async getListElementsText(locator) {
        let List = await this.getElements(locator)
        await log.info("count: " + List.length)
        let value: any = []
        for (let i = 0; i < List.length; i++) {
            value[i] = await (await List[i].innerText()).trim();
        }
        return value
    }

    async getListElementsTextInputValue(locator) {
        let List = await this.getElements(locator)
        await log.info("count: " + List.length)
        let value: any = []
        for (let i = 0; i < List.length; i++) {
            value[i] = await (await List[i].inputValue()).trim();
        }
        return value
    }
    async dragAndDrop(source, destination) {
        await global.page.locator(source).dragTo(global.page.locator(destination))
        await log.info("Drag and Drop is success")
    }
    async dragAndDropManually(source, destination) {
        await global.page.locator(source).hover();
        await global.page.mouse.down();
        await global.page.locator(destination).hover();
        await global.page.mouse.up();
    }

    async getNumberofDecimalDigits(num) {
        const decimalDigits = (num.toString().split('.')[1] || '').length
        return decimalDigits

    }

    async preciseRoundoff2DecimalPoint(valueToBeRoundedOff) {
        let roundedOffValue = valueToBeRoundedOff;
        const decimalDigits = await this.getNumberofDecimalDigits(valueToBeRoundedOff);
        const roundoffPlaces = decimalDigits - 1

        for (let i = 0; i < roundoffPlaces; i++) {
            roundedOffValue = Math.round(roundedOffValue * (10 ** (decimalDigits - i))) / (10 ** (decimalDigits - i));
            await log.info("Rounded off Value =" + roundedOffValue);
        }
        return roundedOffValue;
    }
    async selectCheckBox(locator: any, enabled: boolean) {
        ///if(!enabled && await this.getAttribute(locator, "checked")){
        if (!enabled && (await this.isChecked(locator))) {
            await this.click(locator);
        } else if (enabled && !(await this.isChecked(locator))) {
            //}else if(enabled && !(await this.getAttribute(locator, "checked"))){
            await this.click(locator);
        }
    }

    async waitForLoader() {
        try {
            await global.page.waitForSelector("//div[@class='loader']", {
                timeout: 10000,
            });
            await global.page.waitForSelector("//div[@class='loader']", {
                state: "hidden",
                timeout: 60000,
            });
            await log.info("Waiting for loader to timeout");
        } catch (error) {
            await log.info("No loader appeared");
        }
    }


    // async preciseRoundoff2DecimalPoint(valueToBeRoundedOff){
    //     let roundedOffValue
    //     const decimalDigits = await this.getNumberofDecimalDigits(valueToBeRoundedOff)
    //     for (let i = 0; i < decimalDigits; i++) {
    //         roundedOffValue = Math.round(valueToBeRoundedOff * (10 ** (decimalDigits - i))) / (10 ** (decimalDigits - i));
    //         await log.info("Rounded off Value ="+ roundedOffValue);
    //       }
    //     return roundedOffValue
    // }
    async pressKey(keyName) {
        await global.page.keyboard.press(keyName);
    }

    async addStringInArray(arr, stringTobeAdded) {
        for (let i = 0; i < arr.length; i++) {
            arr[i] = arr[i] + stringTobeAdded
        }
        return arr
    }

    async verifyNumericValues(expected, actual) {
        expected = parseFloat(expected);
        actual = parseFloat(actual);
        if (expected == actual) {
            log.info("Actual is matching with the expected value");
        } else {
            log.error("Actual is not matching with the expected value. \n Actual value: " + actual + "\n Expected Value: " + expected);
        }

    }

    async getInnerHTML(locators: any) {
        var content = await global.page.innerHTML(locators);
        await log.info("Text is " + content);
        return content;
    }

    async parseText(str) {
        //let entities = new AllHtmlEntities();
        let parser = new DomParser();
        let doc = parser.parseFromString(str, "text/html");
        return doc.documentElement.textContent;
    }

    async getCurrentUTCTimeString(): Promise<string> {
        const currentDate = new Date();

        const currentYear = currentDate.getUTCFullYear();
        const currentMonth = String(currentDate.getUTCMonth() + 1).padStart(2, '0'); // Month starts from 0 (January is 0)
        const currentDay = String(currentDate.getUTCDate()).padStart(2, '0');
        const currentHour = String(currentDate.getUTCHours()).padStart(2, '0');
        const currentMinute = String(currentDate.getUTCMinutes()).padStart(2, '0');
        const currentSecond = String(currentDate.getUTCSeconds()).padStart(2, '0');

        const dateTimeString = `${currentYear}${currentMonth}${currentDay}${currentHour}${currentMinute}${currentSecond}`;
        return dateTimeString;
    }

    async getCurrentUTCTimeStringExcludingSec(): Promise<string> {
        const currentDate = new Date();

        const currentYear = currentDate.getUTCFullYear();
        const currentMonth = String(currentDate.getUTCMonth() + 1).padStart(2, '0'); // Month starts from 0 (January is 0)
        const currentDay = String(currentDate.getUTCDate()).padStart(2, '0');
        const currentHour = String(currentDate.getUTCHours()).padStart(2, '0');
        const currentMinute = String(currentDate.getUTCMinutes()).padStart(2, '0');


        const dateTimeString = `${currentYear}${currentMonth}${currentDay}${currentHour}${currentMinute}`;
        return dateTimeString;
    }

    async getTotalNumberofItems(loc) {
        console.log(await loc)
        const numberofItems = await global.page.$$(loc);
        const count = await numberofItems.length
        await log.info("count :" + count);
        return count
    }

    async getCurrentTimeWithOffsets(): Promise<{
        currentTime: string;
        timePlusOneSecond: string;
        timeMinusOneSecond: string;
    }> {
        const currentTime = new Date();
        const timePlusOneSecond = new Date(currentTime.getTime() + 1000); // Adding 1000 milliseconds (1 second)
        const timeMinusOneSecond = new Date(currentTime.getTime() - 1000); // Subtracting 1000 milliseconds (1 second)

        const formatOptions: Intl.DateTimeFormatOptions = {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true,
        };

        const formatter = new Intl.DateTimeFormat('en-US', formatOptions);

        return {
            currentTime: formatter.format(currentTime),
            timePlusOneSecond: formatter.format(timePlusOneSecond),
            timeMinusOneSecond: formatter.format(timeMinusOneSecond),
        };
      }

      async selectDropdownInFrame(frameSelector, locator, dropdownOption, valueToBeSelected) {
        // Switch to the iframe context
        const iframe = await global.page.frame(frameSelector);
    
        // Click the element that opens the dropdown
        await iframe.click(locator);
    
        // Filter and click the dropdown option
        await iframe
            .locator(dropdownOption)
            .filter({ hasText: valueToBeSelected })
            .click();
    
        // Log the selected option
        await log.info("Selected dropdown option as: " + valueToBeSelected);
    
        // Wait if needed
        await this.wait(5000);
    
        // Switch back to the main page context if necessary
        await global.page.bringToFront();
    }
    async selectNextItemfromList(listItems, selectedValue) {

        
        let count = 0;
        let list = await global.page.$$(listItems);
        for (let i=0; i<list.length;i++) {
          const itemtext = await list[i].textContent();
          if (itemtext.trim() == selectedValue) {
            count++;
            await list[i+1].click();
            log.info("Clicked on next option of", selectedValue);
            break;
          }
          if (count == 0) {
            log.info(
              "Desired option is not available in the list: " + selectedValue
            );
          }
        }
      }

      async goBack(){
        await global.page.goBack()
        await log.info("Going back to the previous page..")
      }

      async changeResolution(w: any,h: any){
        await global.page.setViewportSize({width:w, height:h});
        await log.info("Resolution Change to:"+w+"*"+h);

      }

      async currentDateMinusTen(){
        const currentDate = await global.page.evaluate(() => {
            const now = new Date();
            return new Date(now.getFullYear(), now.getMonth(), now.getDate());
        });
        const previousDate = new Date(currentDate);
        previousDate.setDate(currentDate.getDate() - 10);
        const dd1 = String(previousDate.getDate()).padStart(2, '0');
        const mm = String(previousDate.getMonth() + 1).padStart(2, '0');
        const yyyy = previousDate.getFullYear();    
        const formattedDate = `${mm}/${dd1}/${yyyy}`
        return formattedDate
    }

    async currentDateMinusTwentyFive() {
        const currentDate = await global.page.evaluate(() => {
            const now = new Date();
            return new Date(now.getFullYear(), now.getMonth(), now.getDate());
        });
        const previousDate = new Date(currentDate);
        previousDate.setDate(currentDate.getDate() - 25);
        const dd1 = String(previousDate.getDate()).padStart(2, '0');
        const mm = String(previousDate.getMonth() + 1).padStart(2, '0');
        const yyyy = previousDate.getFullYear();    
        const formattedDate = `${mm}/${dd1}/${yyyy}`
        return formattedDate
    }

  /**
   * Clicks a specific point on the element, using two coordinates.
   * @param locator Locator for the element
   * @param x The x-coordinate of the point to click, relative to the top-left corner of the element.
   * @param y The y-coordinate of the point to click, relative to the top-left corner of the element. 
   */
  async clickPosition(locator: string, x: number, y: number) {
    await global.page.locator(locator).click({
      position: { x: x, y: y },
    });
    await log.info(`Clicked on ${locator} at position (${x}, ${y})`);
  }

  /**
   * Gets all elements with the same locator
   * @param locator Locator string for the element(s)
   * @returns An array of all the element locators
   */
  async getAllElementLocators(locator: string): Promise<string[]> {
    const numberOfElements: number = await global.page.locator(locator).count()
    if (numberOfElements > 0) {
      const elementLocators: string[] = []
      for (let i = 1; i <= numberOfElements; i++) {
        const elementLocator = `(${locator})[${i}]`
        elementLocators.push(elementLocator)
      }
      return elementLocators
    } else {
      console.log(`No elements found with locator: ${locator}`)
      return []
    }
  }
  async enterFiannce(locators: any, value: any) {
    await global.page.fill(locators, value);
    await log.info("Entered value" + value + "in element" + locators);
}

async typeFinace(locators: any, value: any) {
    await global.page.type(locators, value);
    await log.info("Entered value" + value + "in element" + locators);
}
async isCheckedFianace(locators: any) {
    let isCheck = await global.page.isChecked(locators)
    if (isCheck) {
        await log.info(locators + "is selected");
    } else {
        await log.info(locators + "is not selected");
    }
    return isCheck;
}

async isDisabledFinance(locators: any) {
    var isDisabled = false;

    await global.page.isDisabled(locators);
    await log.info(locators + "is disabled");
    isDisabled = true;

    return isDisabled;
}

async verifyTextBouth(locators: any, text1: string, text2?: string) {
    var text_msg = "";

    await global.page.waitForSelector(locators, { timeout: 40000 });
    text_msg = await global.page.innerText(locators);
    
    if (text_msg === text1 || (text2 && text_msg === text2)) {
        await log.info(
            'Actual value is matching with expected value \n' +
            " Actual value   : " +
            text_msg +
            "\n Expected values : " +
            text1 +
            (text2 ? " or " + text2 : "")
        );
        return true;
    } else {
        throw new Error(
            "Actual value does not match expected values \n" +
            " Actual value   : " +
            text_msg +
            "\n Expected values : " +
            text1 +
            (text2 ? " or " + text2 : "")
        );
    }
}

async getBaseUrl(): Promise<string> {
    let url: string = await this.getUrl()
    const parts = url.split('/')
    if (parts.length >= 4) {
        return parts.slice(0, 3).join('/')
    } else {
        return url
    }
}

 /**
     * Returns the base url of the application, with no trailing `/`
     * Example: https://www.google.com/maps returns https://www.google.com
     * @returns base url of the application
     */

async getBaseUrl_Ops(): Promise<string> {
    let url: string = await this.getUrl()
    const parts = url.split('/')
    if (parts.length >= 4) {
        return parts.slice(0, 3).join('/')
    } else {
        return url
    }
}

async selectDateInCalendarFinance(locator: any, post: any, field: any) {
    let loc = await this.textLocator(locator, field, post)
    await this.click(loc)
}
async currentDateMinusThirtyFinance() {
    let dd: Date = new Date();
    var dd1 = String(dd.getDate() - 1).padStart(2, "0");
    var mm = String(dd.getMonth()).padStart(2, "0");
    var yyyy = dd.getFullYear();
    let previousDate = mm + "/" + dd1 + "/" + yyyy;
    return previousDate;
}

async verifyElementTrimmedTextFinance(locator, expectedText) {
    log.info(locator);
    const msg = await this.getText(locator);
    const trimMsg = await msg.trim();
    log.info(`Expected: ${expectedText}\nActual:   ${trimMsg}`);
    expect(trimMsg).toBe(expectedText);
}
// Multiplies the first data by -1. When making a report verification on money transfers in Finance Hub, it appears as negative because the money is out of the account. This method can be used for verification.
async verifyNegativeInputText(locator, expectedText) {
    console.log(locator);
let msg = await this.getInputValue(locator);
// Remove commas and convert msg to a number
let numericMsg = parseFloat(msg.replace(/,/g, ''));
// Multiply by -1
numericMsg *= -1;
// Format expectedText to remove commas for comparison
const numericExpectedText = parseFloat(expectedText.replace(/,/g, ''));
expect(numericMsg).toBe(numericExpectedText);
await log.info(
    "Expected text " + expectedText + " is matching with actual text " + msg
);
}
async verifyInputText2(locator, expectedText) {
console.log(locator);
let msg = await this.getInputValue(locator);
// Remove commas and convert msg to a number
let numericMsg = parseFloat(msg.replace(/,/g, '').replace('-', ''));
// Format expectedText to remove commas and negative sign for comparison
const numericExpectedText = parseFloat(expectedText.replace(/,/g, '').replace('-', ''));
expect(numericMsg).toBe(numericExpectedText);
await log.info(
    "Expected text " + expectedText + " is matching with actual text " + msg
);
}
async customAlphanumericSortFinance(arr: string[]) {
    return arr.sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
}
async verifyExpectedActualTextFinance(expected, actual) {
    expect(expected).toBe(actual);
    log.info("Actual Value: " + actual + " expected Value: " + expected)
}

	
async verifyExpectedContainsActualTextSoftAssertionwithTolerance(variable_name, variable_value, actual) {
    let comp_result = 0
    let i: number = 0;
    for (i; i <= 2; i++) {
        let value: number = 0
        let variableString = ""
        if (i == 0) {
            value = parseFloat(variable_value)
            variableString = `${variable_name} $${value}`
        }
        else if (i == 1) {
            const value1 = (parseFloat(variable_value) + 0.01).toFixed(2)
            variableString = `${variable_name} $${value1}`
        }
        else if (i == 2) {
            const value1 = (parseFloat(variable_value) - 0.01).toFixed(2)
            variableString = `${variable_name} $${value1}`
        }
        comp_result = await this.verifyExpectedContainsActualTextSoftAssertion(variableString, actual)
        if (comp_result == 0) {
            if (i != 0) {
                await log.info("below value passed with tolerance +-0.01 tolerance")
            }
            break
        }
    }
    return comp_result
}
async verifyExpectedContainsActualTextSoftAssertionwithToleranceEqualString(variable_name, variable_value, actual) {
    let comp_result = 0
    let i: number = 0;
    for (i; i <= 8; i++) {
        let value: number = 0
        let variableString = ""
        if (i == 0) {
            value = parseFloat(variable_value)
            variableString = `${variable_name}=$${value}`
        }
        else if (i == 1) {
            const value1 = (parseFloat(variable_value) + 0.01).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }
        else if (i == 2) {
            const value1 = (parseFloat(variable_value) - 0.01).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }
        else if (i == 3) {
            const value1 = (parseFloat(variable_value) + 0.02).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }
        else if (i == 4) {
            const value1 = (parseFloat(variable_value) - 0.02).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }
        else if (i == 5) {
            const value1 = (parseFloat(variable_value) + 0.03).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }
        else if (i == 6) {
            const value1 = (parseFloat(variable_value) - 0.03).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }
        else if (i == 7) {
            const value1 = (parseFloat(variable_value) + 0.04).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }
        else if (i == 8) {
            const value1 = (parseFloat(variable_value) - 0.04).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }
        comp_result = await this.verifyExpectedContainsActualTextSoftAssertion(variableString, actual)
        if (comp_result == 0) {
            if (i != 0) {
                await log.info("above value passed with tolerance +-0.01 tolerance")
            }
            break
        }
    }
    return comp_result
}

async downloadFileandSavePayRollCombinationFinance(locator, scenarioName) {
    const downloadPath = "./src/resources/results";
    const downloadPath1 = "./src/resources/data/tempFiles"
    // await this.click(locator);
    const [download] = await Promise.all([
        global.page.waitForEvent("download", { timeout: 120000 }),
        global.page.locator(locator).click(),
    ]);

    // Get the download object
    // const download = await global.page.waitForEvent("download",{timeout:60000});
    // Get the path to the downloaded file
    let downloadedFilename = scenarioName + "_" + download.suggestedFilename();
    console.log(downloadedFilename);
    await download.saveAs(`${downloadPath}/${downloadedFilename}`);
    await download.saveAs(`${downloadPath1}/${scenarioName}.pdf`)
    return downloadedFilename;
}

async sortAmountValuesInAscOrder(locator) {
    let amountValues: number[] = [];
    let elementList = await global.page.$$(locator);
    for (let element of elementList) {
        const textContent = await element.textContent();
        const amountValue = parseFloat(textContent.replace('$', '').replace(',', ''));
        amountValues.push(amountValue);
  }
    amountValues.sort((a, b) => a - b);
    await log.info('Amount values in ascending order: ' + amountValues);
    return amountValues;
}
async sortAmountValuesInDescOrder(locator) {
    let amountValues: number[] = [];
    let elementList = await global.page.$$(locator);
    for (let element of elementList) {
        const textContent = await element.textContent();
        const amountValue = parseFloat(textContent.replace('$', '').replaceAll(',', ''));
        amountValues.push(amountValue);
    }
    amountValues.sort((a, b) => b - a);
    await log.info('Amount values in descending order: ' + amountValues);
    return amountValues;
}
async verifyMultipleAmountValuesInList(locator: string, expectedAmounts: number[]) {
    let elements = await global.page.$$(locator);
    let itemCount = 0;
    for (let element of elements) {
        const textContent = await element.textContent();
        const actualAmount = parseFloat(textContent.replace('$', '').replaceAll(',', ''));
        const expectedAmount = expectedAmounts[itemCount];
        await log.info('Actual Amount: ' + actualAmount);
        await log.info('Expected Amount: ' + expectedAmount);
        if (actualAmount === expectedAmount) {
            itemCount++;
            await log.info('Actual Amount matches Expected Amount: ' + actualAmount);
            expect(true).toBe(true);
        } else {
            await log.info('Actual Amount does not match Expected Amount: ' + expectedAmount);
            expect(false).toBe(true);
        }
    }
}
async threeMonthBeforeDate() {
    const today = await new Date()
    const lastMonth = await new Date(today);
    await lastMonth.setMonth(today.getMonth() - 3)
    const resultDate = await new Date(lastMonth)
    await resultDate.setDate(resultDate.getDate())
    const formattedDate = await this.formatDate(resultDate)
    await log.info(formattedDate)
    return formattedDate
}
async getCurrentDateMMDDYYYYSplitBySlash() {
    const now = await new Date();
    const formattedTime = await now.toLocaleString('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        timeZone: 'America/North_Dakota/Center'
    })
    const [month, day, year] = formattedTime.split('/');
    const formattedDate = `${month}/${day}/${year}`
    return formattedDate
}
async getUTCCurrentDateMMDDYYYY() {
    const now = await new Date();
    const formattedTime = await now.toLocaleString('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        timeZone: 'UTC' // Set the time zone to UTC
    });
    const [month, day, year] = formattedTime.split('/');
    const formattedDate = `${month}/${day}/${year}`;
    return formattedDate;
}

async clickPositionFiannce(locator: string, x: number, y: number) {
    await global.page.locator(locator).click({
        position: { x: x, y: y },
    });
    await log.info(`Clicked on ${locator} at position (${x}, ${y})`);
}
async changeResolutionFianace(w: any, h: any) {
    await global.page.setViewportSize({ width: w, height: h });
    await log.info("Resolution Change to:" + w + "*" + h);
}

  /**
   * Get the text(s) of all elements in a list
   * @param elementList a list of element Locators
   * @returns A list of the texts of the elements
   */
  async getTextsInElementList(elementList: string[]): Promise<string[]> {
    const textList: string[] = []
    for (let element of elementList) {
      const text = await global.page.locator(element).innerText()
      textList.push(text)
    }
    return textList
  }
  async todaysDateInDDMMYYYFormat(){
    const today = new Date();
    const month = String(today.getMonth() + 1).padStart(2, '0'); // Adding 1 because getMonth() returns 0-indexed month
    const day = String(today.getDate()).padStart(2, '0');
    const year = today.getFullYear();
    const formattedDate = `${month}/${day}/${year}`;
    return formattedDate
}
async currentDateMinusFifteenOpshub() {
    let dd: Date = new Date();
    var dd1 = String(dd.getDate() - 15).padStart(2, "0");
    var mm = String(dd.getMonth()).padStart(2, "0");
    var yyyy = dd.getFullYear();
    let previousDate = mm + "/" + dd1 + "/" + yyyy;
    return previousDate;
}
async currentDateMinusThirtyOpshub() {
    let dd: Date = new Date();
    var dd1 = String(dd.getDate() - 1).padStart(2, "0");
    var mm = String(dd.getMonth()).padStart(2, "0");
    var yyyy = dd.getFullYear();
    let previousDate = mm + "/" + dd1 + "/" + yyyy;
    return previousDate;
}
async getUTCCurrentDateMMDDYYYYOpshub() {
    const now = await new Date();
    const formattedTime = await now.toLocaleString('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        timeZone: 'UTC' // Set the time zone to UTC
    });
    const [month, day, year] = formattedTime.split('/');
    const formattedDate = `${month}/${day}/${year}`;
    return formattedDate;
}
async generateRandomString(length: number): Promise<string>{
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const randomBytesArray = randomBytes(Math.ceil(length * 3 / 4));
    const str = randomBytesArray.toString('base64').slice(0, length);
    return str.replace(/[+/]/g, '');
  }
  async getAllTextContents(locators: any) {
    const textContents = await global.page.allTextContents(locators)
    await log.info("Text is " + textContents)
    return textContents
  }
  async scrollToBottm() {
    await log.info("Srolling to the bottom")
    await global.page.evaluate(() => {
      window.scrollTo(0, document.body.scrollHeight)
    })
  }
  async getBaseUrlHrhubMain(): Promise<string> {
    let url: string = await this.getUrl()
    const parts = url.split('/')
    if (parts.length >= 4) {
      return parts.slice(0, 3).join('/')
    } else {
      return url
    }
  }
  async DatePlusOne(Date1: string | number | Date) {
    const currentDate = new Date(Date1);
   // currentDate = Date1;
    const nextday = new Date(currentDate);
    
    nextday.setDate( currentDate.getDate() + 1);
    const dd1 = String(nextday.getDate()).padStart(2, "0");
    const mm = String(nextday.getMonth() + 1).padStart(2, "0");
    const yyyy = nextday.getFullYear();
    let nextDate = mm + "/" + dd1 + "/" + yyyy;
    return nextDate;
}

async getworkingDate() {
    const currentDate = new Date();
    const day =await currentDate.toUTCString();
   if(day.includes("Sun"))
   {
    const currentDate = await this.currentDatePlusOne();
   }
   if(day.includes("Sat"))
   {
    const currentDate = await this.currentDateMinusFour();
   }
    const dd = await String(currentDate.getDate()).padStart(2, "0");
    const mm = String(currentDate.getMonth() + 1).padStart(2, "0");
    const yyyy = currentDate.getFullYear();
    const fiveDaysAgoDate = mm + "/" + dd + "/" + yyyy;
    return currentDate;
}

async getworkingday(currentDate){
    const dd:string = await currentDate.toLocaleString('en-US', {day: '2-digit', })
    return dd;
}

async getworkingdatemonth(currentDate){
    const mm:string = await currentDate.toLocaleString('en-US', { month: 'short' })
    return mm;
}

async verifyExpectedActualTextHrhubMain(expected, actual) {
    expect(expected).toBe(actual);
    log.info("Actual Value: " + actual + " expected Value: " + expected)
}

async verifyExpectedContainsActualTextSoftAssertionwithToleranceHrhubMain(variable_name, variable_value, actual) {
    let comp_result=0
    let i:number=0;
    for(i;i<=2;i++){
        let value:number = 0
        let variableString = ""
        if(i==0){
            value = parseFloat(variable_value)
            variableString = `${variable_name} $${value}`
        }
        else if(i==1){
            const value1 = (parseFloat(variable_value) + 0.01).toFixed(2)
            variableString = `${variable_name} $${value1}`
        }

        else if(i==2){
            const value1 = (parseFloat(variable_value) - 0.01).toFixed(2)
            variableString = `${variable_name} $${value1}`
        }
        
        comp_result = await this.verifyExpectedContainsActualTextSoftAssertion(variableString, actual)
        if(comp_result==0){
            if(i!=0){
                await log.info("below value passed with tolerance +-0.01 tolerance")
            }
            break
        }
    }
    return comp_result
}

async verifyExpectedContainsActualTextSoftAssertionwithToleranceEqualStringHrhubMain(variable_name, variable_value, actual) {
    let comp_result=0
    let i:number=0;
    for(i;i<=8;i++){
        let value:number = 0
        let variableString = ""
        if(i==0){
            value = parseFloat(variable_value)
            variableString = `${variable_name}=$${value}`
        }
        else if(i==1){
            const value1 = (parseFloat(variable_value) + 0.01).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }

        else if(i==2){
            const value1 = (parseFloat(variable_value) - 0.01).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }

        else if(i==3){
            const value1 = (parseFloat(variable_value) + 0.02).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }

        else if(i==4){
            const value1 = (parseFloat(variable_value) - 0.02).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }

        else if(i==5){
            const value1 = (parseFloat(variable_value) + 0.03).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }

        else if(i==6){
            const value1 = (parseFloat(variable_value) - 0.03).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }

        else if(i==7){
            const value1 = (parseFloat(variable_value) + 0.04).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }

        else if(i==8){
            const value1 = (parseFloat(variable_value) - 0.04).toFixed(2)
            variableString = `${variable_name}=$${value1}`
        }


        comp_result = await this.verifyExpectedContainsActualTextSoftAssertion(variableString, actual)
        if(comp_result==0){
            if(i!=0){
                await log.info("above value passed with tolerance +-0.01 tolerance")
            }
            break
        }
    }
    return comp_result
}
async downloadFileandSavePayRollCombinationHrhubMain(locator, scenarioName) {
    const downloadPath = "./src/resources/results";
    const downloadPath1 = "./src/resources/data/tempFiles"
    // await this.click(locator);
    const [download] = await Promise.all([
        global.page.waitForEvent("download",{timeout:120000}),
        global.page.locator(locator).click(),
    ]);

    // Get the download object
    // const download = await global.page.waitForEvent("download",{timeout:60000});
    // Get the path to the downloaded file
    let downloadedFilename = scenarioName + "_" + download.suggestedFilename();
    console.log(downloadedFilename);
    await download.saveAs(`${downloadPath}/${downloadedFilename}`);
    await download.saveAs(`${downloadPath1}/${scenarioName}.pdf`)
    return downloadedFilename;
}

async sortAmountValuesInDescOrderHrhubMain(locator) {
    let amountValues: number[] = [];
    let elementList = await global.page.$$(locator);
    for (let element of elementList) {
        const textContent = await element.textContent();
        const amountValue = parseFloat(textContent.replace('$', '').replace(',', ''));
        amountValues.push(amountValue);
    }
    amountValues.sort((a, b) => b - a);
    await log.info('Amount values in descending order: ' + amountValues);
    return amountValues;
}

async currentDateMinusTenHrhubMain(){
    const currentDate = await global.page.evaluate(() => {
        const now = new Date();
        return new Date(now.getFullYear(), now.getMonth(), now.getDate());
    });
    const previousDate = new Date(currentDate);
    previousDate.setDate(currentDate.getDate() - 10);
    const dd1 = String(previousDate.getDate()).padStart(2, '0');
    const mm = String(previousDate.getMonth() + 1).padStart(2, '0');
    const yyyy = previousDate.getFullYear();    
    const formattedDate = `${mm}/${dd1}/${yyyy}`
    return formattedDate
}
async clickPositionHrhubMain(locator: string, x: number, y: number) {
    await global.page.locator(locator).click({
      position: { x: x, y: y },
    });
    await log.info(`Clicked on ${locator} at position (${x}, ${y})`);
  }

  async changeResolutionHrhubMain(w: any,h: any){
    await global.page.setViewportSize({width:w, height:h});
    await log.info("Resolution Change to:"+w+"*"+h);

  }
  async currentDateMinusTwentyFiveHrhubMain() {
    const currentDate = await global.page.evaluate(() => {
        const now = new Date();
        return new Date(now.getFullYear(), now.getMonth(), now.getDate());
    });
    const previousDate = new Date(currentDate);
    previousDate.setDate(currentDate.getDate() - 25);
    const dd1 = String(previousDate.getDate()).padStart(2, '0');
    const mm = String(previousDate.getMonth() + 1).padStart(2, '0');
    const yyyy = previousDate.getFullYear();    
    const formattedDate = `${mm}/${dd1}/${yyyy}`
    return formattedDate
}

async isValidDate(Date){
    let dateformat = /^(0?[1-9]|1[0-2])[\/](0?[1-9]|[1-2][0-9]|3[01])[\/]\d{4}$/;
    log.info(Date)

// Matching the date through regular expression      
    if (Date.match(dateformat)) {
    let operator = Date.split('/');

    // Extract the string into month, date and year      
    let datepart = [];
    if (operator.length > 1) {
        datepart = Date.split('/');
    }
    let month = parseInt(datepart[0]);
    let day = parseInt(datepart[1]);
    let year = parseInt(datepart[2]);

    // Create a list of days of a month      
    let ListofDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (month == 1 || month > 2) {
        if (day > ListofDays[month - 1]) {
            //to check if the date is out of range     
            return false;
        }
    } else if (month == 2) {
        let leapYear = false;
        if ((!(year % 4) && year % 100) || !(year % 400)) leapYear = true;
        if ((leapYear == false) && (day >= 29)) return false;
        else
            if ((leapYear == true) && (day > 29)) {
                console.log('Invalid date format!');
                return false;
            }
    }
  } else {
      console.log("Invalid date format!");
      return false;
  }
  return "Valid date";
}

/**
* Gets all elements with the same locator
* @param locator Locator string for the element(s)
* @returns An array of all the element locators
*/
async getAllElementLocatorsHrhubMain(locator: string): Promise<string[]> {
const numberOfElements: number = await global.page.locator(locator).count()
if (numberOfElements > 0) {
  const elementLocators: string[] = []
  for (let i = 1; i <= numberOfElements; i++) {
    const elementLocator = `(${locator})[${i}]`
    elementLocators.push(elementLocator)
  }
  return elementLocators
} else {
  console.log(`No elements found with locator: ${locator}`)
  return []
}
}
async currenDateMinusTen(){
    const currentDate = await global.page.evaluate(() => {
        const now = new Date();
        return new Date(now.getFullYear(), now.getMonth(), now.getDate());
    });
    const previousDate = new Date(currentDate);
    previousDate.setDate(currentDate.getDate() - 10);
    const dd1 = String(previousDate.getDate()).padStart(2, '0');
    const mm = String(previousDate.getMonth() + 1).padStart(2, '0');
    const yyyy = previousDate.getFullYear();    
    const formattedDate = `${mm}/${dd1}/${yyyy}`
    return formattedDate
}
async changeResolutionPayRollCalculation(w: any,h: any){
    await global.page.setViewportSize({width:w, height:h});
    await log.info("Resolution Change to:"+w+"*"+h);

  }
  async downloadFileandSavePayRollCombinationPayRollCalculation(locator, scenarioName) {
    const downloadPath = "./src/resources/results";
    const downloadPath1 = "./src/resources/data/tempFiles"
    // await this.click(locator);
    const [download] = await Promise.all([
        global.page.waitForEvent("download",{timeout:120000}),
        global.page.locator(locator).click(),
    ]);

    // Get the download object
    // const download = await global.page.waitForEvent("download",{timeout:60000});
    // Get the path to the downloaded file
    let downloadedFilename = scenarioName + "_" + download.suggestedFilename();
    console.log(downloadedFilename);
    await download.saveAs(`${downloadPath}/${downloadedFilename}`);
    await download.saveAs(`${downloadPath1}/${scenarioName}.pdf`)
    return downloadedFilename;
}


async getRandomStringForEmployeeName(length) {
    const randomChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += randomChars.charAt(Math.floor(Math.random() * randomChars.length));
    }
    return result;
}


}


