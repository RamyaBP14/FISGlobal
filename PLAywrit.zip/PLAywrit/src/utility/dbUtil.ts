import { Client, PoolClient } from 'pg';
import { LoggerUtil } from './logger';
import { Pool } from 'pg';
import { config } from 'dotenv';
import { getSecret } from './secureCredentials';

//import * as mysql from 'mysql2/promise';// Retrieve the IAM user's credentials from the AWS Secret Manager
const log = new LoggerUtil();
let pool;

config({ path: '.env' });
export default pool;

export class dbUtil {
  
  async dbConnection(){
    const  dbUsername = await getSecret('DB_Connection','DB.Username');
    const  dbPassword = await getSecret('DB_Connection','DB.Password')
    const  dbHost = await getSecret('DB_Connection','DB.HOST')
    const  dbPort = await getSecret('DB_Connection','DB.PORT')
      pool = new Pool({
        user: dbUsername,
        host: dbHost,
        database: 'city_' + global.cityCode,
        password: dbPassword,
        port: parseInt(dbPort || '5432'),
      });
  } 
  
  client = new Client({
    host: 'gworks-db-qa.cbv3g1rfbxux.us-east-1.rds.amazonaws.com',
    user: 'postgres',
    //user:'tb_mohini',
    database: 'GworksQAdB',
    //password: '$w4eV6#TgL4&4fdYWmWv',
    password: 'm2*TZt1m5MKiipNYjP32',
    port: 5432, // or your preferred port number
  });

  /**
   * Executes a SQL query against the database using a separate client object
   * @param {string} query The SQL query to execute
   * @returns {Promise<any>} A promise that resolves to the query result object
   */
  async runQuery(query) {
   
    try {
      await this.client.connect();
      const res = await this.client.query(query);
      console.log(res);
      console.log(res.rows);
      await this.client.end();
      return res.rows;
    } catch (err) {
      console.error(err);
    }
    // await client.end()
  }
  /**
   * Executes an update SQL query against the database (similar to runQuery)
   * @param {string} query The SQL update query to execute
   * @returns {Promise<any>} A promise that resolves to the query result object
   */
  async runUpdateQuery(query) {
    try {
      await this.client.connect();
      const res = await this.client.query(query);
      console.log(res);
      console.log(res.rows);
      await this.client.end();
      if (res.rowCount > 0) {
        log.info('Update query was successful.');
      } else {
        log.info('Update query did not affect any rows in the database.');
      }
      return res.rows;
    } catch (err) {
      console.error(err);
    }
  }
  /**
   * Executes a search query against the database (similar to runQuery)
   * @param {string} query The SQL search query to execute
   * @returns {Promise<string>} A promise that resolves to the account number from the search result
   */
  async searchAccount(query) {
    try {
      await this.client.connect();
      const res = await this.client.query(query);
      console.log(res.rows[0].AccountNumber);
      await this.client.end();
      return res.rows[0].AccountNumber;
    } catch (err) {
      console.error(err);
    }
  }

  /**
   * Connects to the database and executes the query
   * @param query Query to be executed
   * @returns Returns the result of the query
   */
  async dbConnectAndQuery(query: string): Promise<any> {
   // console.log("Username use"+dBUsername);
    await this.dbConnection();
    const client: PoolClient = await pool.connect();
    let res: any;
    //console.log(query);
    try {
      res = await client.query(query);
      //console.log(res.rows);
    } catch (error) {
      console.error(new Error());
    } finally {
      client.release();
    }
    return res;
  }
}
