import fs from 'fs';
import { LoggerUtil } from "./logger";
import { promises as fsPromises } from 'fs'
import path from 'path';

let log = new LoggerUtil()

var today = new Date()
var todayDate = today.getFullYear() + "-" + (today.getMonth()+1) + "-" + (today.getDate())

let jsondataDir = "./src/resources/data/"
let jsondataDirPayroll ="./src/resources/data/PayrollCalculationData/"
let jsondataDirTemp = "./src/resources/data/tempFiles/"
let jsondataDirTempFiles = "./src/resources/data/tempFiles/*"
let jsondataDirJsonConfig ="./src/reporter/"
let txtFileDir = "./src/resources/results/"+todayDate+"/gWorks_Automation/"
export class JsonOperations{
/*Json file reader and Fetching Json Data*/  
async readData(fileName) {
    try {
        // read the JSON file
        const fileData = await fs.promises.readFile(`${jsondataDir}${fileName}`, 'utf-8');
    
        // parse the JSON data
        let jsonData = JSON.parse(fileData);
        return jsonData
    
      } catch (err) {
        console.error(err);
      }
} 

/*Read Text File*/
async readTextFile(filepath: string): Promise<string> {
    const data = await fs.promises.readFile(filepath, 'utf8');
    return data;
  }

/*Generate new data Name field */
async getNewLabelName(){
         const newlabel = this.getNewLabelName()
         return newlabel
        }    
/*Json file creation and writing Json Data*/
//It will create new file with the given data. 
//If the file is already exist it will remove the previous one and replace with the new one.
async createJsonData(fileName,jsonData:any){
  try {
    // write the updated data to the file
    await fs.promises.writeFile(`${jsondataDirTemp}${fileName}`, JSON.stringify(jsonData,null,2),{ flag: 'w' });
  } catch (err) {
    console.error(err);
  }
}


    async appendJsonData(fileName,jsonData:any){
        // Read existing data from file
        let existingData = {};
        if (fs.existsSync(`${jsondataDirTemp}${fileName}`)) {
        try {
            const data = await fs.promises.readFile(`${jsondataDirTemp}${fileName}`, 'utf-8');
            existingData = JSON.parse(data) || {};
        } catch (err) {
            console.error(`Failed to read file: ${err}`);
        }
        }

        // Append new data to existing data
        const combinedData = {
        ...existingData,
        ...jsonData
        };

        // Write combined data to file
        try {
        await fs.promises.writeFile(`${jsondataDirTemp}${fileName}`, JSON.stringify(combinedData, null, 2),{ flag: 'w' });
        console.log('Data written to file successfully.');
        } catch (err) {
        console.error(`Failed to write file: ${err}`);
        }
            }

/*For Payroll Calculation Data storage*/
async appendPayrollJsonData(fileName,jsonData:any){
    // Read existing data from file
    let existingData = {};
    if (fs.existsSync(`${jsondataDirPayroll}${fileName}`)) {
    try {
        const data = await fs.promises.readFile(`${jsondataDirPayroll}${fileName}`, 'utf-8');
        existingData = JSON.parse(data) || {};
    } catch (err) {
        console.error(`Failed to read file: ${err}`);
    }
    }

    // Append new data to existing data
    const combinedData = {
    ...existingData,
    ...jsonData
    };

    // Write combined data to file
    try {
    await fs.promises.writeFile(`${jsondataDirPayroll}${fileName}`, JSON.stringify(combinedData, null, 2),{ flag: 'w' });
    console.log('Data written to file successfully.');
    } catch (err) {
    console.error(`Failed to write file: ${err}`);
    }
        }

    /*For Payroll Calculation Data storage*/
async appendConfigJsonData(fileName,jsonData:any){
    // Read existing data from file
    let existingData = {};
    if (fs.existsSync(`${jsondataDirJsonConfig}${fileName}`)) {
    try {
        const data = await fs.promises.readFile(`${jsondataDirJsonConfig}${fileName}`, 'utf-8');
        existingData = JSON.parse(data) || {};
    } catch (err) {
        console.error(`Failed to read file: ${err}`);
    }
    }

    // Append new data to existing data
    const combinedData = {
    ...existingData,
    ...jsonData
    };

    // Write combined data to file
    try {
    await fs.promises.writeFile(`${jsondataDirJsonConfig}${fileName}`, JSON.stringify(combinedData, null, 2),{ flag: 'w' });
    console.log('Data written to file successfully.');
    } catch (err) {
    console.error(`Failed to write file: ${err}`);
    }
        }


/* Update Json file with some data*/
async updateData(fileName,data: any) {
  try {
    // read the JSON file
    const fileData = await fs.promises.readFile(`${jsondataDir}${fileName}`, 'utf-8');

    // parse the JSON data
    let jsonData = JSON.parse(fileData);

    // update the data
    jsonData = { ...jsonData, ...data };

    // write the updated data to the file
    await fs.promises.writeFile(`${jsondataDir}${fileName}`, JSON.stringify(jsonData,null,2));
  } catch (err) {
    console.error(err);
  }
} 

async deleteFile(fileName) {
  try {
      await fs.promises.unlink(`${jsondataDir}${fileName}`)
      if (await fs.existsSync(`${jsondataDir}${fileName}`)) {
          await log.warn("file still exists:",`${jsondataDir}${fileName}`);
      } else {
          await log.info("file is deleted:", `${jsondataDir}${fileName}`);
      }
  } catch (error) {
      await log.info("Exception Occured"+error);
  }
}

async deleteTempFiles(){
  const files = await fs.promises.readdir(`${jsondataDirTemp}`);
  await log.info("Deleting Temp Files...")
  for (const file of files) {
    const filePath = `${jsondataDirTemp}/${file}`;
    await fs.promises.unlink(filePath);
    await log.info(`Successfully deleted ${filePath}`);
  }
}

async  writeDataToJsonFile(filename: string, data: any): Promise<void> {
    const filePath = `${jsondataDir}${filename}` //path.join(__dirname, filename);
  
    let existingData: any = null;
    try {
      existingData = await this.readData(filename);
    } catch (err) {
      // File doesn't exist, do nothing
    }
  
    if (existingData) {
      // Append to existing data
      const newData = [...existingData, data];
      await fs.promises.writeFile(filePath, JSON.stringify(newData, null, 2));
    } else {
      // Create new file
      await fs.promises.writeFile(filePath, JSON.stringify([data], null, 2));
    }
  }





// 
async writeDataToTextFile(fileName: string, data: any): Promise<void> {
    let dataString = data.toString();
    const filename = `${jsondataDirTemp}${fileName}.txt` //path.join(__dirname, filename);
 
 
 
   let existingData: any = null;
 
   try {
 
    existingData = await this.readTextFile(filename);
 
   } catch (err) {
     console.log(err)
    // File doesn't exist, do nothingc
     
   }
 
 
 
   if (existingData) {
 
    // Append to existing data
 
 //    const newData = [...existingData, data];
    
    const newData = existingData + '\n' + dataString;
    await fs.promises.writeFile(filename, newData);
    console.log("File appended")
 
   } else {
 
    // Create new file
 
    await fs.promises.writeFile(filename, dataString, { flag: 'w'});
    console.log("new file created")
 
   }
 
  }

  async writeDataToTextFileSpecificLocation(path,fileName: string, data: any): Promise<void> {
    let dataString = data.toString();
    const filename = `${path}${fileName}.txt` //path.join(__dirname, filename);
 
   let existingData: any = null; 
   try { 
    existingData = await this.readTextFile(filename); 
   } catch (err) {
     console.log(err)
    // File doesn't exist, do nothingc     
   }
 
 
 
   if (existingData) {
 
    // Append to existing data
 
 //    const newData = [...existingData, data];
    
    const newData = existingData + '\n' + dataString;
    await fs.promises.writeFile(filename, newData);
    console.log("File appended")
 
   } else {
 
    // Create new file
 
    await fs.promises.writeFile(filename, dataString, { flag: 'w'});
    console.log("new file created")
 
   }
 
  }



async replaceWordInFile(filePath: string, oldWord: string, newWord: string) {
  try {
    // Read the file contents
    const data = await fs.promises.readFile(filePath, 'utf8');

    // Replace the word in the content
    const updatedContent = data.replace(new RegExp(oldWord, 'g'), newWord);

    // Write the modified content back to the file
    await fs.promises.writeFile(filePath, updatedContent, 'utf8');

    console.log('File updated successfully!');
    return updatedContent
  } catch (err) {
    console.error('Error:', err);
  }
}

// Usage: replaceWordInFile('path/to/file.txt', 'oldWord', 'newWord');

async deleteScenarioComboFiles() {
  try {
    const files = await fs.promises.readdir(jsondataDirPayroll);
  
    for (const file of files) {
      if (file.startsWith('SalaryComboScenario')) {
        const filePath = `${jsondataDirPayroll}/${file}`;
        await fs.promises.unlink(filePath);
        console.log(`Successfully deleted ${filePath}`);
      }
    }
  } catch (err) {
    console.error(`Error deleting scenario combo files: ${err}`);
  }
}
async clearJsonFile(filename: string): Promise<void> {
    try {
      // Check if the file exists
      //await fsPromises.access(`${jsondataDirPayroll}${filename}`, fsPromises.constants.F_OK);
  
      // If it exists, read the JSON file
      const rawData = await fsPromises.readFile(`${jsondataDirPayroll}${filename}`, 'utf-8');
      let data = JSON.parse(rawData); 
      // Clear the data
      data = {}; // For an empty object
      // OR
      // data = []; // For an empty array
  
      // Write the modified data back to the JSON file
      await fsPromises.writeFile(`${jsondataDirPayroll}${filename}`, JSON.stringify(data, null, 2), 'utf-8');
  
      console.log('JSON file cleared successfully.');
    } catch (err:any) {
      if (err.code === 'ENOENT') {
        console.log('File does not exist.');
      } else {
        console.error('Error:', err);
      }
    }
  }
}
export function getLocator(page: string, element: string): string {
  const filePath = path.resolve(__dirname, `../locators/${page}.json`);
  const fileData = fs.readFileSync(filePath, 'utf-8');
  const locators = JSON.parse(fileData);
  // Split the element string by dots to handle nested structures
  const keys = element.split('.');
  let current = locators;
  try {
    for (const key of keys) {
      if (current[key] !== undefined) {
        current = current[key];
      } else {
        throw new Error(`Locator for ${element} not found in ${page}.json`);
      }
    }
  } catch (message) {
    console.log(message)
  }
  return current;
}

