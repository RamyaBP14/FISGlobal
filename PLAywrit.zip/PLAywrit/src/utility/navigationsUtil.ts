import { LoggerUtil } from './logger';
import { PageBase } from './PageBase';
import { JsonOperations } from './jsonOperations';
import { CommonUtils } from './commonUtils';
// import {citycode, executionOptions} from '../../cucumber.js'

const log = new LoggerUtil();
const jsonUtil = new JsonOperations();
let newUrl: string;
const commonUtil = new CommonUtils();

export class navigationsUtil extends PageBase {
  private sidemenu1 = "//p[normalize-space()='Employees']";
  private sidemenu2 = "//span[normalize-space()='Payroll Runs']";
  private employeeMenuHR = "//p[normalize-space()='Employees']";
  private ubAccounts = "//p[normalize-space()='UB Accounts']";
  private AssetRepository = "//p[normalize-space()='Asset Repository']";

  async navigatetoGivenSideMenu1(menuOption, hub) {
    const sideMenuLoc = await this.sidemenu1.replace('Employees', menuOption);
    const hubloc = await this.sidemenu1.replace('Employees', hub);
    await this.navigatetoRepectiveHub(hub);
    await this.click(sideMenuLoc);
    await commonUtil.handleLoadingSpinner();
  }

  async navigatetoGivenSideMenu2(menuOption1, menuOption2, hub) {
    const sideMenuLoc1 = await this.sidemenu1.replace('Employees', menuOption1);
    const sideMenuLoc2 = await this.sidemenu2.replace('Payroll Runs', menuOption2);
    await this.navigatetoRepectiveHub(hub);
    await this.click(sideMenuLoc1);
    await commonUtil.handleLoadingSpinner();
    await this.click(sideMenuLoc2);
    await commonUtil.handleLoadingSpinner();
  }

  async navigatetoRepectiveHub(hub) {
    const hubloc = await this.sidemenu1.replace('Employees', hub);
    if (hub == 'HR') {
      if (!(await this.isVisible(this.employeeMenuHR))) {
        await this.click(hubloc);
      }
    } else if (hub == 'Utility Billing') {
      if (!(await this.isVisible(this.ubAccounts))) {
        await this.click(hubloc);
      }
    } else if (hub == 'Operations') {
      if (!(await this.isVisible(this.AssetRepository))) {
        await this.click(hubloc);
      }
    }
  }
}
