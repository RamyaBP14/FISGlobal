import { getSecret } from './secureCredentials'

let loginAccessKey:string;
let cityCodeTokenKey:string;

export class APIUtil {

  async GET(url: string): Promise<Response>  {
    const apiUrl = await getSecret('API_URL1','API_URL');
    return await fetch(apiUrl + url, {
      method: 'GET',
      headers: {
        Authorization: global.BearerToken,
        'Content-Type': 'application/json',
      },
    });
  }

  /**
   * Executes a POST call
   * @param url the URL of the API
   * @param body the request body for the POST
   * @returns a response object containing the response of the POST
   */
  async POST(url: string, body: string): Promise<Response> {
   const apiUrl = await getSecret('API_URL1','API_URL');
    return await fetch(apiUrl + url, {
      method: 'POST',
      body: body,
      headers: {
        Authorization: global.BearerToken,
        'Content-Type': 'application/json',
      },
    });
  }

  async PUT(url: string, body: string):  Promise<Response> {
    const apiUrl = await getSecret('API_URL1','API_URL');
    return await fetch(apiUrl + url, {
      method: 'PUT',
      body: body,
      headers: {
        Authorization: global.BearerToken,
        'Content-Type': 'application/json',
      },
    });
  }
  // Executes a DELETE request (implementation pending)
  async DELETE() {
    // WIP
  }

async getAccessViaUsernameAndPassword(){
  const url: string = await getSecret('API_URL1','LoginUsername_URL');
  const userName:string = await getSecret('Login.Credentials','Login.Username');
  const password:string = await getSecret('Login.Credentials','Login.Password');
  const jSonBody ={
    "email": userName,
    "password": password,
  }
  const usernamePasswordJson: string = JSON.stringify(jSonBody);
  const usernamePasswordResponse: Response = await this.POSTUsernameAndPassword(url, usernamePasswordJson);
    if (!usernamePasswordResponse.ok) {
      throw new Error('Failed to retrieve the access key');
    }
    if (usernamePasswordResponse.body !== null) {
      const responseJson = await usernamePasswordResponse.json();
      return responseJson.access;
    } else {
      throw new Error('Failled to retrive the access key data from API');
    }
  }

  async getAccessViaCitycode() {
    loginAccessKey =await this.getAccessViaUsernameAndPassword();
    const cityCodeUrl:string = await getSecret('API_URL1','LoginCityCode_URL');
    const jSonBody = {};
    const url:string = cityCodeUrl + global.cityCode;
    const cityCodeJosn:string = JSON.stringify(jSonBody);
    const cityCodeResponse: Response = await this.POSTCityCode(url, cityCodeJosn);
      if (!cityCodeResponse.ok) {
        throw new Error('Failed to retrieve token key');
      }
      if (cityCodeResponse.body !== null) {
        const responseJson = await cityCodeResponse.json();
        return responseJson.token;
      } else {
        throw new Error('Failled to retrive the token access key data from API');
      }
  }

  async getBearerToken() {
    cityCodeTokenKey = await this.getAccessViaCitycode(); 
    const url:string = await getSecret('API_URL1','LoginSupport_URL');
    const jSonBody={
      "token": cityCodeTokenKey,
    }
    const cityLoginSupportJson:string = JSON.stringify(jSonBody);
    const cityLoginSupportResponse: Response = await this.POSTCityCode(url, cityLoginSupportJson);
    if (!cityLoginSupportResponse.ok) {
      throw new Error('Failed to revtrive the bearertoken');
    }
    if (cityLoginSupportResponse.body !== null) {
      const responseJson = await cityLoginSupportResponse.json();
      return responseJson.access;
    } else {
      throw new Error('Failled to retrive the bearertoken data from API');
    }
  }
 
  async POSTUsernameAndPassword(url: string, body: string): Promise<Response> {
    return await fetch(url, {
      method: 'POST',
      body: body,
      headers:{
        'Content-Type': 'application/json',
      }
    });
  }
 
  async POSTCityCode(url: string, body: string): Promise<Response> {
    return await fetch(url, {
      method: 'POST',
      body: body,
      headers: {
        Authorization: loginAccessKey,
        'Content-Type': 'application/json',
      },
    });
  }

  // Not sure if this works, moved it from `commonUtils.ts` to here  
  async captureBearerToken() {
    let captured = false;

    // Capture network requests
    await global.page.route('**', async (route) => {
      if (captured) {
        route.continue();
        return;
      }
      route.continue();
      const headers = await route.request().headers();
      const authorizationHeader = headers['authorization'];
      if (authorizationHeader && authorizationHeader.startsWith('Bearer ')) {
        const token = authorizationHeader.substring('Bearer '.length);
        console.log('Bearer token:', token);
        captured = true;
      }
    });
  }
}
