import { LoggerUtil } from "./logger";
//import {Workbook, Row, Cell, Worksheet} from 'exceljs';
import Excel from 'exceljs';
import xlsx from "xlsx";
import * as XLSX from 'xlsx';
import { JsonOperations } from "./jsonOperations";
//import { Workbook, Worksheet } from "exceljs";
let log = new LoggerUtil()
let jsonUtil = new JsonOperations()

export class excelUtil extends LoggerUtil {
  async readingFromCell(
    path,
    sheetname,
    rowno: string | number,
    colno: string | number
  ) {
    let workbook = new Excel.Workbook();
    await workbook.xlsx.readFile(path);
    let sheet = workbook.getWorksheet(sheetname);
    let cellValue = sheet.getCell(rowno, colno).toString();
    await this.info("Cell value is " + cellValue);
  }

  async writingToCell(
    path,
    sheetname,
    rowno: string | number,
    colno: string | number
  ) {
    let workbook = new Excel.Workbook();
    await workbook.xlsx.readFile(path);
    let sheet = await workbook.getWorksheet(sheetname);
    sheet.getCell(rowno, colno).value = "Ratnesh";
    await workbook.xlsx.writeFile(path);
    await this.info("Cell is updated with value "+sheet.getCell(rowno, colno).toString());
  }

  async readingSheet(
    path,
    sheetname
  ) {
    let workbook = new Excel.Workbook();
    await workbook.xlsx.readFile(path);
    let sheet = await workbook.getWorksheet(sheetname);
    await this.info("Row count is "+sheet.actualRowCount);
    await this.info("Column count is "+sheet.actualColumnCount);
    //Get all the rows data [1st and 2nd column]
    let list: Array<any> = [];
    for (let i = 1; i <= sheet.actualRowCount; i++) { 
      await this.info("Value of "+ i +" Row")
        for (let j = 1; j <= sheet.actualColumnCount; j++) {
          await this.info(sheet.getRow(i).getCell(j).value);
            list.push(sheet.getRow(i).getCell(j).value);   
        }   
    }
    return list;
  }

  async readingRow(
    path,
    sheetname,
    rowNo
  ) {
    let workbook = new Excel.Workbook();
    await workbook.xlsx.readFile(path);
    let sheet = await workbook.getWorksheet(sheetname);
    await this.info("Row count is "+sheet.actualRowCount);
    await this.info("Column count is "+sheet.actualColumnCount);
    //Get all the rows data [1st and 2nd column]
    let list: Array<any> = [];
    for (let i = 2; i <= sheet.actualColumnCount; i++) { 
      await this.info(sheet.getRow(rowNo).getCell(i).value);
      list.push(sheet.getRow(rowNo).getCell(i).value);  
    }
    return list;
  }

  async rowCount(
    path,
    sheetname
  ) {
    let workbook = new Excel.Workbook();
    await workbook.xlsx.readFile(path);
    let sheet = await workbook.getWorksheet(sheetname);
    await this.info("Actual Row count is "+sheet.actualRowCount);
    return sheet.actualRowCount;
  }

  async colCount(
    path,
    sheetname
  ) {
    let workbook = new Excel.Workbook();
    await workbook.xlsx.readFile(path);
    let sheet = await workbook.getWorksheet(sheetname);
    await this.info("Actual Column count is "+sheet.actualColumnCount);
    return sheet.actualColumnCount;
  }

  async readingColumn(
    path,
    sheetname,
    colNo
  ) {
    let workbook = new Excel.Workbook();
    await workbook.xlsx.readFile(path);
    let sheet = await workbook.getWorksheet(sheetname);
    await this.info("Row count is "+sheet.actualRowCount);
    await this.info("Column count is "+sheet.actualColumnCount);
    //Get all the rows data [1st and 2nd column]
    let list: Array<any> = [];
    for (let i = 2; i <= sheet.actualRowCount; i++) { 
      await this.info(sheet.getRow(i).getCell(colNo).value);
      let data = sheet.getRow(i).getCell(colNo).text;
      if(data == null){
        await list.push("");
      }
      else{
        await list.push(data.toString().trim());
      }
    }
    return list;
  }

  async excelToJson(path, sheetname){
    var wb = xlsx.readFile(path)
    var ws = wb.Sheets[sheetname];
    return xlsx.utils.sheet_to_json(ws)
  }

  async excelToCsv(path, sheetname){
    var wb = xlsx.readFile(path)
    var ws = wb.Sheets[sheetname];
    return xlsx.utils.sheet_to_csv(ws)
  }

  async excel_To_Json(filePath, sheetName){
    const workbook = XLSX.readFile(filePath);
    const worksheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(worksheet);
    //console.log(data);
    return data
  }

  async getCellValueFromExcel(filePath, sheetName, cellname){
    const workbook = XLSX.readFile(filePath);
    const worksheet = workbook.Sheets[sheetName];
    const cell = worksheet[cellname];
    const value = cell.v;
    return value
  }

  async getRowNumberByColumnValue(filePath, sheetName, columnName, searchValue) {
    const workbook = XLSX.readFile(filePath);
    const worksheet =  workbook.Sheets[sheetName];
    const columnNumber = XLSX.utils.decode_col(columnName);
    const ref = worksheet['!ref'];
    if (!ref) {
      throw new Error(`Sheet ${sheetName} has no defined range`);
    }
    const range = XLSX.utils.decode_range(ref);
    for (let rowNum = range.s.r; rowNum <= range.e.r; rowNum++) {
      const cellAddress = XLSX.utils.encode_cell({ r: rowNum, c: columnNumber });
      const cell = worksheet[cellAddress];
      if (cell && cell.v == searchValue) {
        console.log("Row Number for searched Item :", rowNum)
        return rowNum; // add 1 to convert 0-indexed row number to 1-indexed row number
      }
    }
    throw new Error(`Row with value ${searchValue} not found in column ${columnName} of sheet ${sheetName}`);
  }


  async  verifyColumnContainsValue(filename: string, sheetName: string, columnName: string, searchValue: any, propName:string): Promise<boolean> {
    const filePath = "./src/resources/results/"+filename;
    const workbook = await xlsx.readFile(filePath);
    const worksheet = workbook.Sheets[sheetName];
    const columnNumber = xlsx.utils.decode_col(columnName);
    const ref = worksheet['!ref'];
    if (!ref) {
      throw new Error(`Sheet ${sheetName} has no defined range`);
    }
    const range = XLSX.utils.decode_range(ref);
    for (let rowNum = range.s.r; rowNum <= range.e.r; rowNum++) {
      const cellAddress = XLSX.utils.encode_cell({ r: rowNum, c: columnNumber });
      const cell = worksheet[cellAddress];
      if (cell && cell.v == searchValue) {
        await log.info("Column contains value "+searchValue)
        const data = `Verified file contains ${propName} value : ${searchValue} from Review Configured Page`
         
        await jsonUtil.writeDataToTextFile(filename,data)
        return true;
        
      }
      else{
        await log.info("Column does not contain value "+searchValue)
      }
    }
    return false;
  }

  async verifyRowContainsArray(filename: string, sheetName: string, rowNumber: number, searchValue: any[]): Promise<boolean> {
    const filePath = `./src/resources/results/${filename}`;
    const workbook = await xlsx.readFile(filePath);
    const worksheet = workbook.Sheets[sheetName];
    const ref = worksheet['!ref'];
    if (!ref) {
      throw new Error(`Sheet ${sheetName} has no defined range`);
    }
    const range = xlsx.utils.decode_range(ref);
  
    for (const value of searchValue) {
      let valueFound = false;
  
      for (let colNum = range.s.c; colNum <= range.e.c; colNum++) {
        const cellAddress = xlsx.utils.encode_cell({ r: rowNumber, c: colNum });
        const cell = worksheet[cellAddress];
        console.log(`Cell ${cellAddress}: ${cell.v}`)
        if (cell && cell.v == value) {
          valueFound = true;
          log.info(`Row ${rowNumber} contains value ${value}`);
          break;
        }
      }
  
      if (!valueFound) {
        await log.info(`Row ${rowNumber} does not contain value ${value}`);
        return false;
      }
    }
  
    await log.info(`Row ${rowNumber} contains all the values from the search array.`);
    return true;
  }

  async getCellValue(
    filename: string,
    sheetName: string,
    rowNumber: number,
    colName: string,
  ) {
    const filePath = `./src/resources/results/${filename}`;
    const workbook = await xlsx.readFile(filePath);
    const worksheet = workbook.Sheets[sheetName];
    
    const colNumber = xlsx.utils.decode_col(colName);
    const cellAddress = xlsx.utils.encode_cell({ r: rowNumber, c: colNumber });
    const cellValue = (worksheet[cellAddress]?.v ?? '').toString();
    return cellValue
  }


async verifyCellValue(
    filename: string,
    sheetName: string,
    rowNumber: number,
    colName: string,
    expectedValue: any
  ){
    const filePath = `./src/resources/results/${filename}`;
    const workbook = await xlsx.readFile(filePath);
    const worksheet = workbook.Sheets[sheetName];
    
    const colNumber = xlsx.utils.decode_col(colName);
    const cellAddress = xlsx.utils.encode_cell({ r: rowNumber, c: colNumber });
    const cellValue = (worksheet[cellAddress]?.v ?? '').toString(); // Convert value to string
    
    if (cellValue == expectedValue.toString()) {
      log.info(`Cell (${rowNumber}, ${colName}) contains the expected value: ${expectedValue}`);
      return 0;
    } else {
      log.info(`Cell (${rowNumber}, ${colName}) does not contain the expected value: ${expectedValue}, cell Value: ${cellValue}`);
      return 1;
    }
  }

  async verifyCellValueWithPercentage(
    filename: string,
    sheetName: string,
    rowNumber: number,
    colName: string,
    expectedValue: any
 ){
    const filePath = `./src/resources/results/${filename}`;
    const workbook = await xlsx.readFile(filePath);
    const worksheet = workbook.Sheets[sheetName];
    
    const colNumber = xlsx.utils.decode_col(colName);
    const cellAddress = xlsx.utils.encode_cell({ r: rowNumber, c: colNumber });
    const cellvalueFloat = ((worksheet[cellAddress]?.v ?? '') * 100).toFixed(2)
    // const cellValue = (worksheet[cellAddress]?.v ?? '').toString(); // Convert value to string
    const cellValue = cellvalueFloat+"%"
    
    if (cellValue == expectedValue.toString()) {
      log.info(`Cell (${rowNumber}, ${colName}) contains the expected value: ${expectedValue}`);
      return 0;
    } else {
      log.info(`Cell (${rowNumber}, ${colName}) does not contain the expected value: ${expectedValue}, cell Value: ${cellValue}`);
      return 1;
    }
  }


  async verifyCellFloatValuewith$(
    filename: string,
    sheetName: string,
    rowNumber: number,
    colName: string,
    expectedValue: any
  ){
    const filePath = `./src/resources/results/${filename}`;
    const workbook = await xlsx.readFile(filePath);
    const worksheet = workbook.Sheets[sheetName];
    
    const colNumber = xlsx.utils.decode_col(colName);
    const cellAddress = xlsx.utils.encode_cell({ r: rowNumber, c: colNumber });
    const cellValue = (worksheet[cellAddress]?.v ?? '').toString(); // Convert value to string
    const numericValue = parseFloat(cellValue);
    const formattedValue = numericValue.toFixed(2); 
    const cellFloatValuewith$ = `$${formattedValue}`
    const expectedValue_withoutComma = (expectedValue.toString()).replace(/,/g, '');
    if (cellFloatValuewith$ == expectedValue_withoutComma) {
      log.info(`Cell (${rowNumber}, ${colName}) contains the expected value: ${expectedValue_withoutComma}, cell Value: ${cellFloatValuewith$}`);
      return 0;
    } else {
      log.info(`Cell (${rowNumber}, ${colName}) does not contain the expected value: ${expectedValue_withoutComma}, cell Value: ${cellFloatValuewith$}`);
      return 1;
    }
  }
  
  async convertExcelDateToreadabledate(numericDateValue){
    const jsDateComponents = await xlsx.SSF.parse_date_code(numericDateValue);
    const jsDate = new Date(
        jsDateComponents.y,  // year
        jsDateComponents.m-1, // month (0-based)
        jsDateComponents.d   // day
      );
      
    
    const formattedDate = `${(jsDate.getMonth() + 1).toString().padStart(2, '0')}/${jsDate.getDate().toString().padStart(2, '0')}/${jsDate.getFullYear()}`; 
    console.log(formattedDate); // This will output the formatted date (yyyy/mm/dd)
    return formattedDate
    }

    async verifyDateCellValue(
        filename: string,
        sheetName: string,
        rowNumber: number,
        colName: string,
        expectedValue: any
      ){
        const filePath = `./src/resources/results/${filename}`;
        const workbook = await xlsx.readFile(filePath);
        const worksheet = workbook.Sheets[sheetName];
        
        const colNumber = xlsx.utils.decode_col(colName);
        const cellAddress = xlsx.utils.encode_cell({ r: rowNumber, c: colNumber });
        const cellNumValue = (worksheet[cellAddress]?.v ?? '').toString(); // Convert value to string
        const cellValue = await this.convertExcelDateToreadabledate(cellNumValue)
        const expectedDateSlashFormat = (expectedValue.toString()).replace(/-/g, "/")
        if (cellValue == expectedDateSlashFormat) {
          await log.info(`Cell (${rowNumber}, ${colName}) contains the expected value: ${expectedDateSlashFormat}`);
          return true;
        } else {
          await log.info(`Cell (${rowNumber}, ${colName}) does not contain the expected value: ${expectedDateSlashFormat}, cell Value: ${cellValue}`);
          return false;
        }
      }

      async verifyDateCellValueSlashFormat(
        filename: string,
        sheetName: string,
        rowNumber: number,
        colName: string,
        expectedValue: any
      ){
        const filePath = `./src/resources/results/${filename}`;
        const workbook = await xlsx.readFile(filePath);
        const worksheet = workbook.Sheets[sheetName];
        
        const colNumber = xlsx.utils.decode_col(colName);
        const cellAddress = xlsx.utils.encode_cell({ r: rowNumber, c: colNumber });
        const cellNumValue = (worksheet[cellAddress]?.v ?? '').toString(); // Convert value to string
        const cellValue = (await this.convertExcelDateToreadabledate(cellNumValue)).replace(/-/g, "/")

        if (cellValue == expectedValue.toString()) {
          await log.info(`Cell (${rowNumber}, ${colName}) contains the expected value: ${expectedValue}`);
          return true;
        } else {
          await log.info(`Cell (${rowNumber}, ${colName}) does not contain the expected value: ${expectedValue}, cell Value: ${cellValue}`);
          return false;
        }
      }

      async copydataFromExceltoExcel(
        sourceFilePath: string,
        destinationFilePath: string,
        startCell: string,
        endCell: string
      ) {
        try {
          // Read data from the source Excel file
          const sourceWorkbook = XLSX.readFile(sourceFilePath);
          const sourceSheetName = sourceWorkbook.SheetNames[0];
          const sourceSheet = sourceWorkbook.Sheets[sourceSheetName];
      
          // Read data from the existing destination Excel file
          const destinationWorkbook = XLSX.readFile(destinationFilePath);
      
          // Copy data from the specified range to the destination sheet
          const range = XLSX.utils.decode_range(`${startCell}:${endCell}`);
          const destinationSheet = destinationWorkbook.Sheets[sourceSheetName];
      
          for (const cellAddress in sourceSheet) {
            if (sourceSheet.hasOwnProperty(cellAddress)) {
              if (
                XLSX.utils.decode_cell(cellAddress).r >= range.s.r &&
                XLSX.utils.decode_cell(cellAddress).r <= range.e.r &&
                XLSX.utils.decode_cell(cellAddress).c >= range.s.c &&
                XLSX.utils.decode_cell(cellAddress).c <= range.e.c
              ) {
                destinationSheet[cellAddress] = sourceSheet[cellAddress];
              }
            }
          }
      
          // Write the destination workbook (with replaced data) back to the destination Excel file
          XLSX.writeFile(destinationWorkbook, destinationFilePath);
      
          console.log('Data copied successfully!');
        } catch (error) {
          console.error('An error occurred:', error);
        }
      }

      async setCellValue(
        filename: string,
        sheetName: string,
        rowNumber: number,
        colName: string,
        newValue: any // The new value to write to the cell
      ) {
        const filePath = `./src/resources/results/${filename}`;
        const workbook = await xlsx.readFile(filePath);
        const worksheet = await workbook.Sheets[sheetName];
        //console.log("Workbook:", workbook);
        console.log("Worksheet:", worksheet);
      
        const colNumber = xlsx.utils.decode_col(colName);
        const cellAddress = xlsx.utils.encode_cell({ r: rowNumber, c: colNumber });
      
        try {
            // Update the cell with the new value
            worksheet[cellAddress] = { v: newValue };
          
            // Write the changes back to the file
            await xlsx.writeFile(workbook, filePath);
            const workbook1 = await xlsx.readFile(filePath);
            const worksheet1 = await workbook1.Sheets[sheetName];
            console.log("Worksheet:", worksheet1);
          } catch (error) {
            console.error("An error occurred:", error);
          }
      }
  
      async setCellValueInExcel(
        filename: string,
        sheetName: string,
        rowNumber: number,
        colName: string,
        newValue: any
    ) {
        const filePath = `./src/resources/results/${filename}`
        try {
            const workbook = new Excel.Workbook();
            await workbook.xlsx.readFile(filePath);

            const worksheet = workbook.getWorksheet(sheetName);
            // const colNumber = worksheet.getColumnKey(colName);
            worksheet.getCell(`${colName}${rowNumber}`).value = newValue;

            await workbook.xlsx.writeFile(filePath);

            const workbook1 = xlsx.readFile(filePath);
            const worksheet1 = workbook1.Sheets[sheetName];
            console.log(`Updated Worksheet in ${filename}:`, worksheet1);
        } catch (error) {
            console.error("An error occurred:", error);
        }
    }
    async copyDataFromExcelToExcelWithRandomValue(
        sourceFilePath: string,
        destinationFilePath: string,
        getRandomValue: any,
        targetCell: string
      ) {
        try {
          
          // Read data from the source Excel file
          const sourceWorkbook = XLSX.readFile(sourceFilePath);
          const sourceSheetName = sourceWorkbook.SheetNames[0];
          const sourceSheet = sourceWorkbook.Sheets[sourceSheetName];
      
          // Read data from the existing destination Excel file
          const destinationWorkbook = XLSX.readFile(destinationFilePath);
          const destinationSheet = destinationWorkbook.Sheets[sourceSheetName];
      
          // Update the value of the specified target cell randomly
          const targetCellAddress = XLSX.utils.decode_cell(targetCell);
          const randomValue = await getRandomValue;
          destinationSheet[targetCell] = { t: 'n', v: randomValue, w: String(randomValue) };
      
          // Write the destination workbook (with updated data) back to the destination Excel file
          XLSX.writeFile(destinationWorkbook, destinationFilePath);
      
          console.log('Data updated successfully!');
        } catch (error) {
          console.error('An error occurred:', error);
        }
    }
    async  getColumnValues(
        filename: string,
        sheetName: string,
        colName: string
      ) {
        const filePath = `./src/resources/data/scenarios/${filename}`
        const workbook = await xlsx.readFile(filePath);
        const worksheet = workbook.Sheets[sheetName];
        const colNumber = xlsx.utils.decode_col(colName);
        const values: any[] = []; // Specify a type or use 'any' for flexibility
        for (let rowNumber = 1; ; rowNumber++) {
          const cellAddress = xlsx.utils.encode_cell({ r: rowNumber, c: colNumber });
          const cellValue = worksheet[cellAddress]?.v;
          if (cellValue === undefined) {
            break; // Stop when the column is empty
          }
          values.push(cellValue);
        }
        return values;
      }
}


