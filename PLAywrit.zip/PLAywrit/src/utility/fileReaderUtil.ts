import csv from 'csv-parser';
import fs from 'fs';
import * as pdfjsLib from 'pdfjs-dist';


export class FileReaderUtils{

async DatFileReader(filePath){
    // const filePath = './src/resources/results/Itron_MV-RS_FCS1_download_20230315114318.dat';
    // fs.createReadStream(filePath)
    // .pipe(csv())
    // .on('data', (data) => {
    //     console.log(data);
    // })
    // .on('end', () => {
    //     console.log('Finished reading file.');
    // });async function readCsvFile(filePath: string) {
    // }
    return new Promise((resolve, reject) => {
        const results: any[] = [];
        fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (data) => {
            results.push(data);
        })
        .on('end', () => {
            resolve(results);
        })
        .on('error', (error) => {
            reject(error);
        });
    });
    }

async ReadDatFileData(){
    try {
        const filePath = './src/resources/results/Neptune Equinox_download75677_20230420162152.dat';
        const data = await this.DatFileReader(filePath);
        console.log(data);
        return data

      } catch (error) {
        console.error(error);
      }

}

async copyAndRenameFile(sourceFilePath,destinationFilePath,oldFileName,newFilename) {
//   const sourceFilePath = 'path/to/source/file.txt';
//   const destinationFilePath = 'path/to/destination/new_file.txt';

    try {
        await fs.promises.copyFile(sourceFilePath, destinationFilePath);
        await fs.promises.rename(destinationFilePath, 'path/to/destination/renamed_file.txt');
        console.log('File copied and renamed successfully!');
    } catch (error) {
        console.error('Error copying or renaming file:', error);
    }
}


}
