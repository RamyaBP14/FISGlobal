export declare function route(url: string, headerOptions?: object, HttpMethod?: string, inputBody?: string, formFlag?: boolean): Promise<any>;
