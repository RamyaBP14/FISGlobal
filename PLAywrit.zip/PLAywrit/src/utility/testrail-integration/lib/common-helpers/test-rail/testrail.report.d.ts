import { INewTestResultImpl } from "./testrail.implements";
import { HookScenarioResult } from "cucumber";
import { TestRailClient } from "./testrail";
export declare class CucumberRailClient extends TestRailClient {
    addAndUpdateTestCaseResult(scenario: HookScenarioResult, runID: number, caseId: number, content: INewTestResultImpl): Promise<void>;
    updateTestRailResults(scenario: any, runID: number, version: string): Promise<void>;
}
