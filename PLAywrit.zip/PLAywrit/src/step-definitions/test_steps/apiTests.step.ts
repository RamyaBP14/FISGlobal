import { Given, Then, World } from "@cucumber/cucumber"
import { Meters } from "../../API/classes/ops_hub/meters"
import { dbUtil } from "../../utility/dbUtil"
import { Meter } from "../../API/objects/ops_hub/meter"
import { expect } from "@playwright/test"
import { Persons } from "../../API/classes/ops_hub/persons"
import { Person } from "../../API/objects/ops_hub/person"
import { ServiceLocations } from "../../API/classes/ops_hub/serviceLocations"
import { ServiceLocation } from "../../API/objects/ops_hub/serviceLocation"
import { UbAccounts } from "../../API/classes/ub_hub/ubAccounts"
import { UbAccount } from "../../API/objects/ub_hub/ubAccount"
import { PageBase } from "../../utility/PageBase"
import { QueryResult } from "pg"

const apiMeter = new Meters()
const apiPerson = new Persons()
const apiServiceLocation = new ServiceLocations()
const apiUbAccount = new UbAccounts()
const dbConn = new dbUtil()
const pageBase = new PageBase()

let meter: Meter
let person: Person
let serviceLocation: ServiceLocation
let ubAccount: UbAccount

Given(/^I create a Meter$/, async function () {
  meter = await apiMeter.createMeter("WATER")
})

Given(/^I create a Person$/, async function () {
  person = await apiPerson.createPerson('Zach', 'Wheeler')
  console.log(person)
})

Given(/^I create a Service Location$/, async function () {
  serviceLocation = await apiServiceLocation.createServiceLocation(person)
  await pageBase.wait(5000)
})

Given(/^I create a UB Account$/, async function () {
  ubAccount = await apiUbAccount.createAccount(
    serviceLocation,
    person
  )
  console.log(ubAccount)
  expect(ubAccount).toBeDefined()
})

Then(/^I assert the Meter was created$/, async function () {
  const query = await dbConn.dbConnectAndQuery(
    `SELECT * FROM "OH"."Assets" WHERE "AssetId" = '${meter.meterId}';`
  )
  expect(query, 'Meter was not created').not.toBeUndefined()
})

Then(/^I assert the Person was created$/, async function () {
  const query = await dbConn.dbConnectAndQuery(
    `SELECT * FROM city.person WHERE id = ${person.id}`
  )
  expect(query, 'Person was not created').not.toBeUndefined()
})