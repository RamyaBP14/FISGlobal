import { Given, Then, When } from "@cucumber/cucumber"
import { dbUtil } from "../../utility/dbUtil"
import { UbAccounts } from "../../API/classes/ub_hub/ubAccounts"
import { expect } from "@playwright/test"

const dbConnection = new dbUtil()
const apiUbAccount = new UbAccounts()

Given(/^I can connect to the database$/, async function () {
  await dbConnection.dbConnectAndQuery('SELECT * FROM "UB"."AccountPaymentTypes" LIMIT 10;')
})

Given(/^I can query Rate Tables "([^"]*)"$/, async function (code: string) {
  const response: string = await apiUbAccount.getRateTableCode(code)
  expect(response).toBeDefined()
})

Given(/^I can query Tax Tables "([^"]*)"$/, async function (code: string) {
  const response: string = await apiUbAccount.getTaxTableCode(code)
  expect(response).toBeDefined()
})

Given(/^I can query a random Rate Table$/, async function () {
  const response: string = await apiUbAccount.getRateTableCode()
  console.log(response)
  expect(response).toBeDefined()
})

Given(/^I can query a random Tax Table$/, async function () {
  const response: string = await apiUbAccount.getTaxTableCode()
  console.log(response)
  expect(response).toBeDefined()
})