import { Then } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { HomePage } from "../pom/ui/hr_hub/homePage";
import { PayrollSettingsPage } from "../pom/ui/hr_hub/payRollSettings";
import { PayTypesPage } from "../pom/ui/hr_hub/payTypesPage";
import { LoggerUtil } from "../utility/logger";
import { deductiblesPage } from "../pom/ui/hr_hub/deductiblesPage";
import { PageBase } from "../utility/PageBase";
import { LeaveTypesPages } from "../pom/ui/hr_hub/LeaveTypesPages";
import { AssetRepositoryPage } from "../pom/ui/ops_hub/assetRepositoryPage";
import { AddAccountPage } from "../pom/ui/ub_hub/addAccountPage";
import { AccountsPage } from "../pom/ui/ub_hub/accountsPage";
import { AccountDetailsSummaryPage } from "../pom/ui/ub_hub/accountDetailsSummaryPage";
import { AccountServicesPage } from "../pom/ui/ub_hub/accountDetailsServicesPage";
import { AddEmployee } from "../pom/ui/hr_hub/addEmployee";
import { LeaveTypePageClass } from "../pom/ui/hr_hub/LeavesTypes";
import { AddTaxTablePage } from "../pom/ui/ub_hub/addTaxTablePage";
import { SetupFuelAdjustment } from "../pom/ui/ub_hub/setupFuelAdjustmentPage";
import { CommonUtils } from "../utility/commonUtils";
import { JsonOperations } from '../utility/jsonOperations' 

let jsonUtil = new JsonOperations();
let homepage = new HomePage();
let paytypes = new PayTypesPage();
let deductiblepage = new deductiblesPage();
let pagebase = new PageBase();
let log = new LoggerUtil();
let payrollSettings = new PayrollSettingsPage();
let LeavesTypes = new LeaveTypePageClass();
let LeaveType = new LeaveTypesPages();
let assetRepository = new AssetRepositoryPage();
let addAccountPage = new AddAccountPage();
let accounts = new AccountsPage();
let accountDetails = new AccountDetailsSummaryPage();
let accountServices = new AccountServicesPage();
let addEmployee = new AddEmployee();
let addTaxTable = new AddTaxTablePage();
let setupFuelAdjustment = new SetupFuelAdjustment();
let commonUtils = new CommonUtils()
let genValue1="";

Then(/^the Add Pay Types window should be displayed$/, async function () {
    await paytypes.verifyAddPayTypesWindow();
});
Then(
    /^I should see Add button as active and Cancel button as Inactive$/,
    async function () {
        await paytypes.verifyAddButton("Visible", "Disabled", "Add");
        await paytypes.verifyCancelButton("Visible", "Enabled", "Cancel");
    }
)
//);

Then(/^the Add Pay Types window should be closed$/, async function () {
    await paytypes.verifyPayTypeWindow();
});

Then(/^I should be able see save button as enabled$/, async function () {
    await paytypes.verifySaveButtonState("Enabled");
});

Then(/^I should be able to see save button as disabled$/, async function () {
    await paytypes.verifySaveButtonState("Disabled");
});

Then(
    /^I should be able to see message "([^"]*)"$/,
    async function (expectedValue: string) {
        await paytypes.verifyPayTypeAdded(expectedValue);
    }
);

Then(/^I should be able see recently added paytype$/, async function () {
    log.info("New Entry Label Name : ", global.genlabelName);
    await paytypes.verifyRecetlyAddedPaytype(global.genlabelName);
});

Then(/^I should see Add to toggle button as Inactive$/, async function () {
    await paytypes.verifyPensionEarningToggle("Disabled");
});

Then(/^I should see Add to toggle button as active$/, async function () {
    await paytypes.verifyPensionEarningToggle("Checked");
});

Then(/^I should be able to see Salary Amount field$/, async function () {
    await paytypes.verifyFieldsSalaryType("Visible");
});

Then(
    /^I should be able to see Hourly Rate,Over Time - Rate field$/,
    async function () {
        await paytypes.verifyFieldsHourlyType("Visible");
    }
);

Then(/^I should be able to see Per Item Rate field$/, async function () {
    await paytypes.verifyFieldsPerItemType("Visible");
});

Then(/^I should be able to see Amount field$/, async function () {
    await paytypes.verifyAllowanceType("Visible");
});

Then(/^I should see all payroll nav tabs in active state$/, async function () {
    await payrollSettings.verifySelectedTabHeader("Deductions/Benefits");
    await payrollSettings.verifyDeductionTab(
        "Visible",
        "Enabled",
        "Deductions/Benefits"
    );
    await payrollSettings.verifyPayTypesTab("Visible", "Enabled", "Pay Types");
    await payrollSettings.verifyLeaveTypesTab(
        "Visible",
        "Enabled",
        "Leave Types"
    );
    await payrollSettings.verifyVendorsTab("Visible", "Enabled", "Vendors");
    await payrollSettings.verifyCostCentersTab(
        "Visible",
        "Enabled",
        "Cost Centers"
    );
    await payrollSettings.verifyCitySettingsTab(
        "Visible",
        "Enabled",
        "City Settings"
    );
});

Then(
    /^I should see that Deductions Benifits is the pre-selected tab and header is displayed as Deductions Benefits$/,
    async function () {
        await payrollSettings.waitforDeductionWindowToDisplay();
    }
);

Then(
    /^I should see that Pay Types tab and header is displayed as "([^"]*)"$/,
    async (headerText) => {
        await payrollSettings.verifySelectedTabHeader(headerText);
    }
);

Then(
    /^I should see the all the table columns header are as per the deduction page$/,
    async function () {
        await payrollSettings.verifyColumnHeader("Label");
        await payrollSettings.verifyColumnHeader("Modified");
        await payrollSettings.verifyColumnHeader("Created");
    }
);

Then(
    /^I should see the all the table columns header are as per the Pay Types page$/,
    async () => {
        await payrollSettings.verifyColumnHeader("Label");
        await payrollSettings.verifyColumnHeader("Type-Frequency");
        await payrollSettings.verifyColumnHeader("Modified");
        await payrollSettings.verifyColumnHeader("Created");
    }
);

Then(
    /^I should see the all the table columns header are as per the Vendors page$/,
    async () => {
        await payrollSettings.verifyColumnHeader("Label");
        await payrollSettings.verifyColumnHeader("Modified");
        await payrollSettings.verifyColumnHeader("Created");
    }
);

Then(
    /^I should see the all the table columns header are as per the Leave Types page$/,
    async () => {
        await payrollSettings.verifyColumnHeader("Label");
        await payrollSettings.verifyColumnHeader("Type");
        await payrollSettings.verifyColumnHeader("Modified");
        await payrollSettings.verifyColumnHeader("Created");
    }
);

Then(
    /^I should see the all the table columns header are as per the Cost Centers page$/,
    async () => {
        await payrollSettings.verifyColumnHeader("Label");
        await payrollSettings.verifyColumnHeader("Code");
        await payrollSettings.verifyColumnHeader("Modified");
        await payrollSettings.verifyColumnHeader("Created");
    }
);

Then(
    /^All the row data should be sorted in descending order as per "([^"]*)"$/,
    async function (columnName: string) {
        await payrollSettings.verifyLabelDescSorting(columnName);
    }
);

Then(
    /^All the row data should be sorted in ascending order as per "([^"]*)"$/,
    async function (columnName: string) {
        await payrollSettings.verifyLabelAscSorting(columnName);
    }
);

Then(
    /^All the row data should be sorted in ascending orderUbhub as per "([^"]*)"$/,
    async function (columnName: string) {
        await payrollSettings.verifyLabelAscSortingUbhub(columnName);
    }
);

Then(
    /^All the row data should be sorted in descending orderUbhub as per "([^"]*)"$/,
    async function (columnName: string) {
        await payrollSettings.verifyLabelDescSortingUbhub(columnName);
    }
);

Then(/^All the row data should be sorted in ascending order as per "([^"]*)" case sensitive off$/, async (columnName: string) => {
    await payrollSettings.verifyLabelAscSortingCaseSensitiveOff(columnName);
});


Then(/^All the row data should be sorted in descending order as per "([^"]*)" case sensitive off$/, async (columnName: string) => {
	await payrollSettings.verifyLabelDescSortingCaseSensitiveOff(columnName);
});


Then(
    /^All the row data should be sorted in ascending order as per "([^"]*)" dates$/,
    async (columnName) => {
        await payrollSettings.verifyDatesAscSorting(columnName);
    }
);

Then(
    /^All the row data should be sorted in descending order as per "([^"]*)" dates$/,
    async (columnName) => {
        await payrollSettings.verifyDatesDescSorting(columnName);
    }
);

Then(
    /^The number of items displayed in the page should be "([^"]*)"$/,
    async (NumberofItems) => {
        await payrollSettings.verifyShownPageNumber(NumberofItems);
        await payrollSettings.verifyNumberofItemsInPage(NumberofItems);
    }
);

Then(
    /^All the entry which contains test should be displayed in the selected page for "([^"]*)"$/,
    async (columnName) => {
        await payrollSettings.verifySearchedItems(columnName, "test");
    }
);

Then(
    /^Total number of pages should be displayed as per the selected items per page and the total number of items$/,
    async () => {
        await payrollSettings.verifyTotalPages();
    }
);

Then(/^Page "([^"]*)" should be selected$/, async (pageNumber) => {
    await payrollSettings.verifySelectedPage(pageNumber);
});

Then(
    /^"([^"]*)" button should be "([^"]*)" and text should be displayed as "([^"]*)"$/,
    async (button, buttonState, buttonValue) => {
        await payrollSettings.verifyPaginationButton(buttonValue, buttonState);
    }
);

Then(
    /^"([^"]*)" button should be displayed as "([^"]*)"$/,
    async (button, buttonState) => {
        await payrollSettings.verifyPaginationButtonsState(button, buttonState);
    }
);

Then(
    /^"([^"]*)" page should be displayed as selected$/,
    async (paginationButton) => {
        await payrollSettings.verifyPaginationSelectedPage(paginationButton);
    }
);

Then(/^Previous button should be disabled$/, async () => {
    await payrollSettings.verifyPaginationButtonsState("previous", "Enabled");
});

Then(/^the Add Deduction overlay should be displayed$/, async function () {
    await global.page.waitForLoadState();
    await deductiblepage.NavigatetoBasicTab();
});

Then(/^the Basic Tab should be displayed$/, async function () {
    await global.page.waitForLoadState();
    await deductiblepage.NavigatetoBasicTab();
});

Then(/^verify all the attributes under Basic Pay Tab$/, async function () {
    await global.page.waitForLoadState();
    await deductiblepage.verifyBasicTabAttributes();
});

Then(/^verify the attributes of Frequency dropdown$/, async function () {
    await deductiblepage.verifyFrequencyvalues("Every Paycheck");
    await deductiblepage.verifyFrequencyvalues("Month");
});

Then(/^verify If Pension Toggle can be turned on$/, async function () {
    await deductiblepage.togglePension();
});

Then(/^verify If Disposable Toggle can be turned on$/, async function () {
    await deductiblepage.toggleDisposable();
});

Then(/^verify If Checkbox Federal can be Checked$/, async function () {
    await deductiblepage.checkFederalTax();
});

Then(/^verify If Checkbox State can be Checked$/, async function () {
    await deductiblepage.checkStateTax();
});

Then(/^verify If Checkbox Local can be Checked$/, async function () {
    await deductiblepage.checkLocalTax();
});

Then(/^verify If Checkbox Medicare can be Checked$/, async function () {
    await deductiblepage.checkMedicareTax();
});

Then(/^verify If Checkbox SocialSecurity can be Checked$/, async function () {
    await deductiblepage.checkSocialSecurity();
});

Then(/^Add attribute values under Tab Basic$/, async function () {
    await deductiblepage.enterlabelvalue("TestAutomation");
    await deductiblepage.selectFrequency("Month");
    await deductiblepage.togglePension();
    await deductiblepage.checkFederalTax();
    await deductiblepage.checkLocalTax();
});

Then(
    /^Toggle "Set at Employee" attribute under Tab Contribution$/,
    async function () {
        await deductiblepage.NavigatetoContributionTab();
        await deductiblepage.toggleSetasEmployee();
    }
);

Then(/^Select the (.*) vendor under Tab Vendor$/, async function (msg) {
    await deductiblepage.NavigatetoVendorTab();
    await deductiblepage.selectvendor(await addEmployee.makeString(msg));
});

Then(
    /^Toggle the "Print in Box 10" attribute under Tab W2$/,
    async function () {
        await deductiblepage.NavigatetoW2Tab();
        await deductiblepage.togglePrintbox10();
    }
);

Then(
    /^Add the Cost center details under Cost Center Distribution Tab$/,
    async function () {
        await deductiblepage.NavigatetoCostcenterdistributionTab();
        await deductiblepage.selectcostcenter("test");
        await deductiblepage.enterdeductibledebit();
        await deductiblepage.enterdeductiblecredit();
        await deductiblepage.enterbenefitdebit();
    }
);

Then(/^Click on Add button$/, async function () {
    await deductiblepage.clickSave();
});

Then(/^verify the toaster message$/, async function () {
    await deductiblepage.verifyDeductionAdded(" Deduction added successfully. ");
});

Then(
    /^the deductible row should be displayed in the table$/,
    async function () {
        await deductiblepage.verifytbl_deductionrow();
    }
);

Then(/^the deductible row is selected.$/, async function () {
    await deductiblepage.Clicktbl_deductionrow();
});

Then(/^select the deductible from master list for "([^"]*)"$/, async function (fileName) {
    await deductiblepage.apiVerifyNewlyAddedRecord(fileName); 
    await deductiblepage.apiSelectAddedRecord();
});

Then(/^Update the label field under Basic Tab$/, async function () {
    await deductiblepage.enterlabelvalue("TestAutomationUpdated007");
});

Then(/^Toggle Disposable under Basic Tab$/, async function () {
    await deductiblepage.toggleDisposable();
});

Then(/^Click on update button$/, async function () {
    await deductiblepage.clickSave();
});

Then(/^verify the toaster message for Update$/, async function () {
    await deductiblepage.verifyDeductionUpdated(
        " Deduction updated successfully. "
    );
});

Then(
    /^Add attribute values under Tab Basic except that of label$/,
    async function () {
        await deductiblepage.selectFrequency("Month");
        await deductiblepage.togglePension();
        await deductiblepage.checkMedicareTax();
    }
);

Then(
    /^Add the Cost center details under Cost Center Distribution Tab except that of Deduction Credit$/,
    async function () {
        await deductiblepage.NavigatetoCostcenterdistributionTab();
        await deductiblepage.selectcostcenter("a");
        await deductiblepage.enterdeductibledebit();
        await deductiblepage.enterbenefitdebit();
    }
);
Then(
    /^Add the all details under Cost Center Distribution Tab$/,
    async function () {
        // await deductiblepage.NavigatetoCostcenterdistributionTab();
        // await deductiblepage.selectcostcenter("Test");
        // await deductiblepage.enterdeductibledebit();
        // await deductiblepage.enterdeductiblecredit();
        // await deductiblepage.enterbenefitdebit();

        // await deductiblepage.associateVendor("a")
        // await deductiblepage.fillW2RequiredFields() // Need to change above steps as it is now mapped with Finance hub data
        await deductiblepage.fillCostCenterRequiredField("a")
        await deductiblepage.clickSave();
    }
);

Then(/^Verify if "Add" button is disabled.$/, async function () {
    await deductiblepage.verifySaveState("Disabled");
});

Then(/^Enter the label value$/, async function () {
    await deductiblepage.NavigatetoBasicTab();
    await deductiblepage.enterlabelvalue("Automation");
});

Then(/^Enter the Deduction Credit value$/, async function () {
    await deductiblepage.NavigatetoCostcenterdistributionTab();
    await deductiblepage.enterdeductiblecredit();
});

Then(/^Verify if "Add" button is enabled.$/, async function () {
    await deductiblepage.verifySaveState("Enabled");
});

Then(/^Add more than 100 characters in the label field$/, async function () {
    let labeldata = await pagebase.randomString(99);
    await deductiblepage.enterlabelvalue(labeldata + "a");
});

Then(
    /^Verify if the lable textbox is able to take more than 100 characters.$/,
    async function () {
        await deductiblepage.verifyCountinLabel();
    }
);

Then(/^Verify if Label field has asterick mark$/, async function () {
    await deductiblepage.verifyAsterickLabel();
});

Then(/^Verify if Frequency field has asterick mark$/, async function () {
    await deductiblepage.verifyAsterickFrequency();
});

Then(
    /^Edit Paytype overlay should be displayed with respective paytype label record "([^"]*)" as heading$/,
    async (recordNumber) => {
        await paytypes.verifyRecordHeader(recordNumber);
    }
);

Then(
    /^Update button should be displayed as "([^"]*)" with Text "([^"]*)"$/,
    async (state, buttonText) => {
        await paytypes.verifyEditPayTypesUpdateButton(buttonText, state);
    }
);

Then(
    /^Clone button should be displayed as "([^"]*)" with Text "([^"]*)"$/,
    async (state, buttonText) => {
        await paytypes.verifyEditPayTypesCloneButton(buttonText, state);
    }
);

Then(
    /^Cancel button should be displayed as "([^"]*)" with Text "([^"]*)"$/,
    async (state, buttonText) => {
        await paytypes.verifyEditPayTypesCancelButton(buttonText, state);
    }
);

Then(
    /^Edit pay type window should be closed and Pay types window should be displayed$/,
    async () => {
        await paytypes.verifyPayTypeWindow();
    }
);

Then(/^GL Distribution and Audit Trail tab are displayed$/, async () => {
    await paytypes.GLDistributionTabVisibility("Visible");
    await paytypes.AudittabVisibility("Visible");
});

Then(
    /^Edit Paytype overlay should be displayed and Pay Type tab is selected$/,
    async () => {
        await paytypes.verifyPayTypeTab("Selected");
    }
);

Then(
    /^GL Distribution tab should be selected with Text "([^"]*)"$/,
    async (tabText) => {
        await paytypes.verifyGLDistributionTab("Selected", "GL Distribution");
    }
);

Then(
    /^Audit trail tab should be selected with Text "([^"]*)"$/,
    async (tabText) => {
        await paytypes.verifyAuditTrailTab("Selected", "Audit Trail");
    }
);

Then(/^I should be able to see update message "([^"]*)"$/, async (msg) => {
    await paytypes.verifyPayTypeUpdated(msg);
});

Then(
    /^I should be able see recently updated record with updated data$/,
    async () => {
        log.info("New Entry Label Name : ", global.genlabelName);
        await paytypes.verifyRecetlyAddedPaytype(global.genlabelName);
    }
);

Then(
    /^I should be able to click on sorting of created column$/,
    async () => {
          await paytypes.clickOnCreatedSort();
    }
);
Then(/^No record should be found with old label name$/, async () => {
    await paytypes.verifyrecordswithOldLabel(global.oldLabelName);
});

Then(/^Record should be available with recent updates$/, async () => {
    await paytypes.clickOnGLDistributionTab();
    await paytypes.verifyGrossPayFieldvalue(global.grosspayValue);
});

Then(/^Created work log should be displayed$/, async () => {
    await paytypes.verifyAuditTrailCreatedLog("1");
});

Then(
    /^Updated work log should be displayed as No audit log to display$/,
    async () => {
        await paytypes.verifyNoAuditlogtoDisplay();
    }
);

Then(
    /^Deleted work log should be displayed as No audit log to display$/,
    async () => {
        await paytypes.verifyNoAuditlogtoDisplay();
    }
);

Then(
    /^Updated work log should be displayed with recent update's log$/,
    async () => {
        await paytypes.verifyAuditTrailUpdatedLog("1");
    }
);

Then(/^Updated and created work logs should be displayed$/, async () => {
    await paytypes.verifyAuditTrailCreatedLog("1");
    await paytypes.verifyAuditTrailUpdatedLog("1");
});

Then(/^Today audit logs should be displayed$/, async () => {
    await paytypes.verifyAuditTrailCreatedLog("1");
    await paytypes.verifyAuditTrailUpdatedLog("1");
});

Then(/^Yesterday audit logs should be displayed$/, async () => {
    await paytypes.verifyNoAuditlogtoDisplay();
});

Then(/^Last 7 days audit logs should be displayed$/, async () => {
    await paytypes.verifyAuditTrailCreatedLog("1");
    await paytypes.verifyAuditTrailUpdatedLog("1");
});

Then(/^This Month audit logs should be displayed$/, async () => {
    await paytypes.verifyAuditTrailCreatedLog("1");
    await paytypes.verifyAuditTrailUpdatedLog("1");
});

Then(/^Clone confirmation dialog should be displayed$/, async () => {
    await paytypes.wait(3000);
    await paytypes.verifyCloneConfirmationDialog(
        "Clone Pay Type",
        "Are you sure you want to clone"
    );
});

Then(
    /^Confirmation message dialog displayed with Cancel and Clone button$/,
    async () => {
        await paytypes.verifyConfirmationDialogCancelButton("Visible", "Cancel");
        await paytypes.verifyConfirmationDialogCloneButton("Visible", "Clone");
    }
);

Then(
    /^Confirmation dialog should be closed and Edit paytypes window should be displayed$/,
    async () => {
        await paytypes.verifyCloneDialogClosed();
    }
);

Then(
    /^Label with prefix Clone should be displayed in edit paytype header$/,
    async () => {
        await paytypes.verifyClonedLable();
    }
);

Then(
    /^Add button should be displayed as "([^"]*)" with Text "([^"]*)"$/,
    async (state, buttonText) => {
        await paytypes.verifyCloneAddButton(buttonText, state);
    }
);

Then(/^I should be able to see message for cloning "([^"]*)"$/, async (msg) => {
    await paytypes.verifyPayTypeUpdated(msg);
});

Then(/^Cloned record should be displayed with header$/, async () => {
    await paytypes.verifyClonedrecordHeader();
});

Then(/^Cloned record should be displayed with updated data$/, async () => {
    await paytypes.verifyUpdatedClonedData();
});

Then(/^Error message should be displayed for unique label name$/, async () => {
    await paytypes.verifyPayTypeUpdated(" Label must be unique. ");
});

Then(/^Asset repository page header should be displayed$/, async () => {
    await assetRepository.verifyPageHeader("Asset Repository - Asset Types");
});

Then(
    /^Service location page and it's breadcrump should be displayed$/,
    async () => {
        await assetRepository.verifyPageHeader("Asset Repository - Service Locations");
        await assetRepository.verifyBreadCrump(
            "Operations / Asset Repository /  Service Locations"
        );
    }
);

Then(
    /^New Service location page and breadcrump should be displayed$/,
    async () => {
        await assetRepository.verifyPageHeaderOfNewSL("Create Service Location");
        await assetRepository.verifyBreadCrump(
            "BackOperations / Asset Repository /  Service Locations"
        );
    }
);

Then(/^All the required field should have required symbol$/, async () => {
    await assetRepository.verifyNSLocationFormRequiredField();
});

Then(
    /^New Service location should be added for "([^"]*)"$/,
    async (occupancy) => {
        await assetRepository.verifyNewLocationAddedmsg(
            " Service Location added successfully. "
        );
        //await assetRepository.verifyServiceAdded(occupancy);
    }
);

Then(
    /^Newly added loaction header should match with added service location for property Owner$/,
    async () => {
        await assetRepository.verifyNewaddedLocationHeader("propertyOwner");
    }
);

Then(
    /^Newly added loaction header should match with added service location for tenant$/,
    async () => {
        await assetRepository.verifyNewaddedLocationHeader("tenant");
    }
);

Then(
    /^Newly added service for property Owner should be displayed in master list$/,
    async () => {
        await assetRepository.verifyAddedserviceRecord("propertyOwner");
    }
);

Then(
    /^Newly added service for tenant should be displayed in master list$/,
    async () => {
        await assetRepository.verifyAddedserviceRecord("tenant");
    }
);

Then(/^New Account page should be displayed$/, async () => {
    await addAccountPage.verifyPageHeader("New Account");
});

Then(/^New Account bread crump should be displayed$/, async () => {
    await addAccountPage.verifyBreadCrumpforNewAccount(
        "BackUtility Billing  / UB Accounts /  UB Accounts  /  New Account"
    );
});

Then(
    /^Basic Information button should be displayed in selected state$/,
    async () => {
        await addAccountPage.verifyBasicInformationButton(
            "Basic Information",
            "Selected"
        );
    }
);

Then(/^Service Deposits button should be dispalyed as disabled$/, async () => {
    await addAccountPage.verifyServiceDepositsButton(
        "Services and Deposits",
        "Disabled"
    );
});

Then(
    /^Service Location required field should be displayed with placeholder$/,
    async () => {
        await addAccountPage.verifyServiceLocationField(
            " Service Location*",
            "Start typing the Service Location"
        );
    }
);

Then(
    /^Account Holder required field should be displayed with placeholder$/,
    async () => {
        await addAccountPage.verifyAccountHolderField(
            " Account Holder*",
            "Start typing the public user name"
        );
    }
);

Then(
    /^Relation required field should be displayed with placeholder$/,
    async () => {
        await addAccountPage.verifyRelationField(" Relation*", "Select Relation");
    }
);

Then(/^Move-in-Date required field should be displayed$/, async () => {
    await addAccountPage.verifyMoveInDateField(" Move-in Date*");
});

Then(
    /^Account Type required field should be displayed with placeholder$/,
    async () => {
        await addAccountPage.verifyAccountTypeField(
            " Account Type*",
            "Select Account Type"
        );
    }
);

Then(/^Select Account field should be displayed as disabled$/, async () => {
    await addAccountPage.verifySelectAccountField(" Select Account ", "false");
});

Then(/^Enter bill payer field should be displayed as disabled$/, async () => {
    await addAccountPage.verifyEnterBillPayerDisabledField(
        " Enter Bill Payer ",
        "false"
    );
});

Then(
    /^Enter bill payer required field should be displayed as Enabled$/,
    async () => {
        await addAccountPage.verifyEnterBillPayerEnabledField(
            "Selected"
        );
    }
);

Then(/^New User link for Account holder should be displayed$/, async () => {
    await addAccountPage.verifyAccountHolderNewUserLink();
});

Then(/^New User link for bill payer should be displayed$/, async () => {
    await addAccountPage.verifyEnterBillPayerNewUserLink();
});

Then(/^Next button should be displayed as "([^"]*)"$/, async (buttonState) => {
    await addAccountPage.verifyNextButton(buttonState);
});

Then(/^Services Page should be displayed$/, async () => {
    await addAccountPage.verifyServicesPageHeader();
});

Then(/^Services and Deposits button should be selected$/, async () => {
    await addAccountPage.verifyServiceDepositsButton(
        "Services and Deposits",
        "Selected"
    );
});

Then(
    /^Basic Information button should be displayed as not selected$/,
    async () => {
        await addAccountPage.verifyBasicInformationButton(
            "Basic Information",
            "Not Selected"
        );
    }
);

Then(/^Save as draft button should be "([^"]*)"$/, async (buttonState) => {
    await addAccountPage.verifySaveasDraftButton(buttonState);
    //await addAccountPage.deleteRecoerdedFile()
});

Then(/^Move-in Details are drafted message should be displayed$/, async () => {
    await addAccountPage.verifyDraftedMessage(
        "Move-in service request created with ServiceRequestId -"
    );
});

Then(/^Add services window should be displayed$/, async () => {
    await addAccountPage.verifyAddServicesHeader("Add Service");
});

Then(
    /^All the fields should be displayed with respected place holder$/,
    async () => {
        await addAccountPage.verifyAddServiceslabelsPlaceholder();
    }
);

Then(/^Cancel button should be displayed "([^"]*)"$/, async (buttonState) => {
    await addAccountPage.verifyAddServiceCancelButton(buttonState);
});

Then(/^Save button should be displayed as "([^"]*)"$/, async (buttonState) => {
    await addAccountPage.verifyAddServiceSaveButton(buttonState);
});

Then(
    /^Recently added service should be displayed in services table$/,
    async () => {
        await addAccountPage.verifyRecentlyAddedService("WATER");
    }
);

Then(
    /^Services table should be displayed with all respected columns$/,
    async () => {
        await addAccountPage.verifyServicepageTableLabels();
    }
);

Then(/^Add button should be displayed as "([^"]*)"$/, async (buttonState) => {
    await addAccountPage.verifyServicePageAddButton(buttonState);
});

Then(/^Back button should be displayed as "([^"]*)"$/, async (buttonState) => {
    await addAccountPage.verifyServicePageBackButton(buttonState);
});

Then(
    /^Save as draft button should be displayed as "([^"]*)"$/,
    async (buttonState) => {
        await addAccountPage.verifyServicePageSaveasDraft(buttonState);
    }
);

Then(
    /^Initiate Move-in button should be displayed as "([^"]*)"$/,
    async (buttonState) => {
        await addAccountPage.verifyInitiateMoveInButton(buttonState);
    }
);

Then(/^Basic Information page should be displayed$/, async () => {
    await addAccountPage.verifyBasicInformationButton(
        "Basic Information",
        "Selected"
    );
});

Then(/^Only Water Service should not be displayed$/, async () => {
    await addAccountPage.verifyWaterServiceDeleted();
});

Then(
    /^Initiate Move-in button should be displayed "([^"]*)"$/,
    async (buttonState) => {
        await addAccountPage.verifyInitiateMoveInButton(buttonState);
    }
);

Then(
    /^Move-in request added successfully message should be displayed$/,
    async () => {
        await addAccountPage.verifyInitiateMoveInMessage();
    }
);

Then(/^Service added message should be displayed$/, async () => {
    await commonUtils.toasterMessageContainsValidation("service added successfully.")
   // await addAccountPage.verifyServiceAddedMessage();
    // await addAccountPage.sleep(10000);
});

Then(/^Account details page should be displayed$/, async () => {
    await addAccountPage.verifyAccountDetailsHeader();
});

Then(/^Updated water service should be displayed$/, async () => {
    await addAccountPage.verifyRecentlyAddedService("WATER");
});

Then(/^Drafted alert message should be displayed$/, async () => {
    await addAccountPage.verifyServiceDraftedMessage();
});

Then(
    /^Account details header should be displayed with the details as: UB Account-Account ID-Service Location$/,
    async () => {
        await accountDetails.verifyAccountDetailsHeader("accountPageDetailsHeader");
    }
);

Then(
    /^Account summary section should be displayed as "([^"]*)"$/,
    async (header) => {
        await accountDetails.verifyAccountSummarySectionTitle(header);
    }
);

Then(
    /^Account details summary first section fields "([^"]*)", "([^"]*)", "([^"]*)", "([^"]*)","([^"]*)", "([^"]*)", "([^"]*)", "([^"]*)", "([^"]*)" are displayed$/,
    async (field1, field2, field3, field4, field5, field6, field7, field8, field9) => {
        await accountDetails.verifyAllFieldsforAccountSummaryFirstSection(
            field1,
            field2,
            field3,
            field4,
            field5,
            field6,
            field7,
            field8,
            field9
        );
    }
);

Then(
    /^Account details summary second section fields "([^"]*)", "([^"]*)", are displayed$/,
    async (field1, field2) => {
        await accountDetails.verifyAllFieldsforAccountSummarySecondSection(
            field1,
            field2
        );
    }
);

Then(
    /^Account details summary third section fields "([^"]*)", are displayed$/,
    async (field1) => {
        await accountDetails.verifyAllFieldsforAccountSummaryThirdSection(field1);
    }
);

Then(
    /^Account details summary forth section fields "([^"]*)", "([^"]*)", "([^"]*)", "([^"]*)","([^"]*)","([^"]*)" are displayed$/,
    async (field1, field2, field3, field4, field5, field6) => {
        await accountDetails.verifyAllFieldsforAccountSummaryForthSection(
            field1,
            field2,
            field3,
            field4,
            field5,
            field6
        );
    }
);

Then(
    /^account details page left side should have sections as "([^"]*)","([^"]*)", "([^"]*)","([^"]*)","([^"]*)","([^"]*)","([^"]*)","([^"]*)"$/,
    async (
        section1,
        section2,
        section3,
        section4,
        section5,
        section6,
        section7,
        section8
    ) => {
        await accountDetails.verifyAccountDetailsPageLeftsideSections(
            section1,
            section2,
            section3,
            section4,
            section5,
            section6,
            section7,
            section8
        );
    }
);

Then(
    /^account details page right side should have sections as "([^"]*)","([^"]*)","([^"]*)"$/,
    async (section1, section2, section3) => {
        await accountDetails.verifyAccountDetailsPageRightsideSections(
            section1,
            section2,
            section3
        );
    }
);

Then(/^Edit page should be displayed$/, async () => {
    await accountDetails.verifyEditAccountDetailsHeader("Edit Account Details");
});

Then(
    /^All the added details should be matched with account summary details$/,
    async () => {
        await accountDetails.verifyAccountSummaryDetails(
            "AccountDetailsValidations"
        );
    }
);

Then(/^User details page should have Services section$/, async () => {
    await accountServices.verifyServiceSectionTitle();
});

Then(/^Services table should have columns as "([^"]*)", "([^"]*)", "([^"]*)", "([^"]*)", "([^"]*)", "([^"]*)", "([^"]*)", "([^"]*)"$/, async (col1, col2, col3, col4, col5, col6, col7, col8) => {
        await accountServices.verifyServicesSectionColumns(
            col1,
            col2,
            col3,
            col4,
            col5,
            col6,
            col7,
            col8
        );
    }
);

Then(
    /^All the added details should be matched with account service details$/,
    async () => {
        await accountServices.verifyRecordedServiceDetails(
            "ServiceDetailsValidations"
        );
    }
);

Then(/^Service Request link should be displayed$/, async () => {
    await accountServices.verifyServiceRequestLink();
});

Then(/^Create request page should be displayed$/, async () => {
    await accountServices.verifyCreateRequestPageHeader();
});

Then(/^Meter Changeouts link should be displayed$/, async () => {
    await accountServices.verifyMeterChangeOutsLink();
});

Then(
    /^Meter Changeouts service request page should be displayed$/,
    async () => {
        await accountServices.verifyMeterChangeOutsPageHeader();
    }
);

Then(/^Service Information page should be displayed$/, async () => {
    await accountServices.verifyServiceInformationPageHeader();
});

Then(/^Service details section should be displayed$/, async () => {
    await accountServices.verifyServiceDetailsSectionTitle();
});

Then(/^Consumption section should be displayed$/, async () => {
    await accountServices.verifyConsumptionSectionTitle();
});

Then(
    /^Service Details section should have fields as "([^"]*)","([^"]*)","([^"]*)","([^"]*)","([^"]*)","([^"]*)"$/,
    async (field1, field2, field3, field4, field5, field6) => {
        await accountServices.verifyServiceDetailsFields(
            field1,
            field2,
            field3,
            field4,
            field5,
            field6
        );
    }
);

Then(
    /^Consumption section MonthlyView button should be in "([^"]*)" state$/,
    async (buttonState) => {
        await accountServices.consumptionSectionMonthlyButton(buttonState);
    }
);

Then(
    /^Consumption section YearlyView button should be in "([^"]*)" state$/,
    async (buttonState) => {
        await accountServices.consumptionSectionYearlyButton(buttonState);
    }
);

Then(/^Consumption graph x and y axis should be displayed$/, async () => {
    await accountServices.verifyConsumptionGraphAxis(
        "Consumption details by month",
        "Units of consumption"
    );
});

Then(/^INVOICES link should be displayed$/, async () => {
    await accountServices.verifyInvoicesLink();
});

Then(/^Selected consumption details section should be displayed$/, async () => {
    await accountServices.verifySelectedConsumptionSection();
});

Then(/^Selected consumption details section has VIEW INVOICE link$/, async () => {
    await accountServices.verifyViewAllLink();
});

Then(
    /^Service Information details should match with the provided details$/,
    async () => {
        await accountServices.verifyServiceInformationDetails(
            "ServiceInformationValidations"
        );
    }
);

Then(
    /^No service to display text should not be displayed in Services Section$/,
    async () => {
        await accountServices.verifyServicesNoRecord();
    }
);

Then(
    /^Atleast one service should be associated with the account$/,
    async () => {
        await accountServices.verifyMinServiceforAccount();
    }
);

Then(
    /^UB Accounts page header should be displayed as "([^"]*)"$/,
    async (headerText) => {
        await accounts.verifyAccountPageHeader(headerText);
    }
);

Then(
    /^The record for the given account number should be displayed$/,
    async () => {
        await accounts.verifySearchedAccountNumberForMasterList("accountsSearch");
    }
);

Then(
    /^All the record for the given account holder should be displayed$/,
    async () => {
        await accounts.verifySearchwithAccountHolderFromMasterList(
            "accountsSearch"
        );
    }
);

Then(
    /^All the record for the given service Location should be displayed$/,
    async () => {
        await accounts.verifySearchwithServiceLocationFromMasterList(
            "accountsSearch"
        );
    }
);

Then(
    /^All the record for the given Bill payer should be displayed$/,
    async () => {
        await accounts.verifySearchwithBillPayerFromMasterList("accountsSearch");
    }
);

Then(
    /^All the record for the given Bill payer Type should be displayed$/,
    async () => {
        await accounts.verifySearchwithBillPayerTypeFromMasterList(
            "accountsStatusSearch"
        );
    }
);

Then(
    /^All the record for the given account status should be displayed$/,
    async () => {
        await accounts.verifySearchwithAccountStatusFromMasterList(
            "accountsStatusSearch"
        );
    }
);

Then(
    /^All the record for the given Move In Date should be displayed$/,
    async () => {
        await accounts.verifySearchwithMoveInDateFromMasterList(
            "accountsStatusSearch"
        );
    }
);

Then(
    /^All the record for the given Move out date should be displayed$/,
    async () => {
        await accounts.verifySearchwithMoveOutDateFromMasterList(
            "accountsStatusSearch"
        );
    }
);

Then(
    /^Payer type, status, services, considerations, payements and types filter options should be displayed$/,
    async () => {
        await accounts.verifyFiltersVisibilityOfMasterPage();
    }
);

Then(/^Payer type Tenant records should be displayed$/, async () => {
    await accounts.verifyFilterwithBillPayerTypeFromMasterList("Tenant");
});


Then(/^Accounts with Balance "([^"]*)" "([^"]*)" should be displayed$/, async (condition,expecteditem) => {
	await accounts.verifyFilterwithBalanceFromMasterList(condition,expecteditem);
});


Then(/^Active records should be displayed$/, async () => {
    await accounts.verifyFilterwithStatusFromMasterList("Active");
});

Then(/^Water service records should be displayed$/, async () => {
    await accountServices.verifyServiceInList("WATER Primary-Water");
});

Then(
    /^Energy Assistance considerations records should be displayed$/,
    async () => {
        await accounts.verifyEnergyAssistance("Enabled");
    }
);

Then(
    /^Both Electronics and Mail payments records should be displayed$/,
    async () => {
        await accounts.verifyPaymentMethodValue("Both(Electronic and Mail)");
    }
);

Then(/^Residential account type records should be displayed$/, async () => {
    await accounts.verifyAccountTypeValue("Residential");
});

Then(
    /^Filter selected area should be displayed as "([^"]*)"$/,
    async (filterSelected) => {
        await accounts.verifyFilterSelectedArea(filterSelected);
    }
);

Then(/^Filter selected area has values as "([^"]*)" , "([^"]*)" and "([^"]*)"$/,
    async (filteredValue1, filteredValue2,filteredValue3) => {
        await accounts.verifyFilterSelectedAreaValue(
            filteredValue1,
            filteredValue2,
            filteredValue3
        );
    }
);

Then(
    /^Account details page will be displayed with selected account number$/,
    async () => {
        await accounts.verifyAccountSummaryHeader("Account Details");
    }
);

Then(/^Account details page will be displayed$/, async () => {
    await accounts.verifyAccountSummaryHeader("Account Summary");
});

Then(/^Add Employee button is displayed$/, async () => {
    await addEmployee.verifyAddEmployeeButton();
});

Then(/^Add Employee window should be displayed$/, async () => {
    await addEmployee.verifyAddEmployeeWindow("Add Employee");
});

Then(
    /^Employee ID, First Name, Middle Name and Last Name fields should be displayed$/,
    async () => {
        await addEmployee.verifyAddEmployeeFields();
    }
);

Then(
    /^Employee ID is required error message should be displayed$/,
    async () => {
        await addEmployee.verifyEmployeeIDErrorMessage();
    }
);

Then(/^First Name is required error message should be displayed$/, async () => {
    await addEmployee.verifyfirstNameErrorMessage();
});

Then(/^Last Name is required error message should be displayed$/, async () => {
    await addEmployee.verifylastNameErrorMessage();
});

Then(
    /^First Name fields are Alphanumerical and allows all special characters$/,
    async () => {
        await addEmployee.enterFirstName("ABC@16$23");
    }
);

Then(
    /^Last Name fields are Alphanumerical and allows all special characters$/,
    async () => {
        await addEmployee.enterLastName("last@1836_$");
    }
);

Then(
    /^Middle Name fields are Alphanumerical and allows all special characters$/,
    async () => {
        await addEmployee.enterMiddleName("middle@18466_%");
    }
);

Then(/^Employee Id should not accept the special characters$/, async () => {
    await addEmployee.enterEmployeeID("@#$%&");
    await addEmployee.verifyEmployeeIDNotEntered();
});


Then(/^Added employee record should be displayed in master record list for "([^"]*)"$/, async (filename) => {
    await addEmployee.validateRecentlyAddedEmployee(filename)
});



Then(/^Verify Add Tax Table overlay should be displayed$/, async () => {
    await addTaxTable.verifyAddtaxTableOverlayHeader();
});

Then(
    /^Verify I should be able to validate all the labels on Tax Table overlay$/,
    async () => {
        await addTaxTable.verifyAddtaxTableOverlayLables();
    }
);

Then(
    /^Verify All the tax methods toggle state should be "([^"]*)" by default$/,
    async (state) => {
        await addTaxTable.verifyDefaultTaxMethodToggleState();
    }
);

Then(
    /^Verify I should be able to disable all the tax methods toggle$/,
    async () => {
        await addTaxTable.switchTaxMethodToggleState();
    }
);

Then(
    /^Verify all the tax methods toggle should be "([^"]*)"$/,
    async (state) => {
        await addTaxTable.verifyDefaultTaxMethodToggleState();
    }
);

Then(
    /^verify Add Tax Table success toaster message should be "([^"]*)"$/,
    async (smsg) => {
        await addTaxTable.verifyAddTaxTableMessage(smsg);
    }
);

Then(
    /^verify Add Tax Table failed toaster message should be "([^"]*)"$/,
    async (msg) => {
        await addTaxTable.verifyAddTaxTableDuplicateErrorMessage(msg);
    }
);

Then(/^I should be able to see Tax Table page$/, async () => {
    await addTaxTable.verifyTaxTableTitle();
});

Then(/^I should not be able to add Tax Table successfully$/, async () => {
    await addTaxTable.verifyAddButtonIsDisabled();
});

Then(
    /^verify sign for Tax Rate Input Box for Amount is "([^"]*)"$/,
    async (sign) => {
        await addTaxTable.verifySignForTaxRateInputforAmount(sign);
    }
);

Then(
    /^verify Tax Table name input box validation message "([^"]*)"$/,
    async (msg) => {
        await addTaxTable.verifyMandatoryFieldsValidationsMessagesForTaxNameInput(
            msg
        );
    }
);

Then(
    /^verify enter Tax Rate State Tax Input Box validation message "([^"]*)"$/,
    async (msg) => {
        await addTaxTable.verifyMandatoryFieldsValidationsMessagesForEnterTaxRateStateTaxInputBox(
            msg
        );
    }
);

Then(
    /^verify enter Tax Rate County Tax Input Box validation message "([^"]*)"$/,
    async (msg) => {
        await addTaxTable.verifyMandatoryFieldsValidationsMessagesForEnterTaxRateCountyTaxInputBox(
            msg
        );
    }
);

Then(
    /^verify enter Tax Rate City Tax Input Box validation message "([^"]*)"$/,
    async (msg) => {
        await addTaxTable.verifyMandatoryFieldsValidationsMessagesForEnterTaxRateCityTaxInputBox(
            msg
        );
    }
);

Then(/^Verify Add button should be "([^"]*)"$/, async (state) => {
    await addTaxTable.verifyAddbuttonIsDisabled(state);
});

Then(
    /^verify sign for Tax Rate Input Box for Consumption is "([^"]*)"$/,
    async (value) => {
        await addTaxTable.verifySignForTaxRateInputforConsumption(value);
    }
);

Then(
    /^verify sign for Tax Rate Input Box for Percentage is "([^"]*)"$/,
    async (value) => {
        await addTaxTable.verifySignForTaxRateInputforPercentage(value);
    }
);

Then(
    /^Verify Fuel Adujustment Title "([^"]*)" should be displayed$/,
    async (value) => {
        await setupFuelAdjustment.verifyFuelAdujutmentTabTitle(value);
    }
);

Then(
    /^Verify Select Eligible Services dropdown placeholder should be "([^"]*)"$/,
    async (value) => {
        await setupFuelAdjustment.verifyplaceholderEligibleServicesDropdown(value);
    }
);

Then(
    /^Verify Calculation Base dropdown placeholder should be "([^"]*)"$/,
    async (value) => {
        await setupFuelAdjustment.verifyplaceholderCalculationBaseDropdown(value);
    }
);

Then(
    /^Verify service "([^"]*)" is displayed in Selected Services section$/,
    async (value) => {
        await setupFuelAdjustment.verifySelectedServicesSectionDisplaySelectedServices(
            value
        );
    }
);

Then(/^Verify "([^"]*)" is selected in Calculation Base$/, async (value) => {
    await setupFuelAdjustment.verifycalculationBaseIsSelected(value);
});

Then(/^Verify Save button should get Enabled$/, async () => {
    await setupFuelAdjustment.verifySaveButtonIsEnabled();
});

Then(
    /^Verify A successful message "([^"]*)" should be displayed$/,
    async (msg) => {
        await setupFuelAdjustment.verifyFueladjustmentSuccessMessage(msg);
    }
);

Then(
    /^Verify Select Eligible Services dropdown label should be "([^"]*)"$/,
    async (label) => {
        await setupFuelAdjustment.verifyLabelEligibleServices(label);
    }
);

Then(
    /^Verify Calculation Base dropdown label should be "([^"]*)"$/,
    async (label) => {
        await setupFuelAdjustment.verifyLabelCalculationBase(label);
    }
);

Then(/^Verify Reset button should get Enabled$/, async () => {
    await setupFuelAdjustment.verifyResetButtonIsEnabled();
});

Then(/^Save button should get disabled$/, async () => {
    await setupFuelAdjustment.verifySaveButtonIsDisabled();
});

Then(/^Reset button should get disabled$/, async () => {
    await setupFuelAdjustment.verifyResetButtonIsDisabled();
});

Then(/^verify Add Leave Type side navigation appears$/, async function () {
    await LeavesTypes.validateAddLeaveType();
});
Then(/^I clear the data validate error messages$/, async function () {
    await LeavesTypes.errorValidationFMLA();
});

Then(/^Click on Leave types Add button$/, async function () {
    await LeavesTypes.clickAddonButton();
});
Then(/^I enter data for required data and FMLA toogle on$/, async function () {
    await LeavesTypes.leaveTypeFMLAFields();
});
Then(
    /^I enter data for required data and Compensation toogle on$/,
    async function () {
        await LeavesTypes.leaveTypeCompensationFields();
    }
);
/*
Then(/^I enter data for required data and (.*)$/, async (msg) => {
    await LeavesTypes.leaveTypeFields(msg, "UnPaid");
})*/
Then(/^verify toaster message "([^"]*)"$/, async (msg) => {
    await LeavesTypes.verifyAddedLeaveType(msg);
});

Then(/^I get the name of exiting record$/, async function () {
    await LeavesTypes.getLabelRecordOne(1);
});
Then(
    /^I will get the value of one of the existing records$/,
    async function () {
        await LeavesTypes.getLabelRecord(4);
    }
);

Then(
    /^I enter data for required data with existing Label name (.*)$/,
    async (msg) => {
        await LeavesTypes.leaveTypeExistingLabel(msg);
    }
);
Then(
    /^I enter data for required data with existing Label value that we get (.*)$/,
    async (msg) => {
        await LeavesTypes.leaveTypeExistingLabelEdit();
    }
);
Then(/^validate Compensation Maximum time fields$/, async function () {
    await LeavesTypes.validateCompensationFields();
});
Then(/^validate either compensation or FMLA toggle is ON$/, async function () {
    await LeavesTypes.validateCompensationFMLAToogle();
});

Then(
    /^validate edit leave type fields then click cancel and naviagte back to leave type page$/,
    async function () {
        await LeavesTypes.validateEditLeaveTypePage();
    }
);
Then(
    /^validate Audit Trail tab visibility and its fields on added Leave types$/,
    async function () {
        await LeavesTypes.validateAuditFields();
    }
);
Then(
    /^Verify changes has to be reflected in an existing record window should be closed$/,
    async function () {
        await LeavesTypes.validateChangesLeaveType();
    }
);

Then(
    /^Validate existing record can be edited and can be saved without any restrictions$/,
    async function () {
        const random = await pagebase.randomString(4);
        genValue1 = "Automation" + random;
        await LeavesTypes.LeaveTypeFieldsUpdate(
            genValue1,
            "Yes",
            "Update",
            "Leave type updated successfully."
        );
    }
);

Then(
    /^Verify provided all the mandatory fields have valid values$/,
    async function () {
        await LeavesTypes.Verifymanditoryfieldsvalue();
    }
);
Then(/^I navigate to Audit Trail tab on added Leave types$/, async function () {
    await LeavesTypes.naviagteAuditTrail();
});
Then(/^Validate the Audit Trail based on Activity Type (.*)$/, async (msg) => {
    await LeavesTypes.validateAuditTrailTab(msg);
});
Then(
    /^Validate the Audit Trail based on Activity Types (.*) and (.*)$/,
    async (msg1, msg2) => {
        await LeavesTypes.validateAuditTrailTabMultiple(msg1, msg2);
    }
);
Then(
    /^validate filters data based on Date Range when Today date range is selected$/,
    async function () {
        await LeavesTypes.selectDaterange();
    }
);
Then(
    /^I click on Clone button and verify the popup cancel$/,
    async function () {
        await LeavesTypes.navigateClonePageAndCancel(await LeavesTypes.cloneLocator());
    }
);
Then(
    /^I click on Clone button and verify the popup clone and (.*)$/,
    async (msg) => {
        await LeavesTypes.navigateClonePageAndClone(await addEmployee.makeString(msg), await LeavesTypes.cloneLocator());
    }
);
Then(
    /^verify changes has to be reflected in an existing record$/,
    async function () {
        await LeavesTypes.validateCloneChangesLeaveType();
    }
);
Then(/^I click and validate toaster message$/, async function () {
    const random = await pagebase.randomString(4);
    let genValue1 = "Automation" + random;
    await LeavesTypes.LeaveTypeFieldsUpdate(genValue1, "No", "Add", "Clone");
});
Then(/^I click and validate duplicate toaster message$/, async function () {
    await LeavesTypes.LeaveTypeFieldsUpdate(
        "",
        "Duplicate",
        "Add",
        "Label should be unique."
    );
});

Then(/^When I click on close button$/, () => {
    return true;
});

Then(/^verify the attributes of Leave Type Page$/, async function () {
    await LeaveType.verifyAddLeaveTypePageAttributesVisibility();
});
Then(/^I enter the label value for Leave Type$/, async function () {
    //await LeaveType.NavigateToLeaveType();
    await LeaveType.AddlabelValue("Automation");
});

Then(
    /^Verify if Label field has asterick mark for Leave Type Page$/,
    async function () {
        await LeaveType.verifyAsterickLabel();
    }
);
Then(
    /^Verify if Type field has asterick mark for Leave Type Page$/,
    async function () {
        await LeaveType.verifyAsterickType();
    }
);
Then(
    /^Verify if Period field has asterick mark for Carry over$/,
    async function () {
        await LeaveType.verifyAsterickPeriod();
    }
);
Then(
    /^Verify if Earn Per Period field has asterick mark for carry over$/,
    async function () {
        await LeaveType.verifyAsterickEarnPerPeriod();
    }
);
Then(
    /^Verify if under carry over Type field has asterick mark$/,
    async function () {
        await LeaveType.verifyAsterickTypeCarryOver();
    }
);
Then(
    /^Verify if under carry over Basis dropdown has asterick mark$/,
    async function () {
        await LeaveType.verifyAsterickBasisCarryOver();
    }
);
Then(
    /^Verify if Maximum Time field has asterick mark for Leave Type Page$/,
    async function () {
        await LeaveType.verifyAsterickMaximumTime();
    }
);

Then(
    /^Add more than 100 characters in the label field of Leave Type$/,
    async function () {
        let labeldata = await pagebase.randomString(99);
        await LeaveType.AddlabelValue(labeldata + "a");
    }
);
Then(
    /^Verify if the lable textbox is able to take more than 100 characters on Leave Type page$/,
    async function () {
        await LeaveType.verifyCountinLabel();
    }
);
Then(/^verify the attributes of Type dropdown is visible$/, async function () {
    await LeaveType.verifyTYPESvalues("Paid");
    await LeaveType.verifyTYPESvalues("UnPaid");
});

Then(/^Add attributes values under Type dropdown$/, async function () {
    //await LeaveType.AddlabelValue("Automation_003");
    await LeaveType.selectTypeDropdown("Paid");
    //  await LeaveType.selectTypeDropdown("UnPaid")
});

Then(
    /^Add attributes values under Type dropdown for leave Type $/,
    async function () {
        //await LeaveType.AddlabelValue("Automation_003");
        //await LeaveType.selectTypeDropdown("Paid");
        await LeaveType.selectTypeDropdown("UnPaid");
    }
);

Then(/^verify Overtime Toggle should be turned on$/, async function () {
    await LeaveType.VerifyToggleOvertimeStatus();
});

Then(/^verify Sick Type Toggle should be turned on$/, async function () {
    await LeaveType.VerifyToggleSickTypeStatus();
});

Then(
    /^verify the attributes of Period dropdown are visible$/,
    async function () {
        await LeaveType.verifyPeriodValues("Each Pay Period");
        await LeaveType.verifyPeriodValues("Each Month");
        await LeaveType.verifyPeriodValues("Each Year");
        await LeaveType.verifyPeriodValues("Regular Hours");
        await LeaveType.verifyPeriodValues("Total Hours");
    }
);

Then(
    /^verify the attributes of Type Dropdown are visible from carry over$/,
    async function () {
        await LeaveType.VerifyTypevaluesofCarryOver("Amount");
        await LeaveType.VerifyTypevaluesofCarryOver("Percentage");
        await LeaveType.VerifyTypevaluesofCarryOver("None");
    }
);
Then(
    /^verify the attributes of basis dropdown are visible$/,
    async function () {
        await LeaveType.VerifyBasisvaluesofCarryOver("Anniversary");
        await LeaveType.VerifyBasisvaluesofCarryOver("Yearly");
        await LeaveType.VerifyBasisvaluesofCarryOver("Date");
    }
);

Then(/^Select Type and Basis dropdown atrributes$/, async function () {
    await LeaveType.selectCarryOverTypeDropdown("None");
    await LeaveType.SelectDropdownforBasisCarryOver("Anniversary");
});
Then(/^I select Basis dropdown attribute as Anniversary$/, async function () {
    await LeaveType.SelectDropdownforBasisCarryOver("Anniversary");
});
Then(
    /^I Select Type and Basis dropdown atrributes as Amount and Yearly$/,
    async function () {
        await LeaveType.selectCarryOverTypeDropdown("Amount");
        await LeaveType.SelectDropdownforBasisCarryOver("Yearly");
    }
);

Then(
    /^verify Amount Text boxes are visible with HH and MM$/,
    async function () {
        await LeaveType.verifyCarryOvertextBoxofAmount();
    }
);

Then(/^Add the attributes of Period dropdown$/, async function () {
    await LeaveType.selectPeriodDropdown("Each Pay Period");
    // await LeaveType.selectPeriodDropdown("Each Month");
    // await LeaveType.selectPeriodDropdown("Each Year");
    // await LeaveType.selectPeriodDropdown("Regular Hours");
    // await LeaveType.selectPeriodDropdown("Total Hours");
});

Then(/^verify Each per period field is visible$/, async function () {
    await LeaveType.verifyHHandMMFieldofEarnMethod();
});
Then(/^verify Earn per period field should be visible$/, async function () {
    await LeaveType.verifyEarn_per_periodVisible();
});

Then(/^verify the Availability Dropdown is visible$/, async function () {
    await LeaveType.verifyAvailabilityDropdownVisible();
});

Then(/^Add Attribute values under Availability$/, async function () {
    await LeaveType.selectAvailabilityDropdown("Calendar Year");
    // await LeaveType.selectAvailabilityDropdown("Hired Anniversary");
});

Then(/^verify Earn per Hour field should be visible$/, async function () {
    await LeaveType.verifyEarnPerHourfiledVisible();
});

Then(
    /^verify the Earn per Period Text boxes should take only integer values in the form of HH and MM$/,
    async function () {
        await LeaveType.verifyHHandMMFieldofEarnMethod();
    }
);

Then(/^add the attributes to text boxes of Amount$/, async function () {
    await LeaveType.addvaluestocarryOverTextBoxAmount();
});

Then(/^Percentage Text box is Visible$/, async function () {
    await LeaveType.verifyCarryOvertextBoxofPercentage();
});

Then(/^Add the attribute to percentage text box$/, async function () {
    await LeaveType.EntervalueToPercentageFiled("20");
});

Then(/^Amount and Percentage Text boxe is optional$/, async function () {
    await LeaveType.VerifyBasisvaluesofCarryOver("Anniversary");
});

Then(/^Month Dropdown should be visible$/, async function () {
    await LeaveType.VerifyvisibilityofBasisdropDownofcarryOver();
});

Then(/^select the attribute value for day$/, async function () {
    await LeaveType.selectArrtibuteforDayCarryOver(16);
});

Then(/^Add MM and HH time in Maximum Time text boxes$/, async function () {
    await LeaveType.enterValuestoMMHHofMaximumTimefield();
});

Then(/^the Add Leave Type overlay has to be displayed$/, async function () {
    await LeaveType.verifytbl_addleaveTyperow();
});

Then(/^Verify Update button is in active state$/, async function () {
    await LeaveType.Verifyupdatebtnstateforactive();
});
Then(
    /^verify the toaster message for adding of Leave Type$/,
    async function () {
        await LeaveType.verifyAddLeaveTypeUpdatedmsg(
            " Leave type added successfully. "
        );
    }
);
Then(
    /^verify the toaster message for Update of Leave Type$/,
    async function () {
        await LeaveType.verifyAddLeaveTypeUpdatedmsg(
            " Leave type updated successfully. "
        );
    }
);

Then(/^verify the visibility of the toggle buttons$/, async function () {
    await LeaveType.VerifyVisibiltyofOverTimetoggleButtons();
    await LeaveType.VerifyVisibiltyofSickTypetoggleButtons();
});

Then(/^Verify visibilty of the Add button$/, async function () {
    await LeaveType.VerifyvisibiltyofAddButton();
});
Then(/^enter the maximum Time Value$/, async function () {
    //await LeaveType.verifyVisibilityofMaximumTime()
    await LeaveType.enterValuestoMMHHofMaximumTimefield();
});

Then(/^Verify if "Add" button is enabled for leave Type$/, async function () {
    await LeaveType.verifySaveState("Enabled");
});

Then(
    /^It should give error message "Label should be unique."$/,
    async function () {
        await this.wait(2000);
        await LeaveType.VerifyDuplicatelabelentrymessgae();
    }
);

Then(
    /^Cancel button should be displayed as active with Text "Cancel"$/,
    async function () {
        await LeaveType.VerifyStatusofCancelButton();
    }
);

Then(
    /^Clicking upon the cancel button window should be closed$/,
    async function () {
        await LeaveType.clickonCancelButton();
    }
);
Then(
    /^Validate existing record can be edited and saved without any restrictions in Leave$/,
    async function () {
        await LeaveType.selectTypeDropdown("UnPaid");
        await LeaveType.ClickontoggleOvertime();
        await LeaveType.ClickontoggleSicktype();
    }
);

Then(
    /^Update button should be displayed as Active with Text "Update"$/,
    async function () {
        await LeaveType.VerifyUpdateButton();
    }
);

Then(
    /^Clicking upon the Update button changes has to be reflected in an existing record window should be closed$/,
    async function () {
        await LeaveType.Clickonupdatebtn();
    }
);

Then(
    /^Clicking upon Update button error message should be displayed if Label is edited and the name already exists$/,
    async function () {
        await LeaveType.VerifyDuplicatelabelentrymessgae();
    }
);

Then(/^Amount and Percentage Text box is optional$/, async function () {
    await LeaveType.VerifyvisibilityofAmonuntandPercentageField();
});

Then(/^Verify the atributes of Month Dropdown are visible$/, async function () {
    // await LeaveType.VerifyvisibilityofBasisdropDownofcarryOver();
    await LeaveType.VerifyMonthvaluesofCarryOver("January");
    await LeaveType.VerifyMonthvaluesofCarryOver("February");
    await LeaveType.VerifyMonthvaluesofCarryOver("March");
    await LeaveType.VerifyMonthvaluesofCarryOver("April");
    await LeaveType.VerifyMonthvaluesofCarryOver("May");
    await LeaveType.VerifyMonthvaluesofCarryOver("June");
    await LeaveType.VerifyMonthvaluesofCarryOver("July");
    await LeaveType.VerifyMonthvaluesofCarryOver("August");
    await LeaveType.VerifyMonthvaluesofCarryOver("September");
    await LeaveType.VerifyMonthvaluesofCarryOver("October");
    await LeaveType.VerifyMonthvaluesofCarryOver("November");
    await LeaveType.VerifyMonthvaluesofCarryOver("December");
});

Then(/^Day dropdown is visible according to month only$/, async function () {
    //await LeaveType.validateMonthDateFields('January',31)
    await LeaveType.validateMonthDateFields("February", 20);
    //await LeaveType.dateLogic(30,5,'April')
});

Then(/^Maximum Time Text Boxes is visible$/, async function () {
    await LeaveType.verifyVisibilityofMaximumTime();
});

Then(
    /^the Leave Type row should be displayed in the table$/,
    async function () {
        await LeaveType.verifytbl_addleaveTyperow();
    }
);
Then(/^the Add Leave Type overlay has to be displayed$/, async function () {
    await LeaveType.verifytbl_addleaveTyperow();
});
Then(/^Verify Update button is not in active state$/, async function () {
    await LeaveType.verifyupdatebuttonstate();
});

Then(
    /^verify the toaster message for adding of Leave Type$/,
    async function () {
        await LeaveType.verifyAddLeaveTypeUpdatedmsg(
            " Leave type added successfully. "
        );
    }
);
Then(
    /^verify the toaster message for Update of Leave Type$/,
    async function () {
        await LeaveType.verifyAddLeaveTypeUpdatedmsg(
            " Leave type updated successfully. "
        );
    }
);

// Then(/^verify toaster message "([^"]*)"$/, async (msg) => {
//     await LeaveType.verifyAddedLeaveType(msg);
// });

Then(/^Cancel button should be displayed$/, async function () {
    await LeaveType.VerifyStatusofCancelButton();
});
Then(/^it discards the chages without saving and navigate to Leave Types page$/,
    async function () {
        await LeaveType.navigateBacktoAddLeaveTypes();
    }
);

Then(/^verify visibility of the Cancel Button$/, async function () {
    await LeaveType.VerifyvisibiltyofCancelButton();
});

Then(/^Verify if "Add" button is disabled for leave Type$/, async function () {
    await LeaveType.verifySaveState("Disabled");
});

Then(/^Click on Add button of leave Type$/, async function () {
    await LeaveType.ClickOnSaveButton();
});
Then(
    /^It should give error message "Label should be unique."$/,
    async function () {
        await this.wait(2000);
        await LeaveType.VerifyDuplicatelabelentrymessgae();
    }
);

Then(
    /^Cancel button should be displayed as active with Text "Cancel"$/,
    async function () {
        await LeaveType.VerifyStatusofCancelButton();
    }
);

Then(
    /^Clicking upon the cancel button window should be closed$/,
    async function () {
        await LeaveType.clickonCancelButton();
    }
);

Then(
    /^Update button should be displayed as Active with Text "Update"$/,
    async function () {
        await LeaveType.VerifyUpdateButton();
    }
);

Then(
    /^Clicking upon the Update button changes has to be reflected in an existing record window should be closed$/,
    async function () {
        await LeaveType.Clickonupdatebtn();
    }
);

Then(
    /^Clicking upon Update button error message should be displayed if Label is edited and the name already exists$/,
    async function () {
        await LeaveType.VerifyDuplicatelabelentrymessgae();
    }
);
Then(/^Click on update button of leave type$/, async function () {
    await LeaveType.Clickonupdatebtn();
});

Then(/^verify the visibility of levels text appears$/, async function () {
    await LeaveType.VerifyVisibilityofLevelsText();
});
Then(
    /^I select the "Each per Period" value from Period dropdown of Earn Method$/,
    async function () {
        await LeaveType.selectPeriodDropdown("Each Pay Period");
    }
);
Then(
    /^I Select the "None" Value from Type dropdown of carry over$/,
    async function () {
        await LeaveType.selectCarryOverTypeDropdown("None");
    }
);
Then(
    /^I select the "Anniversary" value from Basis dropdown of carry over$/,
    async function () {
        await LeaveType.SelectDropdownforBasisCarryOver("Anniversary");
    }
);
Then(
    /^verify the manditory fields are available with Valid Until Month, Earn per Period and maximum Time is visible$/,
    async function () {
        await LeaveType.VerifyManditoryfielsofLevels();
    }
);
Then(
    /^Enter the values for month,Earn Per Period and Maximum time with respect to Hours or Minutes$/,

    async function () {
        await LeaveType.EnterTheValuesForLevelsManditoryFields();
        // await LeaveType.EnterThevalueforMonthoflevelField()
        // await LeaveType.EnterthevaluesforEarnPerperiodAndMaximumTimeLevel()
    }
);
Then(
    /^Enter the values for month,Earn Per Period and Maximum time with respect to Hours or Minutes for next level$/,
    async function () {
        await LeaveType.EnterTheValuesForLevelsManditoryFields();
        await LeaveType.ClickonAddBtnoflevel();
        await LeaveType.EnterThevalueforMonthoflevelField();
        await LeaveType.EnterthevaluesforEarnPerperiodAndMaximumTimeLevel();
    }
);
Then(/^Validate the Add button is enable$/, async function () {
    await LeaveType.ValidatetheEnabledstateofAddLevelButton();
});
Then(/^Validate the Add button is disable$/, async function () {
    await LeaveType.ValidatetheDisabledstateofAddLevelButton();
});

Then(/^Click on add button$/, async function () {
    await LeaveType.ClickonAddBtnoflevel();
});

Then(/^Validate the levels are incremented$/, async function () {
    await LeaveType.validateLevelIncrement();
});
Then(/^Click on delete button$/, async function () {
    await LeaveType.Clickondeleteebtn();
});

Then(/^Validate the levels are decremented$/, async function () {
    await LeaveType.ValidateLevelDecrement();
});
Then(/^Validate the existing levels are deleted$/, async function () {
    await LeaveType.ValidateExitingLevelsDeleted();
});
Then(/^I turn off the Levels Toggle$/, async function () {
    await LeaveType.ClickontoggleLevels();
});
Then(
    /^Enter the values for month,Earn per period and maximum time for to check increasing order otherwise it gives error$/,
    async function () {
        await LeaveType.EnterTheValuesForLevelsManditoryFields();
        await LeaveType.ClickonAddBtnoflevel();
        await LeaveType.EnterThevalueforMonthoflevelField();
        // await LeaveType.EnterthevaluesforEarnPerperiodAndMaximumTimeLevel()
        await LeaveType.verifyErrormsgofLevel();
    }
);
Then(
    /^Verify the Valid Until Year Field is Visible and mandatory$/,
    async function () {
        await LeaveType.VerifyValidUntilYearFieldisMandatory();
    }
);

Then(
    /^Enter the values for Year, Earn Per Perid and Maximum time with respect to Hours or Minutes$/,
    async function () {
        await LeaveType.EnterTheValueForValidUntilYear();
        await LeaveType.EnterthevaluesforEarnPerperiodAndMaximumTimeLevel();
    }
);
Then(
    /^Verify the carry Over Percentage Filed is visible and Mandatory$/,
    async function () {
        await LeaveType.verifyCarryOverPercentageFieldisVisibleAndManditory();
    }
);
Then(/^Enter The value for Carry Over Percentage$/, async function () {
    await LeaveType.EnterTheValueForCarryOverPrcentageLevel();
});

Then(
    /^Verify the carry Over Amount Filed is visible and Mandatory$/,
    async function () {
        await LeaveType.VerifycarryOverAmountFieldisVisibleAndManadatory();
    }
);
Then(/^Enter The value for Carry Over Amount$/, async function () {
    await LeaveType.EnterTheValueForCarryOverAmountLevelField();
});
Then(/^I select the Each Year peroid attribute$/, async function () {
    await LeaveType.selectPeriodDropdown("Each Year");
});

Then(
    /^Validate the Carry Over Amount is filled$/,

    async function () {
        await LeaveType.ValidatetheCarryOverAmountlevelField();
    }
);

Then(/^Verify Levels option is not available$/, async function () {
    await LeaveType.verifyVisiblityofLevelToggle();
});

Then(/^Click on cancel button to close the overlay$/, async function () {
    await LeaveType.clickonCancelButton();
});
Then(/^Validate the error messgae for label if not filled$/, async function () {
    await LeaveType.ClearTextValuesforLbel();
});
Then(/^Clear the value for Earn Per Period$/, async function () {
    await LeaveType.cleartextValueofEarnPerPeriod();
});
Then(/^Clear the value of Maximum time$/, async function () {
    await LeaveType.ClearTextValueofMaximumTime();
});

Then(
    /^Verify Earn Per Period Text box is visible and mandatory$/,
    async function () {
        await LeaveType.verifyEarn_per_periodVisible();
    }
);

Then(
    /^Verify error message for Validation "Earn per period is required"$/,
    async function () {
        await LeaveType.ValidateErrormessageForEarnPerPeriod();
    }
);
Then(
    /^Verify error message for Validation "Maximum time is required"$/,
    async function () {
        await LeaveType.ValidateErrormessageFormaximumTime();
    }
);

Then(
    /^I select the "Each Pay Period" value from Period dropdown of Earn Method$/,
    async function () {
        await LeaveType.selectPeriodDropdown("Each Pay Period");
    }
);

Then(
    /^Enter the values for month, Earn Per Perid and Maximum time with respect to Hours or Minutes$/,
    async function () {
        await LeaveType.EnterTheValuesForLevelsManditoryFields();
        // await LeaveType.EnterThevalueforMonthoflevelField()
        // await LeaveType.EnterthevaluesforEarnPerperiodAndMaximumTimeLevel()
    }
);

Then(
    "Verify all the required field in Add New Asset form should have required symbol",
    async () => {
        await assetRepository.verifyAddNewAssetRequiredField();
    }
);

Then("Verify Add new asset type overlay is closed", async () => {
    await assetRepository.isHeaderVisible(false);
});

Then("Verify Add new asset type overlay is visible", async () => {
    await assetRepository.isHeaderVisible(true);
});

Then("Verify all the core attributes in attribute table", async () => {
    await assetRepository.verifyCoreAttributes();
});

Then("Verify attribute got added", async () => {
    await assetRepository.isDeleteAttrVisible(true);
});

Then("Verify attribute is deleted", async () => {
    await assetRepository.isDeleteAttrVisible(false);
});

Then("Verify asset is added Asset repository table", async () => {
    await assetRepository.navigatetoAssetRepository()
    await assetRepository.verifyAssetAddedByAssetName("assetName");
});
Then("Verify asset is type name and department are editable and Verify the logs", async () => {
    await assetRepository.navigatetoAssetRepository()
    await assetRepository.verifyAssetEditFields("assetName");
});

Then(/^Account details page should be displayed and store AccountID in "([^"]*)"$/, async (filename) => {
    let acc = (await commonUtils.gettoasterMessage()).match(/\d+/g);
    let accno = acc[0].slice(0,-3)
    await addAccountPage.getAccountIDLabel(filename,accno)
});
Then(/^Enter the values for Earned Per Period$/, async function () {
    await LeaveType.EnterTheValuesForEarnperPeriodFields();
});


Then(/^Verify the newly added deduction in master record list for "([^"]*)"$/, async (fileName) => {
    await deductiblepage.apiVerifyNewlyAddedRecord(fileName); 
});
Then(
    /^I add a new employee deduction via API for "([^"]*)"$/,
    async function (fileName: string) {
        await deductiblepage.apiAddEmployeeDeduction(fileName);
    }
)
Then(
    /^validate the Deductions added to employee in deduction tab for "([^"]*)"$/,
    async function (fileName: string) {
        await addEmployee.apiVerifyNewlyAddedEmpDeductions(fileName);
    });
Then(/^verify leaveType should be displayed in master record list for "([^"]*)"$/, async (filename) => {
    const jsonData = await jsonUtil.readData(`tempFiles/${filename}.json`);
    await LeavesTypes.verifyAddedLabel(jsonData.LeaveTypeName);
});    

