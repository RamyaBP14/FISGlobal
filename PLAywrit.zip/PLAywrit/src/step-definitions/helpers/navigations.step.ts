import { Given } from "@cucumber/cucumber"
import { Navigations } from "../../utility/navigations"

const navigations = new Navigations()

Given(/^I navigate to FrontDesk Public Users page$/, async function () {
  await navigations.navigateToFDPublicUsers()
})

Given(/^I navigate to Service Locations page$/, async function () {
  await navigations.navigateToServiceLocations()
})