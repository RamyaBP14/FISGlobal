import {Then, When} from "@cucumber/cucumber"
import {HomePage} from "../pom/ui/hr_hub/homePage"
import { PayrollSettingsPage } from "../pom/ui/hr_hub/payRollSettings"
import { PayTypesPage } from "../pom/ui/hr_hub/payTypesPage";
import { LoggerUtil } from "../utility/logger";
const {chromium, firefox, webkit} = require('playwright');
import { deductiblesPage } from "../pom/ui/hr_hub/deductiblesPage"
import { LeaveTypePageClass } from "../pom/ui/hr_hub/LeavesTypes";
import { AssetRepositoryPage } from "../pom/ui/ops_hub/assetRepositoryPage";
import { AddAccountPage } from "../pom/ui/ub_hub/addAccountPage";
import { AccountsPage } from "../pom/ui/ub_hub/accountsPage";
import { JsonOperations } from "../utility/jsonOperations";
import { AccountDetailsSummaryPage } from "../pom/ui/ub_hub/accountDetailsSummaryPage";
import { AccountServicesPage } from "../pom/ui/ub_hub/accountDetailsServicesPage";
import { AddEmployee } from "../pom/ui/hr_hub/addEmployee";
import { AddTaxTablePage } from "../pom/ui/ub_hub/addTaxTablePage";
import { LeaveTypesPages } from "../pom/ui/hr_hub/LeaveTypesPages";
import { levels } from "log4js";
import { SetupFuelAdjustment } from "../pom/ui/ub_hub/setupFuelAdjustmentPage"

let paytypes = new PayTypesPage()
let log = new LoggerUtil()
let homepage = new HomePage()
let deductiblepage=new deductiblesPage()
let payrollSettings = new PayrollSettingsPage()
let LeavesTypes = new LeaveTypePageClass()
let LeaveType=new LeaveTypesPages()
let assetRepository = new AssetRepositoryPage()
let addAccountPage = new AddAccountPage()
let accounts = new AccountsPage()
let jsonUtil = new JsonOperations()
let accountDetails = new AccountDetailsSummaryPage()
let accountServices = new AccountServicesPage()
let addEmployee = new AddEmployee()
let addTaxTable =new AddTaxTablePage()
let setupFuelAdjustment =new SetupFuelAdjustment()
const options = {
    headless: false, };
When(
    /^I click the "Add Deductibles" button$/,
    async function () {
        

        await deductiblepage.ClickonAddDeductibles();
    }
)
When(
    /^I click on Add Pay Types button$/,
    async function () {
        await paytypes.clickAddPayType()
        log.info("Clicked on Add paytype button")
        
    }
)

When(
    /^I add all required fields in Add Pay Types fields$/,
    async function () {
        await paytypes.enterlabelfield("Test")
        await paytypes.selectTypes(/^Salary$/)
        await paytypes.selectFrequency(/^Weekly$/)
        

    }
)

When(
    /^I search for newly added Deductible from the list by using data from "([^"]*)" file$/,
        async function (fileName: string) {
            
            await deductiblepage.searchDeductibles(fileName);        
        }
    )
When(
    /^I cleared one required field$/,
    async function () {
        await paytypes.enterlabelfield("")
        
    }
)

When(
    /^I add and save all required fields in Add Pay Types fields$/,
    async function () {
        const labelName = await paytypes.enterLabeldata()
        console.log(labelName)
        await paytypes.selectTypes(/^Hourly$/)
        await paytypes.selectFrequency(/^Annual$/)
        await paytypes.saveTypes()
        // await paytypes.searchPaytypes(labelName)
        // await paytypes.verifyRecetlyAddedPaytype(labelName)        
    }
)


When(/^I add and save all required fields in Add Pay Types fields for "([^"]*)"$/, async (scenarioNumber) => {
	    await paytypes.enterUniqueLabel(scenarioNumber)
        const jsonData = await jsonUtil.readData(`PayrollCalculationData/${scenarioNumber}.json`)
        await paytypes.selectPayTypeTypes(jsonData.Paytype_type)
        await paytypes.wait(2000)
        await paytypes.selectPayTypeFrequency(await jsonData.PaytypeFrequency)
        if(jsonData.Federal_Tax_2023_tables!=0){
            await paytypes.clickOnFederalCheckbox()
        }

        if(jsonData.State_Tax!=0 && jsonData.State_Tax!=undefined){
            await paytypes.clickOnStateCheckbox()
        }
        if(jsonData.Local_Tax!=0 && jsonData.Local_Tax!=undefined){
            await paytypes.clickOnLocalCheckbox()
        }
        
        await paytypes.clickOnMedicareCheckbox()
        await paytypes.clickOnSocialSecurityCheckbox()
        await paytypes.saveTypes()
        await paytypes.clickAddPayType()
        await paytypes.enterUniqueLabelForHourlyPaytype(scenarioNumber)
        await paytypes.wait(2000)
        await paytypes.selectPayTypeTypes(jsonData.Paytype_type1)
        await paytypes.wait(2000)
        await paytypes.selectPayTypeFrequency(jsonData.PaytypeFrequency1)
        await paytypes.selectHourlyOverTimerate("1.5x")
        if(jsonData.State_Tax!=0 && jsonData.State_Tax!=undefined){
            await paytypes.clickOnStateCheckbox()
        }
        if(jsonData.Local_Tax!=0 && jsonData.Local_Tax!=undefined){
            await paytypes.clickOnLocalCheckbox()
        }
        await paytypes.clickOnFederalCheckbox()
        await paytypes.clickOnMedicareCheckbox()
        await paytypes.clickOnSocialSecurityCheckbox()
        await paytypes.saveTypes()

});


When(/^I check and add per item and allowance paytypes for "([^"]*)"$/, async (scenarioNumber) => {
        const jsonData = await jsonUtil.readData(`PayrollCalculationData/${scenarioNumber}.json`)
        if(await jsonData.Per_Item != "NA" && await jsonData.Per_Item !=undefined)
        {
            await paytypes.clickAddPayType()
            await paytypes.enterUniqueLabelforPerItem(scenarioNumber)
            await paytypes.selectPayTypeTypes(jsonData.Paytype_type2)
            await paytypes.wait(2000)
            await paytypes.selectPayTypeFrequency(jsonData.PaytypeFrequency2)
            if(jsonData.State_Tax!=0 && jsonData.State_Tax!=undefined){
                await paytypes.clickOnStateCheckbox()
            }
            if(jsonData.Local_Tax!=0 && jsonData.Local_Tax!=undefined){
                await paytypes.clickOnLocalCheckbox()
            }
            await paytypes.clickOnFederalCheckbox()
            await paytypes.clickOnMedicareCheckbox()
            await paytypes.clickOnSocialSecurityCheckbox()
            await paytypes.saveTypes()
        }
        
        if(await jsonData.Allowance != "NA" && await jsonData.Allowance !=undefined)
        {
            await paytypes.clickAddPayType()
            await paytypes.enterUniqueLabelforAllowance(scenarioNumber)
            await paytypes.wait(2000)
            await paytypes.selectPayTypeTypes(jsonData.Paytype_type3)
            await paytypes.wait(3000)
            await paytypes.selectPayTypeFrequency(jsonData.PaytypeFrequency3)
            if(jsonData.PaytypeFrequency3=="Monthly"){
                await paytypes.selectPayAllowanceWithMenu("First Pay of Month")
            }
            if(jsonData.AllowanceTaxable==1){
            if(jsonData.State_Tax!=0 && jsonData.State_Tax!=undefined){
                await paytypes.clickOnStateCheckbox()
            }
            if(jsonData.Local_Tax!=0 && jsonData.Local_Tax!=undefined){
                await paytypes.clickOnLocalCheckbox()
            }
            await paytypes.clickOnFederalCheckbox()
            await paytypes.clickOnMedicareCheckbox()
            await paytypes.clickOnSocialSecurityCheckbox()
        }
            await paytypes.saveTypes()
        }       
});




When(
    /^I add all required fields for allowance type in Add Pay Types fields$/,
    async function () {
        //const labelName = await paytypes.enterLabeldata()
        await paytypes.enterLabelofPaytype()
        await paytypes.selectTypes(/^Allowance$/)
        await paytypes.selectFrequency(/^Monthly$/)
        await paytypes.selectPayAllowanceWithMenu(/^First Pay of Month$/)       
    }
)


When(
    /^I select Add to toggle button$/,
    async function () {
        await paytypes.clickOnPensionToggleButton()      
    }
)

When(
    /^I select tax type and save the details$/,
    async function () {
        await paytypes.clickOnFederalCheckbox() 
        await paytypes.saveTypes()
        await paytypes.searchPaytypes(global.genlabelName)
    }
)


When(
    /^I disable Set at Employee toggle and select Salary type$/,
    async function () {
        await paytypes.switchEmployeeToggle()
        await paytypes.selectTypes(/^Salary$/)
    }
)

When(
    /^I disable Set at Employee toggle and select Hourly type$/,
    async function () {
        await paytypes.switchEmployeeToggle()
        await paytypes.selectTypes(/^Hourly$/)
    }
)

When(
    /^I disable Set at Employee toggle and select Per Item Rate$/,
    async function () {
        await paytypes.switchEmployeeToggle()
        await paytypes.selectTypes(/^Per Item$/)
    }
)

When(
    /^I disable Set at Employee toggle and select Allowance$/,
    async function () {
        await paytypes.switchEmployeeToggle()
        await paytypes.selectTypes(/^Allowance$/)   
    }
)

When(
    /^I search for recently added paytype entry$/,
    async function () {
        await paytypes.searchPaytypes(global.genlabelName)   
    }
)

When(/^I click on Cancel button$/,
    async function () {
        await paytypes.clickOnCancel()   
    }
)

When(
    /^the deduction window is displayed$/,
    async function () {
        await payrollSettings.waitforDeductionWindowToDisplay()   
    }
)

When(/^I click pay types tab$/, async() => {
	
});

When(/^I click on "([^"]*)" sort arrow key$/, 
    async function(columnName:string) {
        await payrollSettings.clickOnColumnSort(columnName)
    }
)

When(/^I again click on "([^"]*)" sort arrow key$/, 
	async function(columnName:string) {
        await payrollSettings.clickOnLabelAsc(columnName)
});


When(/^I again click on "([^"]*)" sort arrow key for ascending order$/, async (columnName:string) => {
        await payrollSettings.clickOnLabelAsc(columnName)
});


When(/^I again click on "([^"]*)" sort arrow key for descending order$/, async (columnName:string) => {
	    await payrollSettings.clickOnLabelDesc(columnName)
        
});

When(/^I again click on "([^"]*)" sort arrow key for descending orderUbhub$/, async (columnName:string) => {
    await payrollSettings.clickOnLabelDescUbhubMain(columnName)
});


When(/^I select show items per page as "([^"]*)"$/, async (numberofPages) => {
	await payrollSettings.selectNumberOfResultsPerPage(numberofPages)
});


When(/^I search entry for given keyword$/, async() => {
    await payrollSettings.searchEntry("test")
});

When(/^I select Page "([^"]*)"$/, async(pageNumber) => {
    await payrollSettings.selectPage(pageNumber)
})

When(/^I click on next button$/, async() => {
    await payrollSettings.clickOnPaginationNextUbhub()
})

When(/^I click on previous button$/, async () => {
    await payrollSettings.clickOnPaginationPrevious()
})

When(/^I click on last page$/, async () => {
    await payrollSettings.clickOnPaginationLastPage()	
})

When(/^I click on record number "([^"]*)" from Master list for edit$/, async (recordNumber) => {
    await paytypes.clickOnMasterListRecord(recordNumber)
    await paytypes.wait(3000)
})

When(/^I click on edit paytypes Cancel button$/, async () => {
    await paytypes.clickOnEditPayTypesCancel()
})


When(/^I click on GL Distribution tab$/, async () => {
	await paytypes.clickOnGLDistributionTab()
})

When(/^I click on Audit Trail tab$/, async() => {
	await paytypes.clickOnAuditTrailTab()
})


When(/^Edit Label field with new name$/, async() => {
	await paytypes.recordOldLabelName()
    await paytypes.enterLabelRandomNumber()
})


When(/^I click on edit paytypes Update button$/, async () => {
	await paytypes.clickonUpdateButton()
})


When(/^I search for recently updated paytype record in master list$/, async () => {
	await paytypes.searchPaytypes(global.genlabelName)
})


When(/^I search for previous paytype record in master list with old label name$/, async () => {
	await paytypes.searchPaytypes(global.oldLabelName)
})


When(/^I enable the Enable Gross Pay Distribution toggle$/, async () => {
	await paytypes.switchGrosspayToggle()
})


When(/^I enter data in gross pay field$/, async () => {
	await paytypes.enterGrossPayValue()
})


When(/^I click on updated record$/, async () => {
    const jsonData = await jsonUtil.readData(`tempFiles/allowanceType.json`)
    const labelName = await jsonData.LabelName
	await paytypes.selectUpdatedRecord(labelName)
})


When(/^I select created as activity type$/, async () => {
	await paytypes.selectActivityTab("Created")
})


When(/^I select activity type as "([^"]*)"$/, async (activityType) => {
	await paytypes.selectActivityTab(activityType)
	
})


When(/^I select updated and created both activity type$/, async () => {
	//Updated is already selected here in previous step
    await paytypes.selectMultipleActivityTab("Created")
})


When(/^I update paytypes record and reopen the same$/, async () => {
	await paytypes.updatePaytypeFrequencyReopenRecord("paytypeUpdatedRecord")
})


When(/^I update paytypes record and reopen the same to validate date Range$/, async () => {
	await paytypes.updatePaytypeFrequencyReopenRecord("dateRange")
})



When(/^I select date range as "([^"]*)"$/, async (dateType) => {
	await paytypes.selectDateRange(dateType)	
})


When(/^I select date as Yesterday$/, async () => {
	await paytypes.clickonDateRangeYesterday()
})


When(/^I click on clone button$/, async () => {
	await paytypes.clickOnCloneButton()
})


When(/^I Click on Cancel button on Confirmation dialog$/, async () => {
	await paytypes.clickOnCloneDialogCancel()
})


When(/^I click on clone button on confirmation dialog$/, async () => {
	await paytypes.clickOnCloneDialogClone()
})


When(/^I click on Clone Add button$/, async () => {
	await paytypes.clickonUpdateButton()
})


When(/^I search for Cloned record$/, async () => {
	await paytypes.searchClonedRecord(global.clonedLabelName)
})


When(/^I switch the Federal checkbox$/, async () => {
	await paytypes.updateFederalCheckbox()
});


When(/^I search for updated Cloned record$/, async () => {
	await paytypes.searchClonedRecord(global.recordedclonedLabelName)
})


When(/^Record the existing paytype Label$/, async () => {
	await paytypes.recordExistingPaytype()
})


When(/^I enter existing label name$/, async () => {
	await paytypes.enterExistingLabel()
})


When(/^I search for 'Service Location' in asset repository$/, async () => {
	await assetRepository.searchIteminGlobalSearchbox("Service Locations")
})


When(/^I search for "([^"]*)" in asset repository$/, async (assetToSearch) => {
	await assetRepository.searchIteminGlobalSearchbox(assetToSearch)
});



When(/^I click on service location link$/, async () => {
	await assetRepository.selectFromSearchedItemList("Service Locations")
})


When(/^I click on asset repository "([^"]*)" link$/, async (linkToClick) => {
	await assetRepository.selectFromSearchedItemList(linkToClick)
});



When(/^I click on Add Service Location Button$/, async () => {
	await assetRepository.clickOnAddServiceLocationButton()
})


When(/^I enter data in all required field for tenant$/, async() => {
	await assetRepository.fillNSLocationForm("tenant")
})


When(/^I enter data in all required field for property Owner$/, async() => {
	await assetRepository.fillNSLocationForm("propertyOwner")
})


When(/^I click on Next button$/, async () => {
	await assetRepository.clickOnNextButton()
})


When(/^I enter Cycle and Route and press Save button$/, async () => {
	await assetRepository.enterCycleNS("2")
    await assetRepository.enterRouteNS("2")
    await assetRepository.clickOnSaveButtonNS()
})


When(/^I click on back button$/, async () => {
	await assetRepository.clickOnBackButton()
})


When(/^I search for newly added service location$/, async () => {
	await assetRepository.searchNewlyAddedserviceRecord("propertyOwner")
})

When(/^I search for newly added service location for tenant$/, async () => {
	await assetRepository.searchNewlyAddedserviceRecord("tenant")
})

When(/^I select occupancy as tenant$/, async () => {
	await assetRepository.selectOccupancy("Tenant")
})


When(/^I check different bill payer account checkbox$/, async () => {
	await addAccountPage.switchBillPayerCheckbox()
})


When(/^I fill all the required field for New Account form$/, async() => {
	await addAccountPage.fillBasicInformationForm()
})


When(/^I click on Next Button$/, async () => {
	await addAccountPage.clickOnNextButton()
})


When(/^I enter data in service location and account holder field$/, async () => {
	await addAccountPage.enterServiceLocationfromRecordedFile("saveAsDraft")
    await addAccountPage.enterAccountHolderName("Thomas")
    await addAccountPage.enterRelation("Property Owner")
})


When(/^I enter data in service location and account holder field for "([^"]*)"$/, async (filename) => {
    await addAccountPage.enterServiceLocationfromRecordedFile(filename)
    await addAccountPage.enterAccountHolderName("Thomas")
    await addAccountPage.enterRelation("Property Owner")
})



When(/^I click on Save as draft button$/, async () => {
	await addAccountPage.clickOnSaveAsDraft()
})

When(/^I click on Add button$/, async () => {
	await addAccountPage.clickOnServicesAddButton()
})


When(/^I enter values in all the required fields for service type "([^"]*)"$/, async (serviceType) => {
    const jsonData = await jsonUtil.readData(`tempFiles/${serviceType}.json`)
    await addAccountPage.selectServiceFieldtoAddService(serviceType)
    await addAccountPage.enterMeterId(jsonData.MeterID)
    await addAccountPage.enterBeginningMeterId("9999")
    await addAccountPage.enterDeposits("1000000")
	
})


When(/^I enter values in all the required fields for service type "([^"]*)" with Meter ID$/, async (serviceType) => {
    //const jsonData = await jsonUtil.readData(`tempFiles/${serviceType}.json`)
    await addAccountPage.selectServiceFieldtoAddService(serviceType)
    await addAccountPage.enterMeterId("7")
    await addAccountPage.enterBeginningMeterId("9999")
    await addAccountPage.enterDeposits("1000000")
   
})

When(/^I enter values for Rate and Tax table$/, async () => {
	await addAccountPage.rateFieldtoAddService()
    await addAccountPage.taxFieldtoAddService()
    await addAccountPage.enablePenaltyToggle()
})


When(/^I click on Save button$/, async () => {
	await addAccountPage.clickOnAddServiceSaveButton()
})


When(/^I click on services page back button$/, async () => {
	await addAccountPage.clickOnServiceBackButton()
})


When(/^Delete water service$/, async() => {
	await addAccountPage.deleteService("WATER")
})


When(/^I click on move-in button$/, async () => {
	await addAccountPage.clickOnInitiateMoveInButton()
})


When(/^I close the alert dialog message$/, async () => {
	await addAccountPage.closeAlertDialog()
})


// When(/^I click on existing Electricity service and update it to Water service$/, async () => {
// 	await addAccountPage.clickOnAddedService("Electricity")
//   //  await addAccountPage.clickOnServicesAddButton()
//     await addAccountPage.enterMeterId("7999")
//     await addAccountPage.selectServiceFieldtoUpdateService("Water")
//     await addAccountPage.clickOnAddServiceSaveButton()
// })


When(/^I click on existing "([^"]*)" service and update it to "([^"]*)" service$/, async (existingService,newService) => {
	await addAccountPage.clickOnAddedService(existingService)
    //await addAccountPage.clickOnServicesAddButton()
    await addAccountPage.selectServiceFieldtoUpdateService(newService)
    await addAccountPage.enterMeterId("1")
    //await addAccountPage.clickOnAddServiceSaveButton()
});


When(/^I click on services Save as draft button$/, async () => {
    await addAccountPage.clickOnBasicSaveAsDraftButton()
})
When(/^I click on services Save as draft button after adding service$/, async () => {
    await addAccountPage.clickOnServicesSaveAsDraftButton()
})


When(/^I click on first active account of the account record$/, async () => {
	await accounts.clickOnFirstAccounttogetAccountDetails("5")
})


When(/^I click on record number "([^"]*)" from the account record master list$/, async (recordNumber) => {
	await accounts.clickOnAccountToGetAccountDetails(recordNumber)
  await accounts.waitForLoader()
});

When(/^I click on a random visible Account$/, async function () {
  await accounts.clickOnRandomAccountFromMasterList()
});

When(/^I click on Edit link at account summary section$/, async () => {
	await accountDetails.clickOnEditLink()
})


When(/^I navigate to the added account from Accounts page$/, async () => {
	await accountDetails.navigateToAddedAccount("AccountDetailsValidations")
})


When(/^I navigate to the added account from Accounts page for "([^"]*)"$/, async (fileName) => {
	await accountDetails.navigateToAddedAccount(fileName)
	
});


When(/^I record Service details for "([^"]*)"$/, async (fileName) => {
	await accountServices.recordServiceDetails(fileName)
})


When(/^I record Service Information details for "([^"]*)"$/, async(fileName) => {
	await accountServices.recordServiceInformationDetails(fileName)
})


When(/^I record all the summary details$/, async() => {
	await accountDetails.recordAddedaccountDetails("AccountDetailsValidations")
})

When(/^I record all the summary details for "([^"]*)"$/, async(filename) => {
	await accountDetails.recordAddedaccountDetails(filename)
})

When(/^I record all the summary details with Holder Name for "([^"]*)"$/, async(filename) => {
	await accountDetails.recordAddedaccountDetailsWithHolderName(filename)
})

When(/^I record all the summary details in "([^"]*)"$/, async (filename) => {
    await accountDetails.recordAddedaccountDetails(filename)
});

When(/^I click on "([^"]*)" details button and collect details$/, async (consideration) => {
	await accountDetails.storeActiveServicelist()
    await accountDetails.clickOnConsiderationsDetailsButton(consideration)
    await accountDetails.storeConsiderationValues(consideration)
    await accountDetails.clickCancelConsiderationWindow()
});



When(/^I click on service request link$/, async () => {
	await accountServices.clickOnServiceRequestLink()
})

When(/^I click on Meter Changeouts link$/, async () => {
	await accountServices.clickOnMeterChangeOutsLink()
})

When(/^I click on Meter ID link$/, async () => {
	await accountServices.clickOnMeterIdLink()
})


When(/^I click on first associated service$/, async () => {
	await accountServices.clickOnFirstService()
})

When(/^I click on YearlyView button$/, async () => {
	await accountServices.clickOnYearlyButton()
})


When(/^I search for the account using account number from the master list of account records$/, async () => {
	await accounts.searchwithAccountNumberFromMasterList("accountsSearch")
})


When(/^I search for the account using Account holder name from the master list of account records$/, async () => {
	await accounts.searchwithAccountHolderFromMasterList("accountsSearch")
})


When(/^I clear previous search$/, async() => {
	await accounts.clearPreviousSearch()
})


When(/^I search for the account using Service Location from the master list of account records$/, async () => {
    await accounts.searchwithServiceLocationFromMasterList("accountsSearch")	
})


When(/^I search for the account using Bill payer from the master list of account records$/, async () => {
    await accounts.searchwithBillPayerFromMasterList("accountsSearch")
})


When(/^I search for the account using Bill Payer Type from the master list of account records$/, async () => {
    await accounts.searchwithBillPayerTypeFromMasterList("accountsStatusSearch")
})


When(/^I search for the account using Account Status from the master list of account records$/, async () => {
	await accounts.searchwithAccountStatusFromMasterList("accountsStatusSearch")
})

When(/^I search for the account using Move In Date from the master list of account records$/, async () => {
    await accounts.searchwithMoveInDatesFromMasterList("accountsStatusSearch")
})


When(/^I search for the account using Move out date from the master list of account records$/, async () => {
    await accounts.searchwithMoveOutDatesFromMasterList("accountsStatusSearch")
})


When(/^I filter payer types as "([^"]*)"$/, async (filterValue) => {
	await accounts.selectPayTypesFilterOption(filterValue)
})


When(/^I filter status as "([^"]*)"$/, async (filterOption) => {
	await accounts.selectStatusFilter(filterOption)
})


When(/^I filter service as "([^"]*)"$/, async (filterOption) => {
	await accounts.selectServicesFilter(filterOption)
})


When(/^I filter considerations as "([^"]*)"$/, async (filterOption) => {
	await accounts.selectConsiderationsFilter(filterOption)
})

When(/^I filter account type as "([^"]*)"$/, async (filterOption) => {
	await accounts.selectType(filterOption)
});


When(/^I click on Account Number link$/, async () => {
	await accounts.clickOnAccountNumberFirstRecord()
});


When(/^I click on Account Holder link$/,async  () => {
	await accounts.clickOnAccountHolderFirstRecord()
})


When(/^I click on Bill Payer link$/, async () => {
	await accounts.clickOnBillPayerFirstRecord()
})

When(/^I click on Add Employee$/, async () => {
	await addEmployee.clickOnAddEmployeeButton()
})

When(/^I enter employee first name$/, async () => {
	await addEmployee.enterFirstName("Test")
})

When(/^I enter unique employee ID for "([^"]*)"$/, async (filename) => {
	await addEmployee.enterUniqueEmployeeID(filename)
});

When(/^I enter employee ID$/, async () => {
	await addEmployee.enterEmployeeID("$*&#@")
})


When(/^I enter last name$/, async () => {
	await addEmployee.enterLastName("QaTest")
})

When(/^I clear the employee ID field$/, async () => {
	await addEmployee.clearEmployeeIDField()
})


When(/^I clear the employee name field$/, async () => {
	await addEmployee.clearFirstNameField()
})


When(/^I clear the last name field$/, async () => {
	await addEmployee.clearLastNameField()
})


When(/^I Enter all mandatory fields and add employee for "([^"]*)"$/, async (filename) => {
	await addEmployee.enterUniqueEmployeeID(filename)
    await addEmployee.enterUniqueName(filename)
    await addEmployee.enterUniqueLastName()
    await addEmployee.clickOnAddButton()
});


When(/^I search for recently added employeeID for "([^"]*)"$/, async (filename) => {
	await addEmployee.searchAddedEmployee(filename)
});


When(/^I Navigate to add employee window from HR tab$/, async () => {
	await addEmployee.navigateToAddEmployeeWithinHRTab()
});



When(/^I click on recently added employee ID at employee page for "([^"]*)"$/, async (filename) => {
	await addEmployee.selectRecordByEmployeeID(filename)
});





When(
    /^$/,
    async function () {
            
    }
)

When(
/^I click the Leave Types tab and button$/,
async function () {
    //await LeaveType.ClickonAddleaveType();
      await LeavesTypes.navigateAddLeaveType();
        
})
When(
    /^I click the Leave Types tab$/,
    async function () {
        await LeavesTypes.clickLeaveTypesTab();
        
})
When(
    /^I click the Compensation toggle button$/,
    async function () {
        await LeaveType.toggleCompensationLeaveType();
        
})
When(
    /^I click the Leave Types button$/,
    async function () {
        await LeavesTypes.clickLeaveTypesAddButton();
        
})

When(
    /^I Click an existing record for edit$/,
    async function(){
        await LeavesTypes.Clickonsavedrecord() 
})


When(
    /^I add new leave type$/,
    async function(){
       
        await LeavesTypes.navigateAddLeaveType()
        await LeavesTypes.leaveTypeCompensationFields();
        await LeavesTypes.clickAddonButton();
})

When(
    /^I search and Click an existing record for edit$/,
    async function(){
        await LeavesTypes.leaveTypeSearch();
       
})

When(
    /^I verify the attributes of Type dropdown$/,
    async function () {
        await LeaveType.AddlabelValue("Automation_003");
        await LeaveType.selectTypeDropdown("Paid");
      //  await LeaveType.selectTypeDropdown("UnPaid")
    }
)
When(
    /^I click on the type dropdown$/,
    async function(){
        await LeaveType.ClickonTypeDropdown();
    }
)
When(
    /^I select the Each Pay peroid attribute$/,
    async function(){
        await LeaveType.selectPeriodDropdown("Each Pay peroid");

    }
    
)
When(
    /^I Select the Each Month Attribute$/,
    async function(){
        await LeaveType.selectPeriodDropdown("Each Month")
    }
)
When(
    /^I Select the Each Year Attribute$/,
    async function (){
        await LeaveType.selectPeriodDropdown("Each Year")

    }
    )
When (
    /^I Select the Regular Hours Attribute$/,
    async function(){
        await LeaveType.selectPeriodDropdown("Regular Hours")
    }
)
When (
        /^I Select the Total Hours Attribute$/,
        async function(){
        await LeaveType.selectPeriodDropdown("Total Hours");
    }
)
When(
    /^I Select attribute value Amount under Type dropdown$/,
    async function(){
        await LeaveType.selectCarryOverTypeDropdown("Amount");
    }
)
When(
    /^I Select attribute value Percentage under Type dropdown$/,
    async function(){
    await LeaveType.selectCarryOverTypeDropdown("Percentage");
    }
)
When(
    /^Select attribute value is none under Type dropdown$/,
    async function(){
        await LeaveType.selectCarryOverTypeDropdown("None");
    }
)
When(
    /^I click on Date Attribute of Basis Dropdown$/,
    async function(){
        await LeaveType.SelectDropdownforBasisCarryOver("Date");


    }
)
When (
    /^I select a particular Month from dropdown list like January to December$/,
    async function(){
        await LeaveType.selectArrtibuteforMonthCarryOver("January")

    }

)
When(
    /^I search for (.*) Leave Type row$/, async (msg) => {
        await LeaveType.searchEntry(await addEmployee.makeString(msg));  
    }
)
When(
    /^the Leave Type row is selected.$/,
    async function(){
        await LeaveType.Clicktbl_addleaveTyperow();

    }
)
When (
    /^click on cancel button of Leave Type$/,
    async function(){
    await LeaveType.clickonCancelButton();
    }
)

When(
    /^I click on Overtime toggle Button$/,
    async function(){
        await LeaveType.ClickontoggleOvertime();

    }
)
    
When(
    /^I click on Sick Type toggle Button$/,
    async function(){
        await LeaveType.ClickontoggleSicktype();
    }
)
When (
    /^I enter label value "leavetyperegression"$/,
    async function(){
        await LeaveType.Enterlabelfordulicatecheck("leavetyperegression")
    }
)
When(/I click on the Levels Toggle$/,
async function(){
    await LeaveType.ClickontoggleLevels()
}
)

When(/^I click on Add Tax Table button$/, async() => {
	await addTaxTable.clickOnAddtaxTableButton()
});


When(/^I add invalid data in all the required field$/, async () => {
	await addTaxTable.addInvalidData();
});



When(/^I add all the required field on Add Tax table form$/, async () => {
	await addTaxTable.addTaxTable();
});


When(/^I add all the required field and one Tax method$/, async () => {
	await addTaxTable.addTaxTableWithOneTaxMethod();
});


When(/^I add all the required field and same Tax Table name$/, async () => {
	await addTaxTable.addDuplicateTaxTable();
});


When(/^I add all the required field and did not select any Tax method$/,async () => {
    await addTaxTable.addTaxTableWithoutTaxMethod();
});


When(/^I click on close button$/,async () => {
	await addTaxTable.clickOnCancelButtonOnOverlay();
});


When(/^I click on Add Button on Add tax table overlay$/,async () => {
	await addTaxTable.clickAddButtonOnAddTaxTableoverlay()
});


When(/^I select Tax method dropdown "([^"]*)"$/, async (value) => {
	await addTaxTable.selectStateTaxMethodDropDown(value)
});



When(/^I click on Select Eligible Services dropdown$/, async () => {
	await setupFuelAdjustment.clickEligibleServicesDropdown()
});


When(/^I select a service "([^"]*)"$/, async (service) => {
	await setupFuelAdjustment.selectServiceFromEligibleServicesDropdown(service)
});



When(/^User selects "([^"]*)"$/, async (SelectAll) => {
	
    await setupFuelAdjustment.selectServiceFromEligibleServicesDropdown(SelectAll)
});

When(/^I click on Calculation Base dropdown$/, async() => {
    await setupFuelAdjustment.clickCalculationBaseDropdown()
});


When(/^Select "([^"]*)" Calculation Base$/, async(Value) => {
    await setupFuelAdjustment.selectFromCalculationBaseDropdown(Value)
});


When(/^I click on Tax Exempt toggle$/, async () => {
	await setupFuelAdjustment.clickOntaxExemptToggle()
});


When(/^I click on Fuel Adjustment Save button$/,async() => {
	await setupFuelAdjustment.clickSaveButton()
});


When(/^I click on Fuel Adjustment Reset button$/, async () => {
	await setupFuelAdjustment.clickResetButton()
});

When('I click on Add New Asset Type button', async () => {
	await assetRepository.clickAddNewAssetType();
})

When('Fill the asset type name', async () => {
	await assetRepository.enterAssetTypeName("assetName");
})

When(/^Select the department as (.*)$/, async (dept) => {
    dept = await assetRepository.makeString(dept);
	await assetRepository.selectDepartment(dept);
})

When('Fill the attribute name and type', async () => {
	await assetRepository.enterAttributeName();
})

When(/^Select the type as (.*)$/, async (dept) => {
    dept = await assetRepository.makeString(dept);
	await assetRepository.selectAttributeType(dept);
})

When('Click on Add attribute button', async () => {
	await assetRepository.clickAddAttribute();
})

When('Click on delete attribute button', async () => {
	await assetRepository.deleteAttributeInTable();
})

When('Enable the Managed toggle', async () => {
	await assetRepository.toggleManaged(true);
})

When('Enable the Required toggle', async () => {
	await assetRepository.toggleRequired(true);
})

When('Click on Add button in Asset type', async () => {
	await assetRepository.clickAddAssetType();
})

When('Click on Cancel button in Asset type', async () => {
	await assetRepository.clickCancel();
})

When(/^I select Rate table from (.*)$/, async (fileName) => {
	await addAccountPage.selectRateTable(fileName)
})

When(/^I select Tax table from (.*)$/, async (fileName) => {
	await addAccountPage.selectTaxTable(fileName)
})
When(/^I select Tax table$/, async () => {
	await addAccountPage.selectFirstTaxTable()
})

When(/^I click on penalty toggle/, async () => {
	await addAccountPage.selectPenaltyToggle()
})

When(/^I enter values for service type (.*) having meterID as (.*), Beginning meter ID (.*) and deposit (.*)$/, async (serviceType,meterID, begMeterID, deposit) => {
	await addAccountPage.selectServiceFieldtoAddService(await addAccountPage.makeString(serviceType))
    if(!(await addAccountPage.makeString(serviceType) == "ELECTRIC")){
        await addAccountPage.enterMeterId(await addAccountPage.makeString(meterID))
        await addAccountPage.enterBeginningMeterId(await addAccountPage.makeString(begMeterID))
    }else{
        //await addAccountPage.enterServiceType(meterID);
    }
    
    await addAccountPage.enterDeposits(await addAccountPage.makeString(deposit))
	
})

When(/^Enable toggle "([^"]*)" from consideration section$/, async(service: string) => {
    await addAccountPage.enableAccountConsideration(service);
});

When(/^I enter Installment Amount of "([^"]*)"$/, async function (installmentAmount: string) {
  if (await addAccountPage.isVisible(addAccountPage.managePaymentAgreementOverlay)) {
    await addAccountPage.fillOutPaymentAgreementDetails(installmentAmount)
  } else {
    console.info('Payment Agreement is already enabled')
  }
});

When(/^Enter Total amount (.*) and select Eligible service as (.*) and Eligible amount (.*) and select (.*) and click on save$/, async(totAmount, elService, elAmount, service) => {
  if (await addAccountPage.isVisible(addAccountPage.manageEnergyAssistanceOverlay)) {
    await addAccountPage.enterTotalAmount(await addAccountPage.makeString(totAmount));
    await addAccountPage.enableElligibleService(await addAccountPage.makeString(elService))
    await addAccountPage.enterEligibleElectricityAmount(await addAccountPage.makeString(elAmount));
    await addAccountPage.selectNewCharge(await addAccountPage.makeString(service));
    await addAccountPage.clickSaveEnergyAssistance();
  } else {
    console.info('Energy Assistance is already enabled')
  }
});

When(/^I enter unique tax table name$/, async () => {
    await addTaxTable.clickOnAddtaxTableButton()
	await addTaxTable.enterTaxTableName()
});

When(/^I select service as "([^"]*)" in tax table$/, async (service) => {
	await addTaxTable.selectServiceTaxTable(service)
});
When(/^I select other fileds on the page$/, async () => {
	await addTaxTable.selectAllFields()
});
When(/^I select "([^"]*)" tax having tax method as "([^"]*)" with tax rate "([^"]*)"$/, async(taxRegion,taxMethod,rate) => {
    await addTaxTable.setTax(taxRegion,taxMethod,rate)
});

When(/^I click on Add button add tax table "([^"]*)"$/, async (filename)  => {
    await addTaxTable.recordAddTaxTableDetails(filename)
	await addTaxTable.clickAddButtonOnAddTaxTableoverlay()
});


When(/^Collect Account ID from Account Detail page and store in "([^"]*)"$/, async (filename) => {
	await accountDetails.recordAccountID(filename)
});


When(/^I enter values for non metered service type "([^"]*)"$/, async (serviceType) => {
	await addAccountPage.selectServiceFieldtoAddService(await addAccountPage.makeString(serviceType))
    await addAccountPage.enterDeposits(await addAccountPage.makeString("0"))
});

Then(/^Click on save button in Asset type$/,async () => {
	await assetRepository.clickSaveAttribute();
});
When(/^I filter payments as "([^"]*)"$/, async (filterOption) => {
	await accounts.selectPaymentsFilter(filterOption)
})
When(/^I Enter all mandatory fields and add approver employee for "([^"]*)"$/, async (filename) => {
	await addEmployee.navigateToAddEmployeeWithinHRTab()
    await addEmployee.enterUniqueEmployeeID(filename)
    await addEmployee.enterUniqueName(filename)
    await addEmployee.enterUniqueLastName()
    await addEmployee.clickOnAddButton()
 });
 When(/^I click on next buttonUbhub$/, async() => {
    await payrollSettings.clickOnPaginationNextUbhub();
})
When(/^I enter data in service location and account holder field by selecting relation type as "([^"]*)" from "([^"]*)" file$/, async (relationType: string, fileName: string) => {
	await addAccountPage.enterServiceLocationfromRecordedFile(fileName);
    await addAccountPage.apiEnterAccountHolderName(fileName);
    await addAccountPage.enterRelation(relationType);
})

When(/^I select the recently added employeeID via API for "([^"]*)"$/, async (filename) => {
	await addEmployee.searchAddedEmployee(filename);
    await addEmployee.selectRecordByEmployeeID(filename);
});
When(/^I Enter all mandatory fields and add employee via API for "([^"]*)"$/, async (filename) => {
	await addEmployee.apiEmployeeData(filename)
});
