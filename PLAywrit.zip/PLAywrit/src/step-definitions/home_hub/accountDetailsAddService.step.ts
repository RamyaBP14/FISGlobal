import { Given, Then, When } from "@cucumber/cucumber"
import { accountDetailsaddService } from "../../pom/ui/ub_hub/accountDetailsAddService";
import { AccountsPage } from '../../pom/ui/ub_hub/accountsPage';
const accounts = new AccountsPage();


let addService = new accountDetailsaddService()

/*Given(/^Navigate to accounts page$/, async function () {
    await addService.navigateToAccounts()
});*/
When('I clicked on a random visible Account', async function () {
    await accounts.clickOnRandomAccountFromMasterList() 
});
When(/^I select upfront configuration/, async function () {
    await addService.clickOnUpfrontBtn()
});
When(/^I click on Add service button$/, async function () {
    await addService.clickOnAddServiceBtn()
});
When(/^user  add service for "([^"]*)"$/, async function (serviceName,value) {
   await addService.addService(serviceName,value)
});
Then(/^Verify add sevice side navigation appears with given Field names FOR THE SERVICE "([^"]*)"$/,async function (serviceName) {
    await addService.ValidateAddServiceFields(serviceName)
});
Then(/^Verify all mandatory fields$/, async function () {
    await addService.validatemandatoryFields()
});
Then(/^Verify user can save or discard the service for "([^"]*)"$/, async function (serviceName) {
    await addService.validateSaveandDiscardServices(serviceName)
});
Then(/^Verify meter Id is unique$/, async function () {
    await addService.validateUniqueMeterID()
});
Then(/^Verify  non metered service for "([^"]*)"$/, async function (serviceName) {
    await addService.validateNonMeteredServices(serviceName)
});
Then(/^Verify sewer service for "([^"]*)"$/, async function (serviceName) {
    await addService.validateSewerServices(serviceName)
});