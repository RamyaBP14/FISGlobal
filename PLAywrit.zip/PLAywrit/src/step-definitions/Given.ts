
import {DataTable, Given, setDefaultTimeout, Then} from "@cucumber/cucumber"
import {HomePage} from "../pom/ui/hr_hub/homePage"
import { PayrollSettingsPage } from "../pom/ui/hr_hub/payRollSettings";
import { PayTypesPage } from "../pom/ui/hr_hub/payTypesPage";
import { JsonOperations } from "../utility/jsonOperations";
import { LoggerUtil } from "../utility/logger";
const {chromium, firefox, webkit} = require('playwright');
import { deductiblesPage } from "../pom/ui/hr_hub/deductiblesPage"
import { LeaveTypesPages } from "../pom/ui/hr_hub/LeaveTypesPages";
import { AssetRepositoryPage } from "../pom/ui/ops_hub/assetRepositoryPage";
import { AddAccountPage } from "../pom/ui/ub_hub/addAccountPage";
import { AccountsPage } from "../pom/ui/ub_hub/accountsPage";
import { AccountDetailsSummaryPage } from "../pom/ui/ub_hub/accountDetailsSummaryPage";
import { AccountServicesPage } from "../pom/ui/ub_hub/accountDetailsServicesPage";
import { AddEmployee } from "../pom/ui/hr_hub/addEmployee";
import { AddTaxTablePage } from "../pom/ui/ub_hub/addTaxTablePage";
import { SetupFuelAdjustment } from "../pom/ui/ub_hub/setupFuelAdjustmentPage";
import { dbUtil } from "../utility/dbUtil";
import { MeterIDPage } from "../pom/ui/ops_hub/meterID";
import { CommonUtils } from "../utility/commonUtils";
import { AccountPayableVendorSetupPage } from "../pom/ui/finance_hub/accountPayableVendorSetup";
import { Meter } from '../API/objects/ops_hub/meter';
import { Meters } from '../API/classes/ops_hub/meters';
import { UbRateTables } from '../API/classes/ub_hub/ubRateTable';
import { UbTaxTables } from '../API/classes/ub_hub/ubTaxTable';
import { UbRateTable } from '../API/objects/ub_hub/ubRateTable';
import { UbTaxTable } from '../API/objects/ub_hub/ubTaxTable';
import { LeaveTypePageClass } from "../pom/ui/hr_hub/LeavesTypes";

let leaveTypeClass = new LeaveTypePageClass();
let db = new dbUtil()
let homepage = new HomePage()
let paytypes = new PayTypesPage()
let deductiblepage=new deductiblesPage()
let payrollSettings = new PayrollSettingsPage()
let log = new LoggerUtil()
let jsonutil = new JsonOperations()
let leaveType=new LeaveTypesPages()
let assetRepository = new AssetRepositoryPage()
let addAccountPage = new AddAccountPage()
let accounts = new AccountsPage()
let accountDetails = new AccountDetailsSummaryPage()
let accountServices = new AccountServicesPage()
let addEmployee = new AddEmployee()
let addTaxTable =new AddTaxTablePage()
let setupFuelAdjustment =new SetupFuelAdjustment()
let meterID = new MeterIDPage()
let jsonUtil = new JsonOperations();
const apiRateTable = new UbRateTables();
const apiTaxTable = new UbTaxTables();
const apiMeter = new Meters();

let meterId: string;
let meter: Meter;
let rateTable: UbRateTable | undefined;
let taxTable: UbTaxTable | undefined;
let vendorSetup = new AccountPayableVendorSetupPage();
let commonUtils = new CommonUtils();
const options = {
 headless: false, };

Given(/^I navigate to Asset Repository$/, async () => {
	await assetRepository.navigatetoAssetRepository()
})


Given(/^I navigate to New Service Location page$/, async () => {
    await assetRepository.navigatetoNewServiceLocation()
})


Given(/^I navigate to New Account page$/, async () => {
	await addAccountPage.navigateToNewAccount() 
})


Given(/^I create new Service Location for new account page$/, async () => {
	await assetRepository.createNewServiceLocation("saveAsDraft","2","2")
})


Given(/^Naviagte to Services page for new account to add new Service for "([^"]*)"$/, async (Service) => {
	const meterID_Value = await meterID.addMeterIDforNewAccount(Service)
    await jsonUtil.appendJsonData(`${Service}.json`,{MeterID:meterID_Value})
    await addAccountPage.navigateToServices("addService","Thomas","Property Owner","2","3")
})

Given(/^Navigate to Services page for new account to validate back button$/, async () => {
	await addAccountPage.navigateToServices("backButton","Thomas","Property Owner","2","3")
})


Given(/^Naviagte to Services page for new account to validate move-in request$/, async () => {
	const meterID_Value = await meterID.addMeterIDforNewAccount("ELECTRIC")
    await jsonUtil.appendJsonData(`ELECTRIC.json`,{MeterID:meterID_Value})
    await addAccountPage.navigateToServices("InitiatemoveIn","Thomas","Property Owner","2","3")
})



Given(/^Naviagte to Services page for new account to validate Save as Draft for service "([^"]*)"$/, async (serviceType) => {
	const meterID_Value = await meterID.addMeterIDforNewAccount(serviceType)
    await jsonUtil.appendJsonData(`${serviceType}.json`,{MeterID:meterID_Value})
    await addAccountPage.navigateToServices("saveAsDraft","Thomas","Property Owner","2","3")
});


Given(/^I add a new Meter for service "([^"]*)"$/, async function (service: string) {
  meterId = await meterID.addMeterIDforNewAccount(service)
  await jsonUtil.appendJsonData('newMeter.json', { MeterID: meterId })
});


// Given(/^I Add new Account for service electric$/, {timeout: 100*7000},async () => {
// 	await accountDetails.addNewAccount(
//     "AccountDetailsValidations", 
//     "Thomas", 
//     "Property Owner",
//     "ELECTRIC", 
//     "Test", 
//     "All Tax Test", 
//     meterId,
//     "71",
//     "1",
//     "3"
//   )
// });
Given(/^I Add new Account for service "([^"]*)"$/, {timeout: 100*7000},async (param1) => {
	await accountDetails.addNewAccount(
    "AccountDetailsValidations", 
    "Thomas", 
    "Property Owner",
    param1, 
    "Test", 
    "All Tax Test", 
    meterId,
    "71",
    "1",
    "3"
  )
});


Given(/^I Add new Account for "([^"]*)" and for Service "([^"]*)", route "([^"]*)" and cycle "([^"]*)"$/,{timeout: 500*1000},async (fileName,Service,route,cycle) => {
  const meterID_Value = await meterID.addMeterIDforNewAccount(Service)
  await jsonUtil.appendJsonData(`${fileName}.json`,{MeterID:meterID_Value})
	await accountDetails.addNewAccount(
    fileName, 
    "Thomas", 
    "Property Owner",
    Service, 
    "Test Table", 
    "Tax Rate test UI",
    meterID_Value,
    "71",
    route,
    cycle
  )
	
});


Given(/^I Add new Account for "([^"]*)" and for Service "([^"]*)", route "([^"]*)" and cycle "([^"]*)" for Vendor "([^"]*)"$/, {timeout: 500*1000}, async (fileName,Service,route,cycle,MR_Vendor) => {
	const meterID_Value = await meterID.addMeterIDWithVendorforNewAccount(Service,MR_Vendor)
  await jsonUtil.appendJsonData(`${fileName}.json`,{MeterID:meterID_Value})
	await accountDetails.addNewAccount(
    fileName, 
    "Thomas", 
    "Property Owner",
    Service, 
    "Test Table", 
    "Tax Rate test UI",
    meterID_Value,
    "71",
    route,
    cycle
  )
});

Given(/^Naviagte to Services page for new account to add new Non Metered Service for "([^"]*)"$/, async (Service) => {
	await addAccountPage.navigateToServices("addService","Thomas","Property Owner","2","3")
});

Given(/^I set All Services Account filter to "([^"]*)"$/, async function (service: string) {
  await accounts.setAllServicesFilter(service);
});

Given(/^I set Account Balance filter to "([^"]*)"$/, async function (filterOption: string) {
  await accounts.setAccountBalanceFilter(filterOption);
});

Given(/^I set Account Type filter to "([^"]*)"$/, async function (filterOption: string) {
  await accounts.setAccountTypeFilter(filterOption);
});

Given(/^I add new FrontDesk Account$/, async function (data: DataTable) {
  let accountData = data.rowsHash();
  await accounts.addNewFDAccount({firstName: accountData.firstName, lastName: accountData.lastName});
})

Given(/^I add new Service Location with a random address$/, async function (data: DataTable) {
  let serviceLocationData = data.rowsHash();
  await accounts.addNewServiceLocation({
    propertyOwner: serviceLocationData.propertyOwner,
    propertyType: serviceLocationData.propertyType
  })
})

Given(
    /^I navigate to Pay Types$/,
    async function () {
        await paytypes.NavigateToPayTypes()
        
    }
)

Given(
    /^I am on the Deductibles_Benefits page$/,
    async function () {
        await payrollSettings.navigateToPayrollSettings()
        await deductiblepage.NavigateToDeductibles();
        
    }
)

Given(
    /^I navigate to Add Pay Types$/,
    async function () {
        await paytypes.NavigateToAddPayTypes()
        
    }
)

Given(
    /^I navigate to Payroll Settings page$/,
    async function () {
        await payrollSettings.navigateToPayrollSettings()
        
    }
)

Given(
    /^Dummy Json$/,
     async function() {
        // await jsonutil.updateData("data.json",{Name:"Ratnesh",Project:"RN"})    
        // const jsonData = await jsonutil.readData("data.json")
        // console.log(jsonData) 
        // console.log(jsonData.Project) 
        // let newData = {"Name":"Vishnu", "Project":"gWorks", "Company":"ThinkBridge", "Year":"2023"}  
        // await jsonutil.createJsonData("JsonDataCreation.json",newData) 
          });
          
          
Given(/^I navigate to pay types tab$/, 
    async function() {
            await payrollSettings.navigateToPayTypePage()
        })

Given(/^I navigate to "([^"]*)" tab$/, async (tabName) => {
	await payrollSettings.naviagtetoPayrollSettingsTab(tabName)
})

Given(/^I Navigate to Leave type page$/,
async function(){
   //await payrollSettings.navigateToAddLeaveTypePage();

    await leaveType.NavigateToLeaveType();
}
)
Given(/^I navigate to allowance type record from master list of pay type$/, async () => {
	await paytypes.navigatetoAllowanceTypeRecord("allowanceType")
})
Given(/^I Navigate to Leave type$/,
async function(){
   //await payrollSettings.navigateToAddLeaveTypePage();

    await leaveType.NavigateToLeaveType1();
}
)

Given(/^I navigate to any existing paytype record$/, async () => {
	await paytypes.createRecordandNavigate("paytypeRecord")
})


Given(/^I navigate to any existing paytype record to validate date Range$/, async () => {
	await paytypes.createRecordandNavigate("dateRange")
})


Given(/^I navigate to any existing paytype record for updated record$/, async () => {
	await paytypes.createRecordandNavigate("paytypeUpdatedRecord")
})


Given(/^I create new Service Location for new account page for scenario "([^"]*)"$/, async (filename) => {
	await assetRepository.createNewServiceLocation(filename,"2","2")
});


Given(/^Naviagte to Services page for new account$/, async() => {
	await addAccountPage.navigateToServices("LabelValidationForAddService","Thomas","Property Owner","2","3")
})

Given(/^Navigate to Services page for new account to validate services page component$/, async () => {
	await addAccountPage.navigateToServices("servicePageComponent","Thomas","Property Owner","2","3")
})

Given(/^Naviagte to Services page for new account to validate delete Service$/, async () => {
	const meterID_Value = await meterID.addMeterIDforNewAccount("ELECTRIC")
    await jsonUtil.appendJsonData(`ELECTRIC.json`,{MeterID:meterID_Value})
   const meterID_Value1 = await meterID.addMeterIDforNewAccount("WATER")
    await jsonUtil.appendJsonData(`WATER.json`,{MeterID:meterID_Value1})
    await addAccountPage.navigateToServices("deleteButton","Thomas","Property Owner","2","3")
})

Given(/^Naviagte to Services page for new account to validate update service$/, async () => {
	const meterID_Value = await meterID.addMeterIDforNewAccount("ELECTRIC")
    await jsonUtil.appendJsonData(`ELECTRIC.json`,{MeterID:meterID_Value})
    await addAccountPage.navigateToServices("updateService","Thomas","Property Owner","2","3")
})

Given(/^Navigate to Accounts page$/, async () => {
	//await accounts.naviagateToAccountsPage()
    await accounts.recordAccountDetailsFromMasterList("5","accountPageDetailsHeader")
})  


Given(/^I Add new Account$/, {timeout: 200*1000}, async () => {
	await accountDetails.addNewAccount(
    "AccountDetailsValidations", 
    "Thomas", 
    "Property Owner", 
    "WATER", 
    "Test", 
    "All Tax Test", 
    meterId,
    "71",
    "2",
    "3"
  )
})

Given(/^I Add new Account for "([^"]*)"$/,{timeout: 100*7000}, async (fileName) => {
    const meterID_Value = await meterID.addMeterIDforNewAccount("WATER")
    await jsonUtil.appendJsonData(`${fileName}.json`,{MeterID:meterID_Value})
      await accountDetails.addNewAccount(
      fileName, 
      "Thomas", 
      "Property Owner", 
      "WATER", 
      "Test Table", 
      "Tax Rate test UI",
      meterID_Value,
      "71",
      "1",
      "3"
    )
  });
// Given(/^I Add new Account for service electric$/, {timeout: 100*7000},async () => {
// 	await accountDetails.addNewAccount(
//     "AccountDetailsValidations", 
//     "Thomas", 
//     "Property Owner",
//     "ELECTRIC", 
//     "Test", 
//     "All Tax Test", 
//     meterId,
//     "71",
//     "1",
//     "3"
//   )
// });



Given(/^Navigate to UB Accounts Page$/, async () => {
    await accounts.naviagateToAccountsPage()
})



Given(/^Navigate to Employee page$/, async () => {
	// await db.runQuery(query)
    await addEmployee.navigateToEmployeesTab()
})


Given(/^Navigate to add employee window$/, async () => {
	await addEmployee.navigateToAddEmployeesTab()
})
Given(/^I navigate to Tax Table page$/, async() => {
	await addTaxTable.navigateToTaxTable()
})

Given(/^I navigate to Tax Table overlay$/, async() => {
	await addTaxTable.navigateToAddTaxTableOverlay()
})
Given(/^I navigate to Fuel Adujustment set up page$/, async() => {
	await setupFuelAdjustment.navigateToFuelAdujutmentTab();
})
Given(/^Naviagte to Services page for new account to add new Non Metered Service for "([^"]*)"$/, async (Service) => {
  await addAccountPage.navigateToServices("addService","Thomas","Property Owner","2","3");
});

Given(/^I navigate to Settings page$/, async function() {
  await payrollSettings.navigateToPayrollSettings();
})

Given(/^User logs out of current role$/, async function() {
    await commonUtils.logOutCurrentUser()
});

Given(/^I add a new Meter for service "([^"]*)" via api$/, async function(serviceName: string) {
  meter = await apiMeter.createMeter(serviceName); 
  meterId = meter.meterId; 
  await jsonUtil.appendJsonData('newMeter.json', { MeterID: meterId })
});
    
Given(/^I Add new Account for service "([^"]*)" by fetching the data from api or database$/, {timeout: 100*7000}, async (serviceName) => {
  rateTable = await apiRateTable.getRateTable(serviceName);
  taxTable = await apiTaxTable.getTaxTable(serviceName);
  const rateTableName = String(rateTable?.rateTableName);
  const taxTableName = String(taxTable?.taxTableName);
  await accountDetails.apiAddNewAccountViaUbAccount(
      "AccountDetailsValidations",  
      "Property Owner",
      serviceName, 
      rateTableName, 
      taxTableName, 
      meterId,
      "71"
  )
});
     
Given(/^I add a new deduction via API for "([^"]*)"$/, async function(fileName: string) {
   await deductiblepage.apiAddDeduction(fileName);
});

Given(/^I add the Pay Type via API$/, async function () {
  await paytypes.apiAddPayType();
});

Given(/^I add the FMLA LeaveType via API for "([^"]*)"$/, async function(fileName: string) {
  await leaveTypeClass.apiAddLeaveType(fileName);
});