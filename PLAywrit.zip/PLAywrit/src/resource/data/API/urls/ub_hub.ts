export enum ubUrls {
  POST_UbAccount = 'u/api/v1/ub/Accounts/AddUtilityAccount',
  POST_AddRateTable = '/u/api/v1/ub/GlobalRateTable/AddGlobalRateTable',
  PUT_AddServices = '/u/api/v1/ub/Service/AddOrUpdateServices',
  POST_AddTaxTable = '/u/api/v1/ub/GlobalTaxTable/AddGlobalTaxTable',
  GET_FHBankDetails = '/u/api/v1/ub//GLDistributionSettings/FHBankList',
  POST_AddOrUpdateGlDistribution = '/u/api/v1/ub/GLDistributionSettings/AddOrUpdateGLDistributionSetting',
  POST_AddPenaltyTable = '/u/api/v1/ub/GlobalPenaltyTable/AddGlobalPenaltyTable',
  POST_AddServicesToAccount = '/u/api/v1/ub/ServiceRequest/AddServiceToAccount'
}