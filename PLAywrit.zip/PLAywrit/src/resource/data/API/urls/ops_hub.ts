export enum opsUrls {
  POST_Meter = '/o/api/v1/ops/Asset/Meter',
  POST_PublicUser = '/o/api/v1/ops/PublicUser',
  POST_ServiceLocation = '/o/api/v1/ops/ServiceLocation'
}