export enum hrHubUrls {
    POST_AddEmployee = '/h/api/v1/hr/Employee/Add',
    POST_AddCostCenter = '/h/api/v1/hr/CostCenter',
    POST_AddPayType = '/h/api/v1/hr/PayType',
    POST_AddLeaveType = '/h/api/v1/hr/LeaveType',
    POST_VendorSetUp = '/h/api/v1/hr/Vendor',
    POST_AddHoliday = '/h/api/v1/hr/Holiday/SaveEmployeeHoliday',
    POST_AddHolidayPolicy = '/h/api/v1/hr/Holiday/SaveHolidayPolicy',
    POST_AddDeduction = '/h/api/v1/hr/Deduction',
    POST_EmployeeDeductions = '/h/api/v1/hr/EmployeeDeductions' 
  }