 export enum fhHubUrls {
  POST_AddVendor = '/f/api/v1/fh/FHVendorSetup/SaveVendorDetails',
  POST_AddBankAccount = '/f/api/v1/fh/FHBankAccountSetup/AddBankAccount',
  POST_AddDistributionId = '/f/api/v1/fh/FHDistributionIDSetup/AddNewDistributionIDSetupDetails',
  POST_AddPaymentType = '/f/api/v1/fh/FHPaymentTypeDetails/AddNewPaymentType',
  POST_AddDepartment = '/f/api/v1/fh/FHDepartmentAccountBreakData/Add',
  POST_AddGlAccount = '/f/api/v1/fh/FHAccountSetup/Add'
}