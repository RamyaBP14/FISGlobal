//import reporter, {Options} from "cucumber-html-reporter"
const fs = require('fs').promises;
var today = new Date()
var reporter = require('cucumber-html-reporter');
var todayDate = today.getFullYear() + "-" + (today.getMonth()+1) + "-" + (today.getDate());
const jsondataDir = 'src/reporter/';
const configfileName = 'configData.json';

// function readData(fileName) {
//     return fs.readFile(`${jsondataDir}${fileName}`, 'utf-8')
//       .then((fileData) => {
//         let jsonData = JSON.parse(fileData);
//         return jsonData;
//       })
//       .catch((err) => {
//         console.error(err);
//       });
//   }     

class cucumberOperations{
async readData(fileName) {
    try {
      // Read the JSON file
      const fileData = await fs.readFile(`${jsondataDir}${fileName}`, 'utf-8');
  
      // Parse the JSON data
      let jsonData = JSON.parse(fileData);
      return jsonData;
    } catch (err) {
      console.error(err);
    }
  }

async generateReport(){
    const jsonData = await this.readData(configfileName)
    console.log(jsonData.testEnvironment)
    console.log(jsonData.cityName)
    var options = {
        theme: 'bootstrap',   //['bootstrap', 'hierarchy', 'foundation', 'simple']
        jsonFile: 'src/resources/reports/cucumber-report.json',
        output: "./src/resources/results/"+todayDate+"/gWorks_Automation/cucumber_report.html",//'src/resources/reports/cucumber_report.html',      //process.env.LogPath+'/cucumber_report.html',
        reportSuiteAsScenarios: true,
        scenarioTimestamp: true,
        screenshotsDirectory: 'src/resources/results/'+todayDate+'/gWorks_Automation/report_screenshot/',
        noInlineScreenshots:true,
        storeScreenshots: true,
        launchReport: true,
        metadata: {
            "App Version":"gWorks",
            "Vendor": `${jsonData.cityName}`,
            "Test Environment": `${jsonData.testEnvironment}`,
        },
        failedSummaryReport: true
    
    };
    await reporter.generate(options);
}

}
  
// var options = {
//     theme: 'bootstrap',   //['bootstrap', 'hierarchy', 'foundation', 'simple']
//     jsonFile: 'src/resources/reports/cucumber-report.json',
//     output: "./src/resources/results/"+todayDate+"/gWorks_Automation/cucumber_report.html",//'src/resources/reports/cucumber_report.html',      //process.env.LogPath+'/cucumber_report.html',
//     reportSuiteAsScenarios: true,
//     scenarioTimestamp: true,
//     screenshotsDirectory: 'src/resources/results/'+todayDate+'/gWorks_Automation/report_screenshot/',
//     noInlineScreenshots:true,
//     storeScreenshots: true,
//     launchReport: true,
//     metadata: {
//         "App Version":"gWorks",
//         "Test Environment": "jsonData",
//         "Browser": "jsonData",
//         "Platform": "Windows 10",
//         "Parallel": "Scenarios",
//         "Executed": "Remote"
//     },
//     failedSummaryReport: true

// };

let cucumReport = new cucumberOperations()
cucumReport.generateReport()


//reporter.generate(options);