#!/bin/bash
# Get the current date in yyyy-mm-dd format
todayDate=$(date +"%Y-%-m-%-d")

# Define the path to the file you want to upload
html_file="./src/resources/results/$todayDate/gWorks_Automation/cucumber_report.html"

# Check if the HTML file exists
if [ -e "$html_file" ]; then
  # Extract the "Passed" value using grep and sed
  passed_value=$(grep -o '<span class="label label-success".*<\/span>' "$html_file" | sed -n 's/.*Passed: \([0-9]\+\)<\/span>/\1/p')

  # Extract the "Failed" value using grep and sed
  failed_value=$(grep -o '<span class="label label-danger".*<\/span>' "$html_file" | sed -n 's/.*Failed: \([0-9]\+\)<\/span>/\1/p')

  # Extract the "Scenarios" value using grep and sed
 #scenarios_value=$(xmlstarlet sel -t -v '//div[@id='piechart_scenarios']' "$html_file" | sed -n 's/[^0-9]*\([0-9]\+\) Scenarios/\1/p')
scenarios_value=$((passed_value + failed_value))

  # Print the extracted values
  echo "Passed Value: $passed_value"
  echo "Failed Value: $failed_value"
  echo "Scenarios Value: $scenarios_value"
else
  echo "HTML file '$html_file' not found."
fi

# Define your Slack API token and channel ID
SLACK_API_TOKEN="xoxb-5115602510288-5869721550198-PHQc4ChqkBUIjyZQJt1nSl9A"
SLACK_CHANNEL="C05QDDJBHB5"

# Define the message you want to send
MESSAGE="Total Test Executed: $scenarios_value Total Test Passed: $passed_value Total Test Failed : $failed_value"

# Make a POST request to Slack's chat.postMessage API endpoint
curl -X POST -H "Content-Type: application/json" -H "Authorization: Bearer $SLACK_API_TOKEN" \
  --data "{
    \"channel\": \"$SLACK_CHANNEL\",
    \"text\": \"*$MESSAGE*\"
  }" \
  https://slack.com/api/chat.postMessage