#!/bin/bash

npm run report
echo "Report Generated successfully"

# Define your Slack API token and channel ID
# TODO: Move to AWS Secrets Manager
SLACK_API_TOKEN="xoxb-6303800404119-6950978557824-s3jnigCqv2r3ztdq2LDLxxgd"

# Smoke Tests
SMOKE_CHANNEL="C06SU8YGHEJ" # smoketest_automation-results

# Hub-specific Tests
UB_CHANNEL="C06TDHQHJPK"  # ubhub_automation-results
HR_CHANNEL="C06SL9M46PR"  # hrhub_payrollcalculation-results
PR_CHANNEL="C06SL9M46PR"  # hrhub_payrollcalculation-results
FH_CHANNEL="C06SU6KK0FQ"  # financehub_automation-results
OPS_CHANNEL="C06TDHG5Q01" # opshub_automation-results

# Capture the test suite name from the argument
testSuiteName="$1"

# Customize the message based on testSuiteName
case "$testSuiteName" in
  "ubSmoke" | "hrSmoke" | "opsSmoke" | "financeSmoke")
    Test="Daily Smoke Test for Ub hub"
    SlackChannel="$SMOKE_CHANNEL"  # Specify the Slack channel for this test suite
    ;;
  "ubhub")
    Test="UB Hub Test"
    SlackChannel="$UB_CHANNEL"  # Specify the Slack channel for this test suite 
    ;;
  "hrhub")
    Test="HR Hub Test"
    SlackChannel="$HR_CHANNEL"  # Specify the Slack channel for this test suite 
    ;;
  "opshub")
    Test="OPS Hub Test"
    SlackChannel="$OPS_CHANNEL"  # Specify the Slack channel for this test suite 
    ;;
  "financehub")
    Test="Finance Hub Test"
    SlackChannel="$FH_CHANNEL"  # Specify the Slack channel for this test suite 
    ;;
  "State"*)
    Test="Payroll Calculation Scenarios for State Tax"
    SlackChannel="$HR_CHANNEL"  # Specify the Slack channel for this test suite
    ;;
  "FederalTax"*)
    Test="Payroll Calculation Scenarios for Federal Tax"
    SlackChannel="$HR_CHANNEL"  # Specify the Slack channel for this test suite
    ;;
  *)
    # Use the default message for other test suite names
    ;;
esac

# Check if the testSuiteName starts with specific prefixes
if [[ "$testSuiteName" == ub* ]]; then
  Module="UB Hub"
elif [[ "$testSuiteName" == hr* ]]; then
  Module="HR Hub"
elif [[ "$testSuiteName" == finance* ]]; then
  Module="Finance Hub"
elif [[ "$testSuiteName" == ops* ]]; then
  Module="OPS Hub"
fi

# Print the extracted values
echo "TagName: $testSuiteName"
echo "Module: $Module"
echo "Test Suite name: $Test"

# Get the current date in yyyy-mm-dd format
todayDate=$(date +"%Y-%-m-%-d")

# Define the path to the file you want to upload
html_file="./src/resources/results/$todayDate/gWorks_Automation/cucumber_report.html"

# Check if the HTML file exists
if [ -e "$html_file" ]; then
  # Extract the "Passed" value using grep and sed
  passed_value=$(grep -o '<span class="label label-success".*<\/span>' "$html_file" | sed -n 's/.*Passed: \([0-9]\+\)<\/span>/\1/p')

  # Extract the "Failed" value using grep and sed
  failed_value=$(grep -o '<span class="label label-danger".*<\/span>' "$html_file" | sed -n 's/.*Failed: \([0-9]\+\)<\/span>/\1/p')

  # Extract the "Scenarios" value using grep and sed
  scenarios_value=$((passed_value + failed_value))

  # Print the extracted values
  echo "Passed Value: $passed_value"
  echo "Failed Value: $failed_value"
  echo "Scenarios Value: $scenarios_value"
else
  echo "HTML file '$html_file' not found."
fi

# Specify the JSON file path
json_file="./src/reporter/configData.json"  # file path

# Check if the specified file exists
if [ ! -f "$json_file" ]; then
  echo "File not found: $json_file"
  exit 1
fi

# Read and extract values from the JSON file using jq
testEnvironment=$(jq -r '.testEnvironment' "$json_file")
city=$(jq -r '.cityName' "$json_file")

# Display the extracted values
echo "testEnvironment: $testEnvironment"
echo "city: $city"

# Define the message you want to send
MESSAGE=":chart_with_upwards_trend:\`-------------------- *NEW Test Execution Details* --------------------\`:chart_with_upwards_trend:
*Module*:                                 _$Module _
*Test Suite Name*:                  _$Test _
*Vendor*:                                  _$city _
*Test Environment*:                 _$testEnvironment _
*Total Test Executed*:             _$scenarios_value _
*Test Passed*:                          _$passed_value _
*Test Failed*:                           _$failed_value _
"

# Extract the timestamp from the response
timestamp=$(echo "$response" | jq -r '.ts')

# Define the path to the file you want to upload
FILE_PATH="./src/resources/results/$todayDate/gWorks_Automation/cucumber_report.html"

# Make a POST request to Slack's files.upload API endpoint to attach the HTML file
curl -F "token=$SLACK_API_TOKEN" -F "channels=$SlackChannel" -F "file=@$FILE_PATH" -F "filename=cucumber_report.html" -F "title=HTML Cucumber Report" -F "initial_comment=$MESSAGE _Please find the attached HTML Cucumber Report for more details._" -F "thread_ts=$timestamp" \
  https://slack.com/api/files.upload
