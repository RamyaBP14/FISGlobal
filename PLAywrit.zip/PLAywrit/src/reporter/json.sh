#!/bin/bash
# Specify the JSON file path
json_file="./src/reporter/configData.json"  # file path


# Check if the specified file exists
if [ ! -f "$json_file" ]; then
  echo "File not found: $json_file"
  exit 1
fi

# Read and extract values from the JSON file using jq
testEnvironment=$(jq -r '.testEnvironment' "$json_file")
city=$(jq -r '.cityName' "$json_file")

# Display the extracted values
echo "testEnvironment: $testEnvironment"
echo "city: $city"
