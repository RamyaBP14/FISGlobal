import { expect } from '@playwright/test'
import { LoggerUtil } from '../../../utility/logger'
import { PageBase } from '../../../utility/PageBase'
import { PayrollSettingsPage } from '../hr_hub/payRollSettings';
import { CommonUtils } from '../../../utility/commonUtils';
import { accountBreakActivityPage } from './accountBreakActivtyPage';
import { getLocator } from '../../../utility/jsonOperations';
import { AddDistributionIds } from '../../../API/classes/fh_hub/addDistributionIdSetUp';

const apiDistributionId = new AddDistributionIds();
let payrollSetting = new PayrollSettingsPage()
let accountBreakActivity = new accountBreakActivityPage()
let commonUtil = new CommonUtils()
let log = new LoggerUtil()
let glACCFunds:any
let count:any 
let glACCFund:any
export class DistributionIdSteupPage extends PageBase {
    readonly locatorPath = 'finance_hub/financehub_locators'

    async navigateToDistributionIDSetupPage() {
        await this.wait(2000)
        await this.waitForLoad()
        // await this.click(this.FinanceTab)
        // await this.wait(2000)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.financeHubSettings'))
        await this.wait(2000)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.financeAccounting'))
        await this.wait(2000)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.financeDistributionIDSetup'))
        await this.wait(2000)
    }
    async verifyDistributionIDTableHeader() {
        await this.verifyMultipleItemsInList(getLocator(this.locatorPath,'DistributionIdSteupPage.tableHeader'), ["Distribution ID", "Bank #", "GL Cash Account", "GL Accounts Payable", "Status", "Created Date"])
    }
    async verifySearchBox() {
        await this.verifyVisibility(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'), "Visible");
    }
    async verifyAddButton() {
        await this.verifyVisibility(getLocator(this.locatorPath,'DistributionIdSteupPage.addDistributionIDButton'), "Visible")
    }
    async verifyDataInGridOfSetupTab() {
        await this.verifyVisibility(getLocator(this.locatorPath,'DistributionIdSteupPage.firstRowInGrid'), "Visible")
    }
    async getDistributionIDRecordFromMasterList(loc, recordNumber) {
        global.distributionIDRecord = (await this.getText(`(${loc})[${recordNumber}]`)).trim()
        return global.distributionIDRecord
    }
    //department code
    async verifyExistingRecordofDepartmentCode() {
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'), global.distributionIDRecord)
        await this.pressEnter()
        await this.verifyText(getLocator(this.locatorPath,'DistributionIdSteupPage.distributionID_rowRecord'), global.distributionIDRecord)
    }
    async searchDistributionCodeFromMasterList(filename, recordNumber) {
        let distributionCode = await this.getDistributionIDRecordFromMasterList(getLocator(this.locatorPath,'DistributionIdSteupPage.distributionID_rowRecord'), recordNumber)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'))
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'), distributionCode)
        await this.pressEnter()
    }
    //bankID
    async searchBankIDFromMasterList(filename, recordNumber) {
        let bankID = await this.getDistributionIDRecordFromMasterList(getLocator(this.locatorPath,'DistributionIdSteupPage.bankID_rowRecord'), recordNumber)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'))
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'), bankID)
        await this.pressEnter()
    }
    async verifyExistingRecordofBankID() {
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'), global.distributionIDRecord)
        await this.pressEnter()
        await this.verifyText(getLocator(this.locatorPath,'DistributionIdSteupPage.bankID_rowRecord'), global.distributionIDRecord)
    }
    //GLCash
    async searchwithGLCashAccFromMasterList(filename, recordNumber) {
        let GLCashAcc = await this.getDistributionIDRecordFromMasterList(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccount_rowRecord'), recordNumber)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'))
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'), GLCashAcc)
        await this.pressEnter()
    }
    async verifyExistingRecordofGLCashAcc() {
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'), global.distributionIDRecord)
        await this.pressEnter()
        await this.verifyText(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccount_rowRecord'), global.distributionIDRecord)
    }
    //GLAP
    async searchwithGLAccPayableFromMasterList(filename, recordNumber) {
        let glAccPayable = await this.getDistributionIDRecordFromMasterList(getLocator(this.locatorPath,'DistributionIdSteupPage.glAccPayable_rowRecord'), recordNumber)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'))
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'), glAccPayable)
        await this.pressEnter()
    }
    async clickFirstRow() {
        if(await this.isVisible(getLocator(this.locatorPath,'DistributionIdSteupPage.firstRowInGrid'))){
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.firstRowInGrid'))
        await commonUtil.waitForLoader()
        }else{
            await this.clickAddDistributionIDButton()
            await this.addSetupID()
            await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.firstRowInGrid'))
        await commonUtil.waitForLoader()
        }
    }
    async verifyExistingRecordofGLAccPayable() {
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'), global.distributionIDRecord)
        await this.pressEnter()
        await this.verifyText(getLocator(this.locatorPath,'DistributionIdSteupPage.glAccPayable_rowRecord'), global.distributionIDRecord)
    }
    async updateExistingRecords() {
        if (await this.isElementEnabled(getLocator(this.locatorPath,'DistributionIdSteupPage.deleteButton'))) {
            await log.info("Distribution ID is not associated to GL Account and AP Module")
            await this.verifyButtonState(getLocator(this.locatorPath,'DistributionIdSteupPage.deleteButton'), "Enabled")
        } else {
            await log.info("Distribution ID is associated to GL Account and AP Module, cannot be deleted.")
        }
        if (await this.isElementEnabled(getLocator(this.locatorPath,'DistributionIdSteupPage.statusToggle'))) {
            await this.isChecked(getLocator(this.locatorPath,'DistributionIdSteupPage.statusToggle'))
            await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.statusToggle'))
            await this.isChecked(getLocator(this.locatorPath,'DistributionIdSteupPage.statusToggle'))
        }
        await this.wait(2000)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountID_Inputtext'))
        //let glAccId2=await this.getText(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountName_InputValue'))
        //await log.info(glAccId2)
            await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.secondElementInDropdown'))
            await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountID_Inputtext'));
        let glAccId=await this.getText(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountName_InputValue'))
        glACCFunds=glAccId.substring(0,3)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.firstElement'))
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.glAPAccountID_Input'))
        await this.wait(2000)
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.glAPAccountID_Input'),glACCFunds);
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.secondElementInDropdown'))
        await this.verifyButtonState(getLocator(this.locatorPath,'DistributionIdSteupPage.updateButton'), "Enabled")
    }
    async clickUpdateButton() {
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.updateButton'))
    }
    async verifyToasterMessage(message) {
        await commonUtil.toasterValidation(message)
    }
    async verifyDisplayedPages(buttonName, pageNumber) {
        const status = await this.getText(getLocator(this.locatorPath,'DistributionIdSteupPage.currentPage'))
        if (status == pageNumber) {
            await log.info("Required page is displayed")
        }
        else {
            await log.info("you are still in same page")
        }
    }
    async verifyShownPageNumber(numberofItems) {
        const currentPageSelected = await this.getInnerText(getLocator(this.locatorPath,'DistributionIdSteupPage.currentShowPage'))
        const showEntriesNumber = await this.getInnerText(getLocator(this.locatorPath,'DistributionIdSteupPage.showedEntries'))
        if (currentPageSelected < showEntriesNumber) {
            await this.wait(2000)
            await log.info("Number of items displayed in this page are only " + showEntriesNumber)
        }
        else {
            await this.wait(2000)
            await this.verifyNumberOfItem(getLocator(this.locatorPath,'DistributionIdSteupPage.numberofRowsinPage'), numberofItems)
            if (currentPageSelected == numberofItems) {
                await this.wait(2000)
                if (await currentPageSelected == showEntriesNumber) {
                    await log.info("Number of items displayed are" + showEntriesNumber)
                }
            }
        }
    }
    async clickAddDistributionIDButton() {
        await this.wait(2000)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.addDistributionSetupButton'))
    }
    async verifyAddDistributionSetupID() {
        await this.verifyText(getLocator(this.locatorPath,'DistributionIdSteupPage.sideoverlay_heading'), "Add Distribution ID")
        await this.verifyVisibility(getLocator(this.locatorPath,'DistributionIdSteupPage.distributionIDField'), "Visible")
        await this.verifyVisibility(getLocator(this.locatorPath,'DistributionIdSteupPage.bankID_Inputtext'), "Visible")
        await this.verifyVisibility(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountID_Inputtext'), "Visible")
        await this.verifyVisibility(getLocator(this.locatorPath,'DistributionIdSteupPage.glAPAccountID_Inputtext'), "Visible")
        await this.verifyVisibility(getLocator(this.locatorPath,'DistributionIdSteupPage.cancelButton'), "Visible")
        await this.verifyVisibility(getLocator(this.locatorPath,'DistributionIdSteupPage.updateButton'), "Visible")
        await this.verifyButtonState(getLocator(this.locatorPath,'DistributionIdSteupPage.bankName_Inputtext'), "Disabled");
        await this.verifyButtonState(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountName_Inputtext'), "Disabled");
        await this.verifyButtonState(getLocator(this.locatorPath,'DistributionIdSteupPage.glAPAccountName_Inputtext'), "Diasbled");
    }
    async addSetupID() {
        global.distributionIDCode = "Test" + await this.getRandomString(4)
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.distributionIDField'), global.distributionIDCode)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.bankID_Inputtext'));
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.firstElement'))
        await this.isVisible(getLocator(this.locatorPath,'DistributionIdSteupPage.bankName_Inputtext'))
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountID_Inputtext'));
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.firstElement'))
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountID_Inputtext'));
        let glAccId=await this.getText(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountName_InputValue'))
        let glACCFund=glAccId.substring(0,3)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.firstElement'))
        await this.isVisible(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountName_Inputtext'))
        await this.wait(2000)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.glAPAccountID_Input'));
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.glAPAccountID_Input'),glACCFund);
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.firstElement'))
        await this.isVisible(getLocator(this.locatorPath,'DistributionIdSteupPage.glAPAccountName_Inputtext'))
        await this.wait(2000)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.updateButton'))
        await commonUtil.handleLoadingSpinner()
    }

    async apiAddDistributionId() {
        global.distributionIDCode = "Test" + await this.getRandomString(4);
        const distributionData = await apiDistributionId.createDistributionId(global.distributionIDCode);
    }
    async deleteCreatedDistributionSetupID() {
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'), global.distributionIDCode)
        await this.pressEnter()
        await this.wait(2000)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.distributionID_rowRecord'))
        await commonUtil.handleLoadingSpinner()
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.deleteButton'))
        await this.verifyText(getLocator(this.locatorPath,'DistributionIdSteupPage.delete_Heading'), "Delete Distribution ID?")
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.delete_PopUpBox'))
        await this.wait(2000)
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'), global.distributionIDCode)
        await this.pressEnter()
        await commonUtil.handleLoadingSpinner()
        await this.verifyText(getLocator(this.locatorPath,'DistributionIdSteupPage.noDataGridMessage'), "No data available to display")
    }
    async verifyPaginationButtonState(button, buttonState) {
        const status = await this.isVisible(getLocator(this.locatorPath,'DistributionIdSteupPage.noDataGridMessage'))
        if (await status == true) {
            await log.info("No data in Grid")
        }
        else if (await buttonState == "Disabled") {
            await log.info("verifying Disable")
            const status1 = await this.isVisible(getLocator(this.locatorPath,'DistributionIdSteupPage.nextPageDisabled'))
            if (await status1 == true) {
                if (await this.isDisabled(getLocator(this.locatorPath,'DistributionIdSteupPage.previousPageDisabled'))) {
                    await log.info("Data is available only in current page")
                }
            }
            else {
                await accountBreakActivity.verifyPaginationButtonDisabledState(button)
            }
        }
        else {
            await log.info("Required Page is enabled")
            await accountBreakActivity.verifyPaginationButtonEnableState(button)
        }
    }
    //add 10 records
    async addRecordsInGrid() {
        await this.wait(2000)
        for (let i = 0; i < 10; i++) {
            await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.addDistributionSetupButton'))
            await this.wait(2000)
            global.distributionIDCode2 = "Bank" + await this.getRandomString(4)
            await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.distributionIDField'), global.distributionIDCode2)
            await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.bankID_Inputtext'));
            await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.firstElement'))
            await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountID_Inputtext'));
            await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.firstElement'))
            await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.glAPAccountID_Inputtext'));
            await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.firstElement'))
            await this.wait(2000)
            await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.updateButton'))
            await commonUtil.toasterValidation("Distribution ID Added Successfully.")
        }
    }
    async validatePagination() {
        await payrollSetting.verifyShownPageNumber("10")
        await payrollSetting.verifyTotalPages()
        await payrollSetting.selectNumberofPages("5")
        await payrollSetting.selectNumberofPages("10")
        await payrollSetting.selectNumberofPages("25")
        await payrollSetting.selectNumberofPages("50")
    }
    async verifyNumberOfItem(locator: any, expectedNumberofItem: any) {
        const expectedValue = parseInt(expectedNumberofItem);
        let list = await global.page.$$(locator);
        await log.info(list.length);
        expect(list.length).toBeLessThanOrEqual(expectedValue);
        await log.info("Expected number of items: " + expectedValue + " are matching with actual number of items " + list.length);
    }
    async addSetupIDunsingWrongData() {
        global.distributionIDCode = "Test" + await this.getRandomString(4)
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.distributionIDField'), global.distributionIDCode)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.bankID_Inputtext'));
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.firstElement'))
        await this.isVisible(getLocator(this.locatorPath,'DistributionIdSteupPage.bankName_Inputtext'))
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountID_Inputtext'));
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.firstElement'))
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountID_Inputtext'));
        let glAccId=await this.getText(getLocator(this.locatorPath,'DistributionIdSteupPage.glCashAccountName_InputValue'))
        glACCFund=glAccId.substring(0,3)
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.firstElement'))
        await this.click(getLocator(this.locatorPath,'DistributionIdSteupPage.glAPAccountID_Inputtext'));
        //await this.click(this.thirdElementInDropdown)
        count= 20
        for(let i=1;i<=Number(count);i++){
            let input =`(//ng-select[@formcontrolname='glAPAccount']//div[@role='option'])[${i}]`;
            let glAccId2=await this.getText(input+"//span")
            let glACCFund2=glAccId2.substring(0,3)
            if(glACCFund==glACCFund2){
            }else{
                await this.click(input);
                break
            }
        }
    }
    async verifyErrorMessageAfterAddingWrongData(message){
        await this.wait(2000)
        await this.verifyText(getLocator(this.locatorPath,'DistributionIdSteupPage.crossFundErrorMessage'),message)
    }

    async verifyAddedLabel() {
        await this.wait(2000);
        await this.enter(getLocator(this.locatorPath,'DistributionIdSteupPage.searchBox'), global.distributionIDCode);
        await this.pressEnter();
        await this.wait(2000);
        await commonUtil.handleLoadingSpinner();
        await this.verifyElementTrimmedText(getLocator(this.locatorPath,'DistributionIdSteupPage.search_DistributionIdSetUp'), global.distributionIDCode);
    }  
    
}
