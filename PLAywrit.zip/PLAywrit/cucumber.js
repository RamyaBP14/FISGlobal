const { chromium } = require("playwright");
const { exec } = require('child_process');

let common = [
    'src/features/**/timeRounding.feature', // Specify our feature files
    '--require-module ts-node/register', // Load TypeScript module
    '--require src/step-definitions/**/*.ts', // Load step definitions
    '--require src/utility/*.ts',
    '--format ./Report.js',
    '--format json:src/resources/reports/cucumber-report.json', // Load custom formatter
    '--format rerun:@rerun.txt',
    '--publish-quiet'
].join(' ');
let allHub = [
    'src/features/**/*.feature', // Specify our feature files
    '--require-module ts-node/register', // Load TypeScript module
    '--require src/step-definitions/**/*.ts', // Load step definitions
    '--require src/utility/*.ts',
    '--format ./Report.js',
    '--format json:src/resources/reports/cucumber-report.json ', // Load custom formatter
    '--tags "@hrhub or @opshub or @ubhub"',
    '--publish-quiet'
].join(' ');
let reRun = [
    //'src/features/**/*.feature', // Specify our feature files
    '--require-module ts-node/register', // Load TypeScript module
    '--require src/step-definitions/**/*.ts', // Load step definitions
    '--require src/utility/*.ts',
    '--format ./Report.js',
    '--format json:src/resources/reports/cucumber-report.json', // Load custom formatter
    '--format rerun:@rerun.txt',
    '--publish-quiet'
].join(' ');

let smoke = `${common} --tags '@smoke'`
let sanity = `${common} --tags '@sanity'`
let test = `${common} --tags '@test51'`
let regression = `${common} --tags '@regression'`
let UbRegression = `${common} --tags '@UbRegression'`
let financeHubRegression = `${common} --tags '@financeHubRegression'`
let regressionTest = `${common} --tags '@regressionTest'`
let opshub = `${common} --tags '@opshub'`
let hrhub = `${common} --tags '@hrhub'`
let ubhub = `${common} --tags '@ubhub'`
let billingRun = `${common} --tags '@billingRun'`
let hrSmoke = `${common} --tags '@hrSmoke'`
let ubSmoke = `${common} --tags '@ubSmoke'`
let opsSmoke = `${common} --tags '@opsSmoke'`
let MDM = `${common} --tags '@MDM'`
let MDMDownload = `${common} --tags '@MDMDownload'`
let MDMUpload = `${common} --tags '@MDMUpload'`
let allhub = `${allHub}`
let payrollCalculation = `${common} --tags '@payrollCalculation11'`
let FederalTax = `${common} --tags '@FederalTax'`
let FederalTax1 = `${common} --tags '@FederalTax1'`
let FederalTax2 = `${common} --tags '@FederalTax2'`
let StateTax1 = `${common} --tags '@StateTax1'`
let StateTax2 = `${common} --tags '@StateTax2'`
let StateSanity = `${common} --tags '@StateSanity'`
let stateTaxCalculation = `${common} --tags '@stateTaxCalculation'`
let financeHub = `${common} --tags '@financeHub'`
let financeSmoke = `${common} --tags '@financeSmoke'`
let chr = "set process.env.Browser = chromium"
let fire = `--world-parameters '{"browser": "webkit"}'`
let safari = "set process.env.Browser = webkit"
let para = "--parallel 4"
let sanity_hr = `${common} --tags '@sanity_hr'`
let tests = `${common} --tags '@tests'`
let financeSanity = `${common} --tags '@financeSanity'`
let financeTest = `${common} --tags '@financeTest'`
let RunOncePipeline = `${common} --tags '@RunOncePipeline'`
let rerunFailed = `${reRun}`
let timesheet = `${common} --tags '@timesheet'`
let city2 = `${common} --tags '@city2'`
let city3 = `${common} --tags '@city3'`
let city4 = `${common} --tags '@city4'`
let city5 = `${common} --tags '@city5'`
let city6 = `${common} --tags '@city6'`
let city7 = `${common} --tags '@city7'`
let city8 = `${common} --tags '@city8'`
let city9 = `${common} --tags '@city9'`
let city10 = `${common} --tags '@city10'`
let city11 = `${common} --tags '@city11'`
let city12 = `${common} --tags '@city12'`
let city13 = `${common} --tags '@city13'`
let city14 = `${common} --tags '@city12'`
let city15 = `${common} --tags '@city13'`
let city16 = `${common} --tags '@city16'`



module.exports = {
    default: common,
    smoke: smoke,
    sanity: sanity,
    test: test,
    opshub: opshub,
    hrhub: hrhub,
    ubhub: ubhub,
    billingRun: billingRun,
    hrSmoke: hrSmoke,
    ubSmoke: ubSmoke,
    opsSmoke: opsSmoke,
    MDM: MDM,
    MDMDownload: MDMDownload,
    MDMUpload: MDMUpload,
    allhub: allhub,
    regression: regression,
    regressionTest: regressionTest,
    stateTaxCalculation: stateTaxCalculation,
    payrollCalculation: payrollCalculation,
    chromium: chr,
    firefox: fire,
    safari: safari,
    RunOncePipeline: RunOncePipeline,
    parallel: para,
    sanity_hr: sanity_hr,
    UbRegression: UbRegression,
    financeHub: financeHub,
    tests: tests,
    financeHubRegression:financeHubRegression,
    financeSmoke: financeSmoke,
    financeSanity: financeSanity,
    financeTest:financeTest,
    rerunFailed: rerunFailed,
    FederalTax: FederalTax,
    FederalTax1: FederalTax1,
    FederalTax2: FederalTax2,
    StateTax1: StateTax1,
    StateSanity: StateSanity,
    StateTax2: StateTax2,
    timesheet: timesheet,
    city2: city2,
    city3: city3,
    city4: city4,
    city5: city5,
    city6: city6,
    city7: city7,
    city8: city8,
    city9: city9,
    city10: city10,
    city11: city11,
    city12: city12,
    city13: city13,
    city14: city14,
    city15: city15,
    city16: city16
};
